module.exports = {
    "VIDEO_LOADING": {
        "en-US": "Loading",
        "ko-KR": "로딩중",
        "zh-CHS": "载入中",
        "zh-CHT": "載入中",
        "ja-JP": "ローディング"
    },
    "VIDEO_CONNECTING": {
        "en-US": "Connecting to Server",
        "ko-KR": "접속중입니다.",
        "zh-CHS": "正在连接到服务器",
        "zh-CHT": "正在連接到服務器",
        "ja-JP": "サーバーに接続中"
    },
    "VIDEO_CONNECTED": {
        "en-US": "Server Connected",
        "ko-KR": "접속 성공입니다..",
        "zh-CHS": "成功连接服务器",
        "zh-CHT": "成功連接服務器",
        "ja-JP": "サーバーに接続しました"
    },
    "VIDEO_RECONNECTING": {
        "en-US": "Reconnecting to Server",
        "ko-KR": "재접속 시도합니다.",
        "zh-CHS": "重新连接服务器",
        "zh-CHT": "重重新連接服務器",
        "ja-JP": "サーバーに再接続中"
    },
    "VIDEO_CONNECT_FAIL": {
        "en-US": "Authentication Failed",
        "ko-KR": "접속실패입니다.",
        "zh-CHS": "验证失败",
        "zh-CHT": "驗證失敗",
        "ja-JP": "認証に失敗しました"
    },
    "VIDEO_NOMORE_CONNECTING": {
        "en-US": "Network is unstable. Please refresh manually.",
        "ko-KR": "네트워크환경이 불안정합니다. 새로고침버튼을 눌러 주세요.",
        "zh-CHS": "网络不稳定，请手动刷新.",
        "zh-CHT": "網絡不穩定，請手動刷新.",
        "ja-JP": "ネットワークが不安定です。手動でリフレッシュしてください"
    },
    "VIDEO_BUFFER_EMPTY": {
        "en-US": "Unstable Network",
        "ko-KR": "네트워크 상태가 좋지 않습니다.",
        "zh-CHS": "不稳定网络",
        "zh-CHT": "不穩定網絡",
        "ja-JP": "ネットワークが不安定"
    },
    "VIDEO_BUFFER_WAITING": {
        "en-US": "Buffering",
        "ko-KR": "버퍼링중입니다.",
        "zh-CHS": "正在缓冲]",
        "zh-CHT": "正在緩衝]",
        "ja-JP": "バッファリング中"
    }
}