module.exports = {
    "INSUFFICIENT_CREDIT": {
        "en-US": "INSUFFICIENT CREDIT",
        "ko-KR": "잔액이 부족합니다",
        "zh-CHS": "余额不足",
        "zh-CHT": "餘額不足",
        "ja-JP": "残高不足"
    },
    "YOUR_BET_IS_SUCCESSFUL": {
        "en-US": "YOUR BET IS SUCCESSFUL",
        "ko-KR": "베팅이 성공했습니다",
        "zh-CHS": "投注成功",
        "zh-CHT": "投注成功",
        "ja-JP": "ベット成功"
    },
    "PLACE_YOUR_BETS_PLEASE": {
        "en-US": "PLACE YOUR BETS PLEASE",
        "ko-KR": "베팅을 시작해 주세요",
        "zh-CHS": "请投注",
        "zh-CHT": "請投注",
        "ja-JP": "ベットしてください"
    },
    "NO_MORE_BETS_PLEASE": {
        "en-US": "NO MORE BET PLEASE",
        "ko-KR": "베팅을 중지해 주세요",
        "zh-CHS": "请停止投注",
        "zh-CHT": "請停止投注",
        "ja-JP": "ベットを止めてください"
    },
    "NO_GAME": {
        "en-US": "CANCEL GAME",
        "ko-KR": "게임취소",
        "zh-CHS": "取消游戏",
        "zh-CHT": "取消遊戲",
        "ja-JP": "ゲームをキャンセルします"
    },
    "PLEASE_WAIT_FOR_THE_NEXT_ROUND": {
        "en-US": "PLEASE WAIT FOR THE NEXT ROUND",
        "ko-KR": "다음게임부터 참여할 수 있습니다",
        "zh-CHS": "请等待下一局",
        "zh-CHT": "請等待下一局",
        "ja-JP": "次のラウンドをお待ちください"
    },
    "PLEASE_WAIT_FOR_THE_SHOE_CHANGE": {
        "en-US": "PLEASE WAIT FOR THE SHOE CHANGE",
        "ko-KR": "카드 슈 교체중입니다",
        "zh-CHS": "请等待更换扑克牌",
        "zh-CHT": "請等待更換撲克牌",
        "ja-JP": "カード 交換中です。しばらくお待ちください。"
    },
    "PLEASE_WAIT_FOR_THE_DEALER_CHANGE": {
        "en-US": "PLEASE WAIT FOR THE DEALER CHANGE",
        "ko-KR": "딜러 교대중입니다",
        "zh-CHS": "请等待更换荷官",
        "zh-CHT": "請等待更換荷官",
        "ja-JP": "ディーラー交代中です。しばらくお待ちください"
    },
    "BOX_BET_EXCEED_MAXIMUM_LIMIT": {
        "en-US": "BOX BET EXCEED MAXIMUM LIMIT",
        "ko-KR": "영역 베팅한도초과",
        "zh-CHS": "投注已超过最大投注金额",
        "zh-CHT": "投注已超過最大投注金額",
        "ja-JP": "ボックスベットが上限を超えています"
    },
    "MAXIMUM_ALLOWED_BET": {
        "en-US": "THE MAXIMUM ALLOWED BET IS {0}.<br>PLACE A SMALLER BET AND TRY AGAIN.",
        "ko-KR": "THE MAXIMUM ALLOWED BET IS {0}.<br>PLACE A SMALLER BET AND TRY AGAIN.",
        "zh-CHS": "最高投注金额为 {0}.<br>请选择较小的投注金额再重新下注.",
        "zh-CHT": "最高投注金額為 {0}.<br>請選擇較小的投注金額再重新下注.",
        "ja-JP": "賭け金の上限額は{0}.<br>賭け金を少なくして、もう一度ベットしてください"
    },
    "BETTING_MIN_BET": {
        "en-US": "Please bet more than minimum limit",
        "ko-KR": "최소 베팅 금액을 확인해주세요",
        "zh-CHS": "请投注超过最低余额",
        "zh-CHT": "請投注超過最低餘額",
        "ja-JP": "賭け金の下限を超える金額をベットしてください"
    },
    "BACCARAT_PLAYER_WIN": {
        "en-US": "PLAYER",
        "ko-KR": "플레이어",
        "zh-CHS": "闲家",
        "zh-CHT": "閒家",
        "ja-JP": "プレイヤー"
    },
    "BACCARAT_BANKER_WIN": {
        "en-US": "BANKER",
        "ko-KR": "뱅커",
        "zh-CHS": "庄家",
        "zh-CHT": "莊家",
        "ja-JP": "バンカー"
    },
    "BACCARAT_BANKER_WIN_SUPERSIX": {
        "en-US": "BANKER, SUPERSIX",
        "ko-KR": "뱅커 슈퍼식스",
        "zh-CHS": "庄家, 超级六点",
        "zh-CHT": "莊家, 超級六點",
        "ja-JP": "バンカー、スーパー6"
    },
    "TIE_WIN": {
        "en-US": "TIE",
        "ko-KR": "타이",
        "zh-CHS": "和局",
        "zh-CHT": "和局",
        "ja-JP": "引き分け"
    },
    "BACCARAT_PLAYER_PAIR": {
        "en-US": "PLAYER PAIR",
        "ko-KR": "플레이어 페어",
        "zh-CHS": "闲家 对子",
        "zh-CHT": "閒家 對子",
        "ja-JP": "プレイヤーペア"
    },
    "BACCARAT_BANKER_PAIR": {
        "en-US": "BANKER PAIR",
        "ko-KR": "뱅커 페어",
        "zh-CHS": "庄家 对子",
        "zh-CHT": "莊家 對子",
        "ja-JP": "バンカーペア"
    },
    "DRAGON_WIN": {
        "en-US": "DRAGON",
        "ko-KR": "드래곤",
        "zh-CHS": "龙门",
        "zh-CHT": "龍門",
        "ja-JP": "ドラゴン"
    },
    "TIGER_WIN": {
        "en-US": "TIGER",
        "ko-KR": "타이거",
        "zh-CHS": "虎门",
        "zh-CHT": "虎門",
        "ja-JP": "タイガー"
    },
    "WINS": {
        "en-US": "WINS",
        "ko-KR": "승리",
        "zh-CHS": "获胜",
        "zh-CHT": "獲勝",
        "ja-JP": "勝ち"
    },
    "CAN_NOT_BOTH_BET": {
        "en-US": "Can not bet on both sides",
        "ko-KR": "두군데 같이 베팅할수 없습니다",
        "zh-CHS": "不能两边投注",
        "zh-CHT": "不能兩邊投注",
        "ja-JP": "両方にベットすることはできません"
    },
    "PLAYER_MIN_BET": {
        "en-US": "Check player min bet",
        "ko-KR": "플레이어 최소 베팅 금액",
        "zh-CHS": "查询闲家最低投注",
        "zh-CHT": "查詢閒家最低投注",
        "ja-JP": "プレイヤーの賭け金の下限額を確認してください"
    },
    "BANKER_MIN_BET": {
        "en-US": "Check banker min bet",
        "ko-KR": "뱅커 최소 베팅 금액",
        "zh-CHS": "查询闲家最低投注",
        "zh-CHT": "莊家閒家最低投注",
        "ja-JP": "バンカーの賭け金の下限額を確認してください"
    },
    "DRAGON_MIN_BET": {
        "en-US": "Check dragon min bet",
        "ko-KR": "드래곤 최소 베팅 금액",
        "zh-CHS": "查询庄家最低投注",
        "zh-CHT": "查詢莊家最低投注",
        "ja-JP": "ドラゴンの賭け金の下限額を確認してください"
    },
    "TIGER_MIN_BET": {
        "en-US": "Check tiger min bet",
        "ko-KR": "타이거 최소 베팅 금액",
        "zh-CHS": "查询龙门最低投注",
        "zh-CHT": "查詢龍門最低投注",
        "ja-JP": "タイガーの賭け金の下限額を確認してください"
    },
    "TIE_MIN_BET": {
        "en-US": "Check tie min bet",
        "ko-KR": "타이 최소 베팅 금액",
        "zh-CHS": "查询和局最低投注",
        "zh-CHT": "查詢和局最低投注",
        "ja-JP": "引き分けの賭け金の下限額を確認してください"
    },
    "PLAYERPAIR_MIN_BET": {
        "en-US": "Check playerpair min bet",
        "ko-KR": "플레이어페어 최소 베팅 금액",
        "zh-CHS": "查询闲家对子最低投注",
        "zh-CHT": "查詢閒家對子最低投注",
        "ja-JP": "プレイヤーペアの賭け金の下限額を確認してください"
    },
    "BANKERPAIR_MIN_BET": {
        "en-US": "Check bankerpair min bet",
        "ko-KR": "뱅커페어 최소 베팅 금액",
        "zh-CHS": "查询庄家对子最低投注",
        "zh-CHT": "查詢莊家對子最低投注",
        "ja-JP": "バンカーペアの賭け金の下限額を確認してください"
    },
    "SUPERSIX_MIN_BET": {
        "en-US": "Check supersix min bet",
        "ko-KR": "슈퍼식스 최소 베팅 금액",
        "zh-CHS": "查询超级六点最低投注",
        "zh-CHT": "查詢超級六點最低投注",
        "ja-JP": "スーパー6の賭け金の下限額を確認してください"
    },
    "CORRECTION_CARD": {
        "en-US": "Incorrect card has been modified",
        "ko-KR": "잘못된 카드가<br>수정 되었습니다.",
        "zh-CHS": "错误扑克牌已经被修改",
        "zh-CHT": "錯誤撲克牌已經被修改",
        "ja-JP": "誤ったカード変更されています"
    },
    "PRINT_CONNECT_SUCCESS": {
        "en-US": "Print Connect Success",
        "ko-KR": "프린트연결에 성공하였습니다.",
        "zh-CHS": "打印连接成功",
        "zh-CHT": "打印連接成功",
        "ja-JP": "接続成功の表示"
    },
    "PRINT_CONNECT_FAIL": {
        "en-US": "Print Connect Fail",
        "ko-KR": "프린트연결에 실패하였습니다.",
        "zh-CHS": "打印连接失败",
        "zh-CHT": "打印連接失敗",
        "ja-JP": "接続失敗の表示"
    },
    "NO_CHIPS_TABLE": {
        "en-US": "No chips put on the table.",
        "ko-KR": "테이블위에 올려놓은 칩이 없습니다.",
        "zh-CHS": "No chips put on the table.",
        "zh-CHT": "沒有籌碼放在桌子上。",
        "ja-JP": "No chips put on the table."
    },
    "CONFIRM_SAVE_BETS": {
        "en-US": "Do you wish to save current bet?",
        "ko-KR": "현재 베팅칩을 저장하시겠습니까?",
        "zh-CHS": "Do you wish to save current bet?",
        "zh-CHT": "您是否希望保存當前投注？",
        "ja-JP": "Do you wish to save current bet?"
    },
    "REMOVE_SAVE_BETS": {
        "en-US": "Do you wish to erase bets?",
        "ko-KR": "베팅정보를 지우시겠습니까?",
        "zh-CHS": "您想删除赌注？",
        "zh-CHT": "您想刪除賭注？",
        "ja-JP": "Do you wish to erase bets?"
    },
    "NO_BETS_AVALIBLE": {
        "en-US": "Unable to bet at this moment.",
        "ko-KR": "현재 베팅이 가능하지 않습니다.",
        "zh-CHS": "目前无法下注。",
        "zh-CHT": "目前無法下注。",
        "ja-JP": "Unable to bet at this moment."
    },
    "MY_TURN_SQUEEZE": {
        "en-US": "It's your turn.<br>Check your card.",
        "ko-KR": "당신의 차례입니다.<br>카드를 스퀴즈 해주세요.",
        "zh-CHS": "轮到你了.<br>查看你的牌.",
        "zh-CHT": "輪到你了.<br>查看您的牌.",
        "ja-JP": "It's your turn.<br>Check your card."
    },
    "OTHER_TURN_SQUEEZE": {
        "en-US": "{0}<br>is checking the card.",
        "ko-KR": "{0}님이<br>카드 스퀴즈중입니다.",
        "zh-CHS": "{0}<br>正在看牌",
        "zh-CHT": "{0}<br>正在看牌.",
        "ja-JP": "{0}<br>is checking the card."
    },
    "CONFIRM_TIP": {
        "en-US": "Sending {0} to the dealer.",
        "ko-KR": "딜러에게 {0} 팁을 전송하시겠습니까?",
        "zh-CHS": "Sending {0} 给荷官.",
        "zh-CHT": "Sending {0} 給荷官.",
        "ja-JP": "Sending {0} to the dealer."
    },
    "RES_TIP_SUCCESS": {
        "en-US": "Your tip is delivered to the dealer.",
        "ko-KR": "딜러에게 팁이 성공적으로 전송됐습니다.",
        "zh-CHS": "您的小费已转移给荷官",
        "zh-CHT": "您的小費已轉移給荷官.",
        "ja-JP": "Your tip is delivered to the dealer."
    },
    "PAD_TIP_ST": {
        "en-US": "- You may select up to 5 balls.\\n- 1 stake of bet is available per line.\\n- It is not allowed to cancel/edit/refund after clicking the 'BET' button.",
        "ko-KR": "- 볼 1개 ~ 5개까지 자유롭게 베팅이 가능합니다.\\n- 1라인당 게임 비용은 1입니다.\\n- BET버튼을 클릭한 후에는 취소, 수정, 환불이 불가능합니다.",
        "zh-CHS": "- 1 〜 5随意观看，你可以下注。\\n- 每场比赛费用1一行.\\n- 你点击BET按钮后，取消，修改，不退还。",
        "zh-CHT": "- 1 〜 5隨意觀看，你可以下注。\\n- 每場比賽費用1一行.\\n- 你點擊BET按鈕後，取消，修改，不退還。",
        "ja-JP": "- ボール1個〜 5個まで自由に賭けが可能です.\\n- 1ラインあたりのゲームのコストは1です.\\n- BETボタンをクリックした後は、キャンセル、修正、払い戻しはできません."
    },
    "PAD_TIP_CB": {
        "en-US": "- You may select up to 14 balls.\\n- Please make a check sign on any desired bet type among the 5 types.\\n- It is not allowed to cancel/edit/refund after clicking the 'BET' button.",
        "ko-KR": "- 볼 1개~ 14개까지 자유롭게 선택할 수 있습니다.\\n- 베팅 타입은 5개이며 원하는 항목에 체크를 하시면 됩니다.\\n- BET버튼을 클릭한 후에는 취소, 수정, 환불이 불가능합니다.",
        "zh-CHS": "- 从1-14 ，你可以选择免费查看。.\\n- 5注型简直就是你想要的物品进行检查。\\n- 你点击BET按钮后，取消，修改，不退还。",
        "zh-CHT": "- 从1-14 ，你可以選擇免費查看。.\\n- 5注型簡直就是你想要的物品進行檢查。\\n- 你點擊BET按鈕後，取消，修改，不退還。",
        "ja-JP": "- ボール1個〜 14個まで自由に選択することができます.\\n- ベットタイプは5個であり、目的の項目にチェックをください.\\n- BETボタンをクリックした後は、キャンセル、修正、払い戻しはできません."
    },
    "PAD_TIP_BN": {
        "en-US": "- You can select 1 number per line.\\n- 1 stake of bet is available per line.\\n- It is not allowed to cancel/edit/refund after clicking the 'BET' button.",
        "ko-KR": "- 1라인당 선택할 수 있는 번호는 1개입니다.\\n- 1라인당 게임 비용은 1입니다.\\n- BET버튼을 클릭한 후에는 취소, 수정, 환불이 불가능합니다.",
        "zh-CHS": "- 您可以选择一个数字，每行1.\\n- 每场比赛费用1一行.\\n- 你点击BET按钮后，取消，修改，不退还。",
        "zh-CHT": "- 您可以选择一个数字，每行1.\\n- 每场比赛费用1一行.\\n- 你點擊BET按鈕後，取消，修改，不退還。",
        "ja-JP": "- 1ラインあたり選択できる番号は1つです.\\n- 1ラインあたりのゲームのコストは1です.\\n- BETボタンをクリックした後は、キャンセル、修正、払い戻しはできません."
    },
    "PAD_TIP_BC": {
        "en-US": "- You can select 1 color per line.\\n- 1 stake of bet is available per line.\\n- It is not allowed to cancel/edit/refund after clicking the 'BET' button.",
        "ko-KR": "- 1라인당 선택할 수 있는 색상은 1개입니다.\\n- 1라인당 게임 비용은 1입니다.\\n- BET버튼을 클릭한 후에는 취소, 수정, 환불이 불가능합니다.",
        "zh-CHS": "- 你可以选择一种颜色，每行1.\\n- 每场比赛费用1一行.\\n- 你点击BET按钮后，取消，修改，不退还。",
        "zh-CHT": "- 你可以選擇一種顏色，每行1.\\n- 每场比赛费用1一行.\\n- 你點擊BET按鈕後，取消，修改，不退還。",
        "ja-JP": "- 1ラインあたり選択できる色は1つです.\\n- 1ラインあたりのゲームのコストは1です.\\n- BETボタンをクリックした後は、キャンセル、修正、払い戻しはできません."
    },
    "PAD_TIP_N1ST": {
        "en-US": "- You can select 1 number per line.\\n- 1 stake of bet is available per line.\\n- It is not allowed to cancel/edit/refund after clicking the 'BET' button.",
        "ko-KR": "- 1라인당 선택할 수 있는 번호는 1개입니다.\\n- 1라인당 게임 비용은 1입니다.\\n- BET버튼을 클릭한 후에는 취소, 수정, 환불이 불가능합니다.",
        "zh-CHS": "- 您可以选择一个数字，每行1.\\n- 每场比赛费用1一行.\\n- 你点击BET按钮后，取消，修改，不退还。",
        "zh-CHT": "- 您可以選擇一個數字，每行1.\\n- 每場比賽費用1一行.\\n- 你點擊BET按鈕後，取消，修改，不退還。",
        "ja-JP": "- 1ラインあたり選択できる番号は1つです.\\n- 1ラインあたりのゲームのコストは1です.\\n- BETボタンをクリックした後は、キャンセル、修正、払い戻しはできません."
    },
    "PAD_TIP_TV": {
        "en-US": "- Bet on a sum of all 6 normal balls.\\n- 1 stake of bet is available per line.\\n- It is not allowed to cancel/edit/refund after clicking the 'BET' button.",
        "ko-KR": "- 일반볼 6개의 합산 수를 예측하여 베팅을 하여 주세요.\\n- 1라인당 게임 비용은 1입니다.\\n- BET버튼을 클릭한 후에는 취소, 수정, 환불이 불가능합니다.",
        "zh-CHS": "- 加上6普遍认为请估计投注数量.\\n- 每场比赛费用1一行.\\n- 你点击BET按钮后，取消，修改，不退还.",
        "zh-CHT": "- 押注於全部6球正常的總和.\\n- 每場比賽費用1一行.\\n- 你點擊BET按鈕後，取消，修改，不退還.",
        "ja-JP": "- 一般的なボール6個の合算数を予測して賭けをしてください.\\n- 一般的なボール6個の合算数を予測して賭けをしてください.\\n- BETボタンをクリックした後は、キャンセル、修正、払い戻しはできません."
    },
    "PAD_TIP_OE": {
        "en-US": "- Bet on either even or odd.\\n- You can bet when all 6 items are checked.\\n- Bet stake is fixed to 1, and it's not allowed to cancel/edit/refund after clicking the 'BET' button.",
        "ko-KR": "- 해당 볼의 홀.짝 여부를 체크하여 주십시오.\\n- 6개 모두 체크되어야 베팅이 가능합니다.\\n- 게임 비용은 1이며, BET 버튼 클릭 후에는 취소,수정,환불이 불가능합니다.",
        "zh-CHS": "- 球的孔，请检查是否对.\\n- 您应该检查所有六个可能的投注.\\n- 游戏成本为1 ，然后点击BET键取消，修改，不退还。",
        "zh-CHT": "- 投注奇數或偶數。.\\n- 您應該檢查所有六個可能的投注.\\n- 遊戲成本為1，然後點擊BET鍵取消，修改，不退還。.",
        "ja-JP": "- そのボールのホール。ペアかどうかをチェックしてください.\\n- 6つのすべてのチェックする必要がありベットが可能です.\\n- ゲームの費用は、 1であり、 BETボタンをクリックした後は、キャンセル、修正、払い戻しはできません."
    },
    "PAD_TIP_HL": {
        "en-US": "- Bet on either high or low.\\n- You can bet when all 6 items are checked.\\n- Bet stake is fixed to 1, and it's not allowed to cancel/edit/refund after clicking the 'BET' button.",
        "ko-KR": "- 해당 볼의 높고, 낮음을 체크하여 주십시오.\\n- 6개 모두 체크되어야 베팅이 가능합니다.\\n- 게임 비용은 1이며, BET 버튼 클릭 후에는 취소,수정,환불이 불가능합니다.",
        "zh-CHS": "- 高，低的观点，请检查.\\n- 您应该检查所有六个可能的投注.\\n- 游戏成本为1 ，然后点击BET键取消，修改，不退还.",
        "zh-CHT": "- 押注於或高或低.\\n- 您應該檢查所有六個可能的投注..\\n- 遊戲成本為1，然後點擊BET鍵取消，修改，不退還。",
        "ja-JP": "- そのボールの高く、低をチェックしてください.\\n- 6つのすべてのチェックする必要がありベットが可能です.\\n- ゲームの費用は、 1であり、 BETボタンをクリックした後は、キャンセル、修正、払い戻しはできません."
    },
    "LADDER_CHECK_BET": {
        "en-US": "Please choose betting type.",
        "ko-KR": "베팅을 선택해 주세요.",
        "zh-CHS": "请选择投注类型.",
        "zh-CHT": "請選擇投注類型.",
        "ja-JP": "Please choose betting type."
    },
    "LADDER_CHECK_CHIP": {
        "en-US": "Place bets using chips.",
        "ko-KR": "칩을 선택해 주세요.",
        "zh-CHS": "下注请用筹码.",
        "zh-CHT": "下注請用筹码.",
        "ja-JP": "Place bets using chips."
    },
    "CANNOT_BET_TIME": {
        "en-US": "Not in betting time.",
        "ko-KR": "베팅 시간이 아닙니다.",
        "zh-CHS": "请等会才下注.",
        "zh-CHT": "請等會才下注.",
        "ja-JP": "Not in betting time."
    },
    "STANDBY_GAME_LOTTERY": {
        "en-US": "Starting game.",
        "ko-KR": "추첨을 시작합니다.",
        "zh-CHS": "游戏开始.",
        "zh-CHT": "遊戲開始.",
        "ja-JP": "Starting game."
    },
    "STANDBY_GAME_BETTING": {
        "en-US": "The betting time starts soon.",
        "ko-KR": "잠시 후에 베팅이 시작됩니다.",
        "zh-CHS": "投注时间即将开始.",
        "zh-CHT": "投注時間即將開始.",
        "ja-JP": "The betting time starts soon."
    },
    "CURRENT_LADDER_IN_PROGRESS": {
        "en-US": "Please wait for the settlement.",
        "ko-KR": "현재 추첨 중입니다. 잠시만 기다려 주세요.",
        "zh-CHS": "请稍后在清算中.",
        "zh-CHT": "請稍候在清算中.",
        "ja-JP": "Please wait for the settlement."
    },
    "BET_AREA_EXCEEDED_MAXIMUM_LIMIT": {
        "en-US": "bet area max limit exceeded",
        "ko-KR": "영역 베팅 한도 초과",
        "zh-CHS": "下注区已超出限额",
        "zh-CHT": "下注區已超出限額",
        "ja-JP": "bet area max limit exceeded"
    },
    "BET_AREA_LOWER_MINIMUM_LIMIT": {
        "en-US": "lower than bet area minimum limit",
        "ko-KR": "영역 베팅 한도 미달",
        "zh-CHS": "低于下注去最低限额",
        "zh-CHT": "低於下注去最低限額",
        "ja-JP": "lower than bet area minimum limit"
    },
    "SAVE_BET_MODE_NOT_AVALIBLE": {
        "en-US": "SaveBet is available in Single View mode only",
        "ko-KR": "베팅 저장기능은 현재 뷰모드에서는<br>지원되지 않습니다.",
        "zh-CHS": "保存赌注仅在单行模式",
        "zh-CHT": "保存賭注僅在單行模式",
        "ja-JP": "SaveBet is available in Single View mode only"
    },
    "REBET_CONFIRM_MESSAGE": {
        "en-US": "Do you still want to bet?",
        "ko-KR": "베팅하시겠습니까?",
        "zh-CHS": "您还想下注吗?",
        "zh-CHT": "您還想下注嗎?",
        "ja-JP": "Do you still want to bet?"
    },
    "BACCARAT_NOT_BOTH": {
        "en-US": "Can not bet on both sides",
        "ko-KR": "두군데 같이 베팅할수 없습니다",
        "zh-CHS": "不能两边投注",
        "zh-CHT": "不能兩邊投注",
        "ja-JP": "両方にベットすることはできません"
    }
}