module.exports = {
    "SERVER_CONNECTION_FAIL": {
        "en-US": "Server Connection Fail!",
        "ko-KR": "서버 연결 실패!",
        "zh-CHS": "服务器连接失败!",
        "zh-CHT": "服務器連接失敗!",
        "ja-JP": "サーバー接続失敗！"
    },
    "GAME_ERROR": {
        "en-US": "GAME ERROR",
        "ko-KR": "게임 에러",
        "zh-CHS": "游戏错误",
        "zh-CHT": "遊戲錯誤",
        "ja-JP": "ゲーム･エラー"
    },
    "RESULT_FAILED_MORE_THAN_LIMIT": {
        "en-US": "RESULT FAILED MORE THAN LIMIT",
        "ko-KR": "더 이상 게임을 실행 할 수 없습니다.",
        "zh-CHS": "结果失败 超过限制",
        "zh-CHT": "結果失敗超過限制",
        "ja-JP": "失敗回数が限度を超えています"
    },
    "EXIT_GAME": {
        "en-US": "EXIT GAME?",
        "ko-KR": "게임을 종료하시겠습니까?",
        "zh-CHS": "退出游戏?",
        "zh-CHT": "退出遊戲?",
        "ja-JP": "ゲームを終了しますか？"
    },
    "LOGIN_SUCCESS": {
        "en-US": "{0}<br>WELCOME TO {1}.",
        "ko-KR": "{0}님<br>{1}에 오신걸 환영합니다.",
        "zh-CHS": "{0}<br>欢迎来到 {1}.",
        "zh-CHT": "{0}<br>歡迎來到 {1}.",
        "ja-JP": "{0}<br>ようこそ {1}へ"
    },
    "CANT_CHANGE_MULTIVIEW_IN_RUNNING_SLOT": {
        "en-US": "MULTIVIEW NOT ALLOWED WITH SLOTGAME OPENED",
        "ko-KR": "슬롯이 실행중이면 멀티뷰를 할 수 없습니다.",
        "zh-CHS": "多视频不允许老虎机游戏打开.",
        "zh-CHT": "多视频不允许老虎机游戏打开.",
        "ja-JP": "スロットゲームを開いている状態ではマルチビュー画面を利用できません"
    },
    "CHANGE_CREDIT": {
        "en-US": "{0} IS {1}::CHARGED|WITHDRAW",
        "ko-KR": "{0} {1}::충전|환전",
        "zh-CHS": "{0} {1}::存款成功|取款成功",
        "zh-CHT": "{0} {1}::存款成功|取款成功",
        "ja-JP": "{0} {1}::チャージ|引き出し"
    },
    "CHANGE_MINIGAME_CREDIT": {
        "en-US": "{0} {1}::WINS|BETS",
        "ko-KR": "{0} {1}::승리|베팅",
        "zh-CHS": "{0} {1}::赢利|投注",
        "zh-CHT": "{0} {1}::盈利|投注",
        "ja-JP": "{0} {1}::勝ち|ベット"
    },
    "CHANGE_NONE_CREDIT": {
        "en-US": "{0} {1}::CHARGED|WITHDRAW",
        "ko-KR": "{0} {1}::충전|환전",
        "zh-CHS": "{0} {1}::存款成功|取款成功",
        "zh-CHT": "{0} {1}::存款成功|取款成功",
        "ja-JP": "{0} {1}::課金|撤退"
    },
    "LOGIN_FALED": {
        "en-US": "LOGIN FAILED. RETRY LOGIN!",
        "ko-KR": "로그인 실패.<br>아이디와 패스워드를 확인 바랍니다.",
        "zh-CHS": "登入失败. 请重新登入!",
        "zh-CHT": "登入失敗。請重新登入!",
        "ja-JP": "ログインに失敗しました。<br>もう一度試みてください"
    },
    "SOCKET_CLOSE": {
        "en-US": "SERVER DISCONNECTED.<br>PLEASE RESTART {0}!",
        "ko-KR": "서버 연결이 종료되었습니다.<br>{0}를 다시 재실행하세요.",
        "zh-CHS": "服务器断开连接.<br>请重新启动 {0}!",
        "zh-CHT": "服服務器斷開連接.<br>重新啟動 {0}!",
        "ja-JP": "サーバー切断 <br>再起動してください {0}!"
    },
    "ERROR_JOIN_ROOM": {
        "en-US": "FAILED JOINING THE ROOM",
        "ko-KR": "방정보를 받아오는데 실패하였습니다.",
        "zh-CHS": "加入赌厅失败",
        "zh-CHT": "加入賭廳失敗",
        "ja-JP": "入室に失敗しました"
    },
    "MAINTENANCE": {
        "en-US": "MAINTENANCE",
        "ko-KR": "점검 중 입니다.",
        "zh-CHS": "系统维护",
        "zh-CHT": "系統維護",
        "ja-JP": "メンテナンス"
    },
    "TABLE_CLOSED_DUE_TO_MAINTENANCE": {
        "en-US": "TABLE CLOSED DUE TO MAINTENANCE",
        "ko-KR": "점검을 위해 테이블이 닫혔습니다.",
        "zh-CHS": "系统维护中.<br>详情请联系您的代理",
        "zh-CHT": "桌子关闭由于系统维护",
        "ja-JP": "メンテナンスのためテーブルが閉鎖中"
    },
    "APPLICATION_PATH_INVALID": {
        "en-US": "THE APPLICATION PATH<br>IS INVALID.",
        "ko-KR": "실행 경로가 올바르지 않습니다.",
        "zh-CHS": "应用程序路径<br>是无效的.",
        "zh-CHT": "應用程序路徑<br>是無效的.",
        "ja-JP": "アプリケーション経路<br>が不当です"
    },
    "APPLICATION_RESTARTING": {
        "en-US": "{0} UPDATE ALERT.<br>{0} IS NOW RESTARTING.",
        "ko-KR": "{0} 업데이트가 있습니다.<br>게임을 재실행합니다.",
        "zh-CHS": "{0} 更新警报.<br>{0} 现在正在重新开启中.",
        "zh-CHT": "{0} 更新警报.<br>{0} 現在正在重新開啟中.",
        "ja-JP": "{0} 更新通知.<br>{0} が再起動中です"
    },
    "GET_OUT_GAME": {
        "en-US": "{0} Due to no activities in the game,<br>the table has been closed.",
        "ko-KR": "{0} 게임에 참여하지 않아서<br>테이블이 닫힙니다.",
        "zh-CHS": "{0} 由于游戏中没有玩家游戏,<br>=赌桌已经关闭.",
        "zh-CHT": "{0} 由於遊戲中沒有玩家遊戲,<br>=賭桌已經關閉.",
        "ja-JP": "{0} ゲームのアクティビティが無いため、<br>テーブルが閉鎖されています"
    },
    "CHECK_NETWORK_CONNECTION": {
        "en-US": "Please check your network connection.",
        "ko-KR": "네트워크 연결 상태를 확인해주세요.",
        "zh-CHS": "请检查您的网络连接.",
        "zh-CHT": "請檢查您的網絡連接.",
        "ja-JP": "ネットワーク接続状態を確認してください"
    },
    "SYSTEM_MAINTENANCE": {
        "en-US": "System Maintenance in Progress.<br>Contact your agent for details.",
        "ko-KR": "현재 시스템 점검중입니다.<br>잠시후에 접속해주세요.",
        "zh-CHS": "系统维护过程中.<br>详情请联系您的代理.",
        "zh-CHT": "系統維護中.<br>詳情請聯繫您的代理.",
        "ja-JP": "システムメンテナンス中。<br>詳しくは代理店にお問い合わせください"
    },
    "EMERGENCY_MAINTENANCE": {
        "en-US": "[ System Maintenenance ]<br>System Maintenenance Scheduled in : {0}",
        "ko-KR": "[ 시스템 점검 ]<br>{0} 후 실시될 예정입니다.",
        "zh-CHS": "[ 系统维护中 ]<br>System Maintenenance Scheduled in : {0}",
        "zh-CHT": "[ 系統維護中 ]<br>System Maintenenance Scheduled in : {0}",
        "ja-JP": "[ System Maintenenance ]<br>System Maintenenance Scheduled in : {0}"
    },
    "EMERGENCY_MESSAGE": {
        "en-US": "[ System Message ]<br>System Message",
        "ko-KR": "[ 시스템 메세지 ]<br>시스템 메세지.",
        "zh-CHS": "[ 系统维护中 ]<br>System Message",
        "zh-CHT": "[ 系統維護中 ]<br>System Message",
        "ja-JP": "[ System Message ]<br>System Message"
    },
    "NOT_AVAILABLE_VIEWMODE_LOTTO": {
        "en-US": "Lotto Game is not available in multi mode.",
        "ko-KR": "로또 게임은 멀티뷰 전환이 불가능합니다.",
        "zh-CHS": "乐透游戏是不是在多模式下使用.",
        "zh-CHT": "樂透遊戲是不是在多模式下使用.",
        "ja-JP": "Lotto Game is not available in multi mode."
    },
    "LOADING_ASSETS": {
        "en-US": "Assets Loading...",
        "ko-KR": "로딩중...",
        "zh-CHS": "加载...",
        "zh-CHT": "加載...",
        "ja-JP": "ロード中..."
    },
    "CHECKING_SYSTEM": {
        "en-US": "Checking System...",
        "ko-KR": "시스템 체크..",
        "zh-CHS": "系统检查...",
        "zh-CHT": "系統檢查...",
        "ja-JP": "チェックシステム..."
    },
    "DECRYPT_FILES": {
        "en-US": "Decrypt contents",
        "ko-KR": "파일 복호화..",
        "zh-CHS": "解密文件",
        "zh-CHT": "解密文件",
        "ja-JP": "ファイル復号化"
    },
    "CONNECTING_SERVER": {
        "en-US": "Connecting...",
        "ko-KR": "접속중...",
        "zh-CHS": "连接中...",
        "zh-CHT": "連接中...",
        "ja-JP": "接続します..."
    },
    "AUTHENTICATION_USER": {
        "en-US": "Authentication...",
        "ko-KR": "인증중...",
        "zh-CHS": "认证...",
        "zh-CHT": "認證...",
        "ja-JP": "ユーザー認証..."
    },
    "PROGRESS_SERVER_DATAS": {
        "en-US": "Data Progress..",
        "ko-KR": "데이터 불러오기",
        "zh-CHS": "数据进展..",
        "zh-CHT": "數據進展..",
        "ja-JP": "データの進捗状況.."
    },
    "COMPLETE_SERVER_DATAS": {
        "en-US": "Data Complete..",
        "ko-KR": "데이터 완료",
        "zh-CHS": "完整数据..",
        "zh-CHT": "完整數據..",
        "ja-JP": "全データ.."
    },
    "CONNECTING_GAME": {
        "en-US": "Connecting Game..",
        "ko-KR": "게임 접속중..",
        "zh-CHS": "连接游戏中..",
        "zh-CHT": "連接遊戲中..",
        "ja-JP": "接続ゲーム.."
    },
    "DECRYPT_GAME": {
        "en-US": "Decrypt Game..",
        "ko-KR": "게임 복호화",
        "zh-CHS": "解密游戏..",
        "zh-CHT": "解密遊戲..",
        "ja-JP": "復号化ゲーム.."
    },
    "INITIALIZE_GAME": {
        "en-US": "UI initialize..",
        "ko-KR": "UI 초기화중",
        "zh-CHS": "UI 初始化..",
        "zh-CHT": "UI 初始化..",
        "ja-JP": "UI は初期化.."
    },
    "LOADING_LANGUAGE_PACK": {
        "en-US": "Loading Language Assets..",
        "ko-KR": "언어팩 불러오기..",
        "zh-CHS": "导入语言..",
        "zh-CHT": "導入語言..",
        "ja-JP": "読み込んで 言語 資産.."
    }
}