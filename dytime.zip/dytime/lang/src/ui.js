module.exports = {
    "NEIGHBOR_BET": {
        "en-US": "NEIGHBOR BET",
        "ko-KR": "이웃 배팅",
        "zh-CHS": "邻座下注",
        "zh-CHT": "鄰座下注",
        "ja-JP": "ネイバーベット"
    },
    "SAVE": {
        "en-US": "SAVE",
        "ko-KR": "저장",
        "zh-CHS": "保存",
        "zh-CHT": "保存",
        "ja-JP": "セーブ"
    },
    "REBET": {
        "en-US": "REBET",
        "ko-KR": "반복배팅",
        "zh-CHS": "重新下注",
        "zh-CHT": "重新下注",
        "ja-JP": "再ベット"
    },
    "CONFIRM": {
        "en-US": "CONFIRM",
        "ko-KR": "배팅확정",
        "zh-CHS": "确定",
        "zh-CHT": "确定",
        "ja-JP": "承認"
    },
    "CLEAR": {
        "en-US": "CLEAR",
        "ko-KR": "다시하기",
        "zh-CHS": "清除",
        "zh-CHT": "清除",
        "ja-JP": "取り消し"
    },
    "CHIP_SELECT": {
        "en-US": "SELECT",
        "ko-KR": "칩선택",
        "zh-CHS": "选择",
        "zh-CHT": "選擇",
        "ja-JP": "選択"
    },
    "LIVE BACCARAT": {
        "en-US": "LIVE BACCARAT",
        "ko-KR": "라이브 바카라",
        "zh-CHS": "现场 百家乐",
        "zh-CHT": "現場 百家樂",
        "ja-JP": "ライブ ･バカラ"
    },
    "LIVE SUPERSIX": {
        "en-US": "LIVE SUPERSIX",
        "ko-KR": "라이브 슈퍼식스",
        "zh-CHS": "现场 超级6点百家乐",
        "zh-CHT": "現場 超級6點百家樂",
        "ja-JP": "ライブ ･スーパー6"
    },
    "LIVE ROULETTE": {
        "en-US": "LIVE ROULETTE",
        "ko-KR": "라이브 룰렛",
        "zh-CHS": "现场 轮盘",
        "zh-CHT": "現場 輪盤",
        "ja-JP": "ライブ ･ルーレット"
    },
    "LIVE SICBO": {
        "en-US": "LIVE SICBO",
        "ko-KR": "라이브 식보",
        "zh-CHS": "现场 骰宝",
        "zh-CHT": "現場 骰寶",
        "ja-JP": "ライブ ・シックボー"
    },
    "LIVE DRAGON TIGER": {
        "en-US": "LIVE DRAGON TIGER",
        "ko-KR": "라이브 드래곤 타이거",
        "zh-CHS": "现场 龙虎门",
        "zh-CHT": "現場 龍虎門",
        "ja-JP": "ライブ ･ドラゴンタイガー"
    },
    "E GAMES": {
        "en-US": "E GAMES",
        "ko-KR": "E 게임",
        "zh-CHS": "电子娱乐场",
        "zh-CHT": "電子娛樂場",
        "ja-JP": "E ゲーム"
    },
    "SLOT": {
        "en-US": "SLOT",
        "ko-KR": "슬롯",
        "zh-CHS": "老虎机",
        "zh-CHT": "老虎機",
        "ja-JP": "スロット"
    },
    "LIVE OTHER GAMES": {
        "en-US": "LIVE ROULETTE, SICBO, DRAGONTIGER<br>OTHER GAMES",
        "ko-KR": "라이브 룰렛,식보,드래곤타이거<br>기타 게임들",
        "zh-CHS": "现场 轮盘, 骰宝 龙虎<br>和其他游戏",
        "zh-CHT": "現場 輪盤，骰寶 龍虎<br>和其他遊戲",
        "ja-JP": "ライブ のルーレット、シックボー、<br>ドラゴンタイガー その他のゲーム"
    },
    "HIGH SPEED GAMES": {
        "en-US": "HIGH SPEED GAMES",
        "ko-KR": "하이스피드 게임들",
        "zh-CHS": "高速 游戏",
        "zh-CHT": "高速 游戏",
        "ja-JP": "ハイスピード ゲーム"
    },
    "TOTAL": {
        "en-US": "Total",
        "ko-KR": "전체",
        "zh-CHS": "总额",
        "zh-CHT": "總額",
        "ja-JP": "合計"
    },
    "TOTAL_BET": {
        "en-US": "Total Bet",
        "ko-KR": "전체 베팅",
        "zh-CHS": "总投注",
        "zh-CHT": "總投注",
        "ja-JP": "合計ベット額"
    },
    "BET": {
        "en-US": "Bet",
        "ko-KR": "베팅",
        "zh-CHS": "投注",
        "zh-CHT": "投注",
        "ja-JP": "ベット"
    },
    "MY_BET": {
        "en-US": "My Bet",
        "ko-KR": "나의 베팅",
        "zh-CHS": "我的投注",
        "zh-CHT": "我的投注",
        "ja-JP": "マイベット"
    },
    "MIN": {
        "en-US": "Min",
        "ko-KR": "최소",
        "zh-CHS": "最低限度",
        "zh-CHT": "最低額度",
        "ja-JP": "最低限度額"
    },
    "MAX": {
        "en-US": "Max",
        "ko-KR": "최대",
        "zh-CHS": "最高限度",
        "zh-CHT": "最高額度",
        "ja-JP": "最高限度額"
    },
    "DEALER": {
        "en-US": "Dealer",
        "ko-KR": "딜러",
        "zh-CHS": "荷官",
        "zh-CHT": "荷官",
        "ja-JP": "ディーラー"
    },
    "GAME_ROUND": {
        "en-US": "Round",
        "ko-KR": "라운드",
        "zh-CHS": "局数",
        "zh-CHT": "局數",
        "ja-JP": "ラウンド"
    },
    "PLAYER": {
        "en-US": "Player",
        "ko-KR": "플레이어",
        "zh-CHS": "闲家",
        "zh-CHT": "閒家",
        "ja-JP": "プレイヤー"
    },
    "BANKER": {
        "en-US": "Banker",
        "ko-KR": "뱅커",
        "zh-CHS": "庄家",
        "zh-CHT": "莊家",
        "ja-JP": "バンカー"
    },
    "DRAGON": {
        "en-US": "Dragon",
        "ko-KR": "드래곤",
        "zh-CHS": "龙门",
        "zh-CHT": "龍門",
        "ja-JP": "ドラゴン"
    },
    "TIGER": {
        "en-US": "Tiger",
        "ko-KR": "타이거",
        "zh-CHS": "虎门",
        "zh-CHT": "虎門",
        "ja-JP": "タイガー"
    },
    "TIE": {
        "en-US": "Tie",
        "ko-KR": "무승부",
        "zh-CHS": "和局",
        "zh-CHT": "和局",
        "ja-JP": "タイ"
    },
    "PLAYER_PAIR": {
        "en-US": "Player Pair",
        "ko-KR": "플레이어 페어",
        "zh-CHS": "闲家对子",
        "zh-CHT": "閒家對子",
        "ja-JP": "プレイヤーペア"
    },
    "BANKER_PAIR": {
        "en-US": "Banker Pair",
        "ko-KR": "뱅커 페어",
        "zh-CHS": "庄家对子",
        "zh-CHT": "莊家對子",
        "ja-JP": "バンカーペア"
    },
    "SUPERSIX": {
        "en-US": "Super Six",
        "ko-KR": "슈퍼식스",
        "zh-CHS": "超级六点",
        "zh-CHT": "超級六點",
        "ja-JP": "スーパー6"
    },
    "OPEN_CARD": {
        "en-US": "Open Card",
        "ko-KR": "카드 열기",
        "zh-CHS": "开牌",
        "zh-CHT": "開牌",
        "ja-JP": "カードをオープン"
    },
    "DEALER_OPEN": {
        "en-US": "Open Dealer",
        "ko-KR": "딜러 열기",
        "zh-CHS": "庄家开牌",
        "zh-CHT": "莊家開牌",
        "ja-JP": "ディーラーをオープン"
    },
    "HOT": {
        "en-US": "HOT",
        "ko-KR": "핫",
        "zh-CHS": "热门",
        "zh-CHT": "熱門",
        "ja-JP": "ホット"
    },
    "COLD": {
        "en-US": "COLD",
        "ko-KR": "콜드",
        "zh-CHS": "冷门",
        "zh-CHT": "冷門",
        "ja-JP": "コールド"
    },
    "BIG": {
        "en-US": "BIG",
        "ko-KR": "큰수",
        "zh-CHS": "大",
        "zh-CHT": "大",
        "ja-JP": "大"
    },
    "SMALL": {
        "en-US": "SMALL",
        "ko-KR": "작은수",
        "zh-CHS": "小",
        "zh-CHT": "小",
        "ja-JP": "小"
    },
    "THREE_OF_KIND": {
        "en-US": "THREE OF KIND",
        "ko-KR": "같은 세종류",
        "zh-CHS": "三条",
        "zh-CHT": "三條",
        "ja-JP": "スリーカード"
    },
    "HOT_NUMBER": {
        "en-US": "HOT NUMBER",
        "ko-KR": "핫 넘버",
        "zh-CHS": "热门号码",
        "zh-CHT": "熱門號碼",
        "ja-JP": "ホットナンバー"
    },
    "COLD_NUMBER": {
        "en-US": "COLD NUMBER",
        "ko-KR": "콜드 넘버",
        "zh-CHS": "冷门号码",
        "zh-CHT": "冷門號碼",
        "ja-JP": "コールドナンバー"
    },
    "YOU_WIN": {
        "en-US": "YOU WIN!",
        "ko-KR": "승리!",
        "zh-CHS": "您赢了!",
        "zh-CHT": "您赢了!",
        "ja-JP": "獲得賞金！"
    },
    "BET_CONFIRMED": {
        "en-US": "BET CONFIRMED!",
        "ko-KR": "배팅 완료!",
        "zh-CHS": "投注确定!",
        "zh-CHT": "投注确定!",
        "ja-JP": "ベット承認！"
    },
    "BET_INFO": {
        "en-US": "BET INFO",
        "ko-KR": "베팅 정보",
        "zh-CHS": "投注信息",
        "zh-CHT": "投注信息",
        "ja-JP": "ベット情報"
    },
    "Current": {
        "en-US": "Current Game",
        "ko-KR": "현재 게임",
        "zh-CHS": "当前的游戏",
        "zh-CHT": "當前的遊戲",
        "ja-JP": "現在のゲーム"
    },
    "Prev": {
        "en-US": "Prev Game",
        "ko-KR": "이전 게임",
        "zh-CHS": "之前的游戏",
        "zh-CHT": "之前的遊戲",
        "ja-JP": "前回のゲーム"
    },
    "Betting": {
        "en-US": "Betting",
        "ko-KR": "배팅",
        "zh-CHS": "投注",
        "zh-CHT": "投注",
        "ja-JP": "ベッティング"
    },
    "Result": {
        "en-US": "Result",
        "ko-KR": "결과",
        "zh-CHS": "结果",
        "zh-CHT": "結果",
        "ja-JP": "結果"
    },
    "Even/Odd Bet": {
        "en-US": "Even / Odd",
        "ko-KR": "홀 / 짝",
        "zh-CHS": "单 / 双",
        "zh-CHT": "單 / 雙",
        "ja-JP": "偶数 / 奇数"
    },
    "Small/Big Bet": {
        "en-US": "Small / Big",
        "ko-KR": "소 / 대",
        "zh-CHS": "小 / 大",
        "zh-CHT": "小 / 大",
        "ja-JP": "小 / 大"
    },
    "Number Bet": {
        "en-US": "Number Bet",
        "ko-KR": "숫자 배팅",
        "zh-CHS": "号码投注",
        "zh-CHT": "號碼投注",
        "ja-JP": "ナンバーズベット"
    },
    "Pair Bet": {
        "en-US": "Pair Bet",
        "ko-KR": "페어 배팅",
        "zh-CHS": "对子投注",
        "zh-CHT": "對子投注",
        "ja-JP": "ペアベット"
    },
    "total of 4": {
        "en-US": "total of 4",
        "ko-KR": "합 4",
        "zh-CHS": "总数 4",
        "zh-CHT": "總數 4",
        "ja-JP": "4ベットの合計"
    },
    "total of 5": {
        "en-US": "total of 5",
        "ko-KR": "합 5",
        "zh-CHS": "总数 5",
        "zh-CHT": "總數 5",
        "ja-JP": "5ベットの合計"
    },
    "total of 6": {
        "en-US": "total of 6",
        "ko-KR": "합 6",
        "zh-CHS": "总数 6",
        "zh-CHT": "總數 6",
        "ja-JP": "6ベットの合計"
    },
    "total of 7": {
        "en-US": "total of 7",
        "ko-KR": "합 7",
        "zh-CHS": "总数 7",
        "zh-CHT": "總數 7",
        "ja-JP": "7ベットの合計"
    },
    "total of 8": {
        "en-US": "total of 8",
        "ko-KR": "합 8",
        "zh-CHS": "总数 8",
        "zh-CHT": "總數 8",
        "ja-JP": "8ベットの合計"
    },
    "total of 9": {
        "en-US": "total of 9",
        "ko-KR": "합 9",
        "zh-CHS": "总数 9",
        "zh-CHT": "總數 9",
        "ja-JP": "9ベットの合計"
    },
    "total of 10": {
        "en-US": "total of 10",
        "ko-KR": "합 10",
        "zh-CHS": "总数 10",
        "zh-CHT": "總數 10",
        "ja-JP": "10ベットの合計"
    },
    "total of 11": {
        "en-US": "total of 11",
        "ko-KR": "합 11",
        "zh-CHS": "总数 11",
        "zh-CHT": "總數 11",
        "ja-JP": "11ベットの合計"
    },
    "total of 12": {
        "en-US": "total of 12",
        "ko-KR": "합 12",
        "zh-CHS": "总数 12",
        "zh-CHT": "總數 12",
        "ja-JP": "12ベットの合計"
    },
    "total of 13": {
        "en-US": "total of 13",
        "ko-KR": "합 13",
        "zh-CHS": "总数 13",
        "zh-CHT": "總數 13",
        "ja-JP": "13ベットの合計"
    },
    "total of 14": {
        "en-US": "total of 14",
        "ko-KR": "합 14",
        "zh-CHS": "总数 14",
        "zh-CHT": "總數 14",
        "ja-JP": "14ベットの合計"
    },
    "total of 15": {
        "en-US": "total of 15",
        "ko-KR": "합 15",
        "zh-CHS": "总数 15",
        "zh-CHT": "總數 15",
        "ja-JP": "15ベットの合計"
    },
    "total of 16": {
        "en-US": "total of 16",
        "ko-KR": "합 16",
        "zh-CHS": "总数 16",
        "zh-CHT": "總數 16",
        "ja-JP": "16ベットの合計"
    },
    "total of 17": {
        "en-US": "total of 17",
        "ko-KR": "합 17",
        "zh-CHS": "总数 17",
        "zh-CHT": "總數 17",
        "ja-JP": "17ベットの合計"
    },
    "Double Bet": {
        "en-US": "Double Bet",
        "ko-KR": "더블배팅",
        "zh-CHS": "双倍投注",
        "zh-CHT": "雙倍投注",
        "ja-JP": "ダブルベット"
    },
    "Triple Bet": {
        "en-US": "Triple Bet",
        "ko-KR": "트리플 배팅",
        "zh-CHS": "三倍投注",
        "zh-CHT": "三倍投注",
        "ja-JP": "トリプルベット"
    },
    "Any Triple": {
        "en-US": "Any Triple",
        "ko-KR": "애니 트리플",
        "zh-CHS": "任何三",
        "zh-CHT": "任何三",
        "ja-JP": "アニートリプル"
    },
    "BET_LIMITS": {
        "en-US": "BET LIMITS",
        "ko-KR": "베팅리밋",
        "zh-CHS": "投注限制",
        "zh-CHT": "投注限制",
        "ja-JP": "ベット限度額"
    },
    "Table Limits": {
        "en-US": "Table Limits",
        "ko-KR": "테이블 리밋",
        "zh-CHS": "赌桌投注限制",
        "zh-CHT": "賭桌投注限制",
        "ja-JP": "テーブルリミット"
    },
    "Split": {
        "en-US": "Split",
        "ko-KR": "스플릿",
        "zh-CHS": "分拆",
        "zh-CHT": "分拆",
        "ja-JP": "スプリット"
    },
    "Street": {
        "en-US": "Street",
        "ko-KR": "스트릿",
        "zh-CHS": "三个数字组合",
        "zh-CHT": "三個數字組合",
        "ja-JP": "ストリート"
    },
    "Corner / Four": {
        "en-US": "Corner / Four",
        "ko-KR": "코너 / 포",
        "zh-CHS": "四个数字组合",
        "zh-CHT": "四個數字組合",
        "ja-JP": "コーナー / 4点"
    },
    "Line": {
        "en-US": "Line",
        "ko-KR": "라인",
        "zh-CHS": "线注",
        "zh-CHT": "線注",
        "ja-JP": "ライン"
    },
    "Straight": {
        "en-US": "Straight",
        "ko-KR": "스트레이트",
        "zh-CHS": "单个数字",
        "zh-CHT": "單個數字",
        "ja-JP": "ストレート"
    },
    "column": {
        "en-US": "Column",
        "ko-KR": "컬럼",
        "zh-CHS": "直行",
        "zh-CHT": "直行",
        "ja-JP": "カラム"
    },
    "dozen": {
        "en-US": "Dozen",
        "ko-KR": "더즌",
        "zh-CHS": "12个数字注",
        "zh-CHT": "12個數字注",
        "ja-JP": "ダズン"
    },
    "1 - 18": {
        "en-US": "1 - 18",
        "ko-KR": "1 - 18",
        "zh-CHS": "1 - 18",
        "zh-CHT": "1 - 18",
        "ja-JP": "1 - 18"
    },
    "19 - 36": {
        "en-US": "19 - 36",
        "ko-KR": "19 - 36",
        "zh-CHS": "19 - 36",
        "zh-CHT": "19 - 36",
        "ja-JP": "19 - 36"
    },
    "Red or Black": {
        "en-US": "Red / Black",
        "ko-KR": "빨강 / 검정",
        "zh-CHS": "红/黑",
        "zh-CHT": "紅/黑",
        "ja-JP": "レッド / ブラック"
    },
    "Even or Odd": {
        "en-US": "Even / Odd",
        "ko-KR": "홀 / 짝",
        "zh-CHS": "双/单",
        "zh-CHT": "雙/單",
        "ja-JP": "偶数 / 奇数"
    },
    "DICE": {
        "en-US": "DICE",
        "ko-KR": "주사위",
        "zh-CHS": "骰宝",
        "zh-CHT": "骰寶",
        "ja-JP": "ダイス"
    },
    "PREV_GAMES": {
        "en-US": "PREV GAMES",
        "ko-KR": "이전게임",
        "zh-CHS": "之前的游戏",
        "zh-CHT": "之前的遊戲",
        "ja-JP": "前回のゲーム"
    },
    "LOG_OUT": {
        "en-US": "LOG OUT",
        "ko-KR": "나가기",
        "zh-CHS": "登出",
        "zh-CHT": "登出",
        "ja-JP": "ログアウト"
    },
    "Lobby": {
        "en-US": "Lobby",
        "ko-KR": "로비",
        "zh-CHS": "大厅",
        "zh-CHT": "大廳",
        "ja-JP": "ロビー"
    },
    "Baccarat": {
        "en-US": "Baccarat",
        "ko-KR": "바카라",
        "zh-CHS": "百家乐",
        "zh-CHT": "百家樂",
        "ja-JP": "バカラ"
    },
    "SuperSix": {
        "en-US": "Super Six",
        "ko-KR": "슈퍼 식스",
        "zh-CHS": "超级六点",
        "zh-CHT": "超級六點",
        "ja-JP": "スーパー6"
    },
    "BaccaratLive": {
        "en-US": "Live Baccarat",
        "ko-KR": "라이브 바카라",
        "zh-CHS": "现场百家乐",
        "zh-CHT": "現場百家樂",
        "ja-JP": "ライブ･バカラ"
    },
    "SuperSixLive": {
        "en-US": "Live Super Six",
        "ko-KR": "라이브 슈퍼 식스",
        "zh-CHS": "现场超级六点百家乐",
        "zh-CHT": "現場超級六點百家樂",
        "ja-JP": "ライブ･スーパー6"
    },
    "SqueezeBaccarat": {
        "en-US": "Squeeze Baccarat",
        "ko-KR": "스퀴즈 바카라",
        "zh-CHS": "咪牌百家乐",
        "zh-CHT": "咪牌百家樂",
        "ja-JP": "スクイズバカラ"
    },
    "SqueezeSuperSix": {
        "en-US": "Squeeze Super Six",
        "ko-KR": "스퀴즈 슈퍼 식스",
        "zh-CHS": "咪牌超级六点百家乐",
        "zh-CHT": "咪牌超級六點百家樂",
        "ja-JP": "スクイズスーパー6"
    },
    "VIPBaccarat": {
        "en-US": "VIP Baccarat",
        "ko-KR": "VIP 바카라",
        "zh-CHS": "贵宾竞咪百家乐",
        "zh-CHT": "貴賓競咪百家樂",
        "ja-JP": "ライブ･ドラゴンタイガー"
    },
    "VIPSuperSix": {
        "en-US": "VIP Supersix",
        "ko-KR": "VIP 슈퍼식스",
        "zh-CHS": "贵宾竞咪超级六点百家乐",
        "zh-CHT": "貴賓競咪超級六點百家樂",
        "ja-JP": "ライブ･ドラゴンタイガー"
    },
    "HighSpeedBaccarat": {
        "en-US": "HighSpeed Baccarat",
        "ko-KR": "하이스피드 바카라",
        "zh-CHS": "快速 百家乐",
        "zh-CHT": "快速 百家樂",
        "ja-JP": "ハイスピード バカラ"
    },
    "HighSpeedSuperSix": {
        "en-US": "HighSpeed Supersix",
        "ko-KR": "하이스피드 슈퍼식스",
        "zh-CHS": "快速 超级六点",
        "zh-CHT": "快速 超級六點",
        "ja-JP": "ハイスピード スーパー6"
    },
    "Roulette": {
        "en-US": "Roulette",
        "ko-KR": "룰렛",
        "zh-CHS": "轮盘",
        "zh-CHT": "輪盤",
        "ja-JP": "ルーレット"
    },
    "RouletteLive": {
        "en-US": "Live Roulette",
        "ko-KR": "라이브 룰렛",
        "zh-CHS": "现场轮盘",
        "zh-CHT": "現場輪盤",
        "ja-JP": "ライブ･ルーレット"
    },
    "HighSpeedRoulette": {
        "en-US": "HighSpeed Roulette",
        "ko-KR": "하이스피드 룰렛",
        "zh-CHS": "快速 轮盘",
        "zh-CHT": "快速 輪盤",
        "ja-JP": "ハイスピード ルーレット"
    },
    "SicBo": {
        "en-US": "Sicbo",
        "ko-KR": "식보",
        "zh-CHS": "骰宝",
        "zh-CHT": "骰寶",
        "ja-JP": "シックボー"
    },
    "SicBoLive": {
        "en-US": "Live Sicbo",
        "ko-KR": "라이브 식보",
        "zh-CHS": "现场骰宝",
        "zh-CHT": "現場骰寶",
        "ja-JP": "ライブ･シックボー"
    },
    "Lotto": {
        "en-US": "Lotto",
        "ko-KR": "로또",
        "zh-CHS": "乐透直播",
        "zh-CHT": "樂透",
        "ja-JP": "ロット"
    },
    "LottoLive": {
        "en-US": "Live Lotto",
        "ko-KR": "라이브 로또",
        "zh-CHS": "乐透直播",
        "zh-CHT": "樂透直播",
        "ja-JP": "ライブロト"
    },
    "MAINTENANCE": {
        "en-US": "MAINTENANCE",
        "ko-KR": "테이블 점검중",
        "zh-CHS": "维护",
        "zh-CHT": "維護",
        "ja-JP": "メンテナンス"
    },
    "DragonTiger": {
        "en-US": "DragonTiger",
        "ko-KR": "용 호랑이",
        "zh-CHS": "龙虎门",
        "zh-CHT": "龍虎門",
        "ja-JP": "ドラゴンタイガー"
    },
    "DragonTigerLive": {
        "en-US": "Live DragonTiger",
        "ko-KR": "라이브 용 호랑이",
        "zh-CHS": "现场龙虎斗",
        "zh-CHT": "現場龍虎鬥",
        "ja-JP": "ライブ･ドラゴンタイガー"
    },
    "ADD_TABLE": {
        "en-US": "ADD TABLE",
        "ko-KR": "테이블 추가",
        "zh-CHS": "添加赌桌",
        "zh-CHT": "添加賭桌",
        "ja-JP": "テーブル追加"
    },
    "ADD_GAME": {
        "en-US": "ADD GAME",
        "ko-KR": "게임 추가",
        "zh-CHS": "添加游戏",
        "zh-CHT": "添加遊戲",
        "ja-JP": "ゲーム追加"
    },
    "BACK_GAME": {
        "en-US": "BACK GAME",
        "ko-KR": "게임으로",
        "zh-CHS": "回到游戏",
        "zh-CHT": "回到遊戲",
        "ja-JP": "バックゲーム"
    },
    "PLAY": {
        "en-US": "PLAY",
        "ko-KR": "플레이",
        "zh-CHS": "玩",
        "zh-CHT": "玩",
        "ja-JP": "プレイ"
    },
    "LIMITS": {
        "en-US": "LIMITS",
        "ko-KR": "베팅 리스트",
        "zh-CHS": "限制",
        "zh-CHT": "限制",
        "ja-JP": "限度"
    },
    "OK": {
        "en-US": "OK",
        "ko-KR": "확인",
        "zh-CHS": "确认",
        "zh-CHT": "確認",
        "ja-JP": "OK"
    },
    "CANCEL": {
        "en-US": "CANCEL",
        "ko-KR": "취소",
        "zh-CHS": "取消",
        "zh-CHT": "取消",
        "ja-JP": "取り消し"
    },
    "CHANGE_SEAT": {
        "en-US": "Change Seat",
        "ko-KR": "자리 이동",
        "zh-CHS": "更改座位",
        "zh-CHT": "更改座位",
        "ja-JP": "座席変更"
    },
    "PLAY_BTN": {
        "en-US": "Play",
        "ko-KR": "입장",
        "zh-CHS": "游戏",
        "zh-CHT": "遊戲",
        "ja-JP": "プレイ"
    },
    "PLAYING": {
        "en-US": "Playing",
        "ko-KR": "플레이중",
        "zh-CHS": "正在游戏",
        "zh-CHT": "正在遊戲",
        "ja-JP": "プレイ中"
    },
    "KR": {
        "en-US": "KOREA",
        "ko-KR": "한국어",
        "zh-CHS": "韩国",
        "zh-CHT": "韓國",
        "ja-JP": "韓国"
    },
    "EN": {
        "en-US": "ENGLISH",
        "ko-KR": "영어",
        "zh-CHS": "英语",
        "zh-CHT": "英語",
        "ja-JP": "英语"
    },
    "JP": {
        "en-US": "JAPAN",
        "ko-KR": "일본어",
        "zh-CHS": "日本",
        "zh-CHT": "日本",
        "ja-JP": "日本"
    },
    "CN": {
        "en-US": "CHINA",
        "ko-KR": "중국어",
        "zh-CHS": "中國",
        "zh-CHT": "中國",
        "ja-JP": "中国"
    },
    "LANGUAGE": {
        "en-US": "language",
        "ko-KR": "언어",
        "zh-CHS": "语言",
        "zh-CHT": "語言",
        "ja-JP": "言語"
    },
    "GAME_SOUND": {
        "en-US": "game sound",
        "ko-KR": "게임음",
        "zh-CHS": "游戏声音",
        "zh-CHT": "遊戲聲音",
        "ja-JP": "ゲームサウンド"
    },
    "BGM_SOUND": {
        "en-US": "bgm",
        "ko-KR": "배경음",
        "zh-CHS": "bgm",
        "zh-CHT": "bgm",
        "ja-JP": "bgm"
    },
    "RECORDS": {
        "en-US": "Records",
        "ko-KR": "게임 기록",
        "zh-CHS": "记录",
        "zh-CHT": "記錄",
        "ja-JP": "記録"
    },
    "VIEW_MODE": {
        "en-US": "view mode",
        "ko-KR": "화면 전환",
        "zh-CHS": "视图模式",
        "zh-CHT": "視圖模式",
        "ja-JP": "ビューモード"
    },
    "FULL_SCREEN": {
        "en-US": "full screen",
        "ko-KR": "전체 화면",
        "zh-CHS": "全屏",
        "zh-CHT": "全屏",
        "ja-JP": "フルスクリーン"
    },
    "EXIT": {
        "en-US": "exit",
        "ko-KR": "나가기",
        "zh-CHS": "退出",
        "zh-CHT": "退出",
        "ja-JP": "終了"
    },
    "BETEAST_LINK": {
        "en-US": "bet east sports",
        "ko-KR": "bet east 스포츠",
        "zh-CHS": "bet east 体育",
        "zh-CHT": "bet east 體育",
        "ja-JP": "bet east スポーツ"
    },
    "DRAG_HANDLE": {
        "en-US": "Drag Handle",
        "ko-KR": "여기를 드래그하세요",
        "zh-CHS": "拖动手柄",
        "zh-CHT": "拖動手柄",
        "ja-JP": "Drag Handle"
    },
    "DEALER_VIDEO_TIP": {
        "en-US": "click dealer image to preview table video",
        "ko-KR": "딜러 사진을 클릭해서 테이블 미리보기를 확인하세요",
        "zh-CHS": "点击荷官图片预览桌面视频",
        "zh-CHT": "點擊荷官圖片預覽桌面視頻",
        "ja-JP": "ディーラーの画像をクリックしてテーブル映像をプレビュー"
    },
    "HISTORY_TOP_TITLE": {
        "en-US": "GAME HISTORY",
        "ko-KR": "게임 히스토리",
        "zh-CHS": "游戏历史记录",
        "zh-CHT": "遊戲歷史記錄",
        "ja-JP": "ゲーム履歴"
    },
    "HISTORY_TOP_NOTIFY_MSG": {
        "en-US": "Please refresh to update log.",
        "ko-KR": "최근 게임 기록은 새로고침을 눌러주세요.",
        "zh-CHS": "请刷新到更新日志.",
        "zh-CHT": "請刷新到更新日誌.",
        "ja-JP": "リフレッシュしてログを更新してください."
    },
    "HISTORY_TABMENU_CATEGORY_1": {
        "en-US": "LIVE GAME",
        "ko-KR": "실시간게임",
        "zh-CHS": "现场游戏",
        "zh-CHT": "場遊戲",
        "ja-JP": "ライブ･ゲーム"
    },
    "HISTORY_LIST_HEADER_COL_1": {
        "en-US": "Start Time",
        "ko-KR": "시작 시간",
        "zh-CHS": "开始时间",
        "zh-CHT": "開始時間",
        "ja-JP": "開始時刻"
    },
    "HISTORY_LIST_HEADER_COL_2": {
        "en-US": "End Time",
        "ko-KR": "종료시간",
        "zh-CHS": "结束时间",
        "zh-CHT": "結束時間",
        "ja-JP": "終了時刻"
    },
    "HISTORY_LIST_HEADER_COL_3": {
        "en-US": "Bet Cash",
        "ko-KR": "베팅 금액",
        "zh-CHS": "投注现金",
        "zh-CHT": "投注現金",
        "ja-JP": "現金ベット"
    },
    "HISTORY_LIST_HEADER_COL_4": {
        "en-US": "Bet Balance",
        "ko-KR": "게임전 잔액",
        "zh-CHS": "投注余额",
        "zh-CHT": "投注餘額",
        "ja-JP": "ベットバランス"
    },
    "HISTORY_LIST_HEADER_COL_5": {
        "en-US": "Win Cash",
        "ko-KR": "승리 금액",
        "zh-CHS": "赢现金",
        "zh-CHT": "贏現金",
        "ja-JP": "賞金"
    },
    "HISTORY_LIST_HEADER_COL_6": {
        "en-US": "Win Balance",
        "ko-KR": "게임후 잔액",
        "zh-CHS": "赢余额",
        "zh-CHT": "贏餘額",
        "ja-JP": "賞金残高"
    },
    "HISTORY_DETAIL_INFO_PLAYER_BET": {
        "en-US": "Player Bet",
        "ko-KR": "플레이어 베팅",
        "zh-CHS": "闲家投注",
        "zh-CHT": "閒家投注",
        "ja-JP": "プレイヤーベット"
    },
    "HISTORY_DETAIL_INFO_BANKER_BET": {
        "en-US": "Banker Bet",
        "ko-KR": "뱅커 베팅",
        "zh-CHS": "庄家投注",
        "zh-CHT": "莊家投注",
        "ja-JP": "バンカーベット"
    },
    "HISTORY_DETAIL_INFO_TIE_BET": {
        "en-US": "Tie Bet",
        "ko-KR": "타이 베팅",
        "zh-CHS": "和局投注",
        "zh-CHT": "和局投注",
        "ja-JP": "タイベット"
    },
    "HISTORY_DETAIL_INFO_TOTAL_WIN": {
        "en-US": "Total Win",
        "ko-KR": "전체 승",
        "zh-CHS": "总盈利",
        "zh-CHT": "總盈利",
        "ja-JP": "配当総額"
    },
    "HISTORY_DETAIL_INFO_DRAGON_BET": {
        "en-US": "Dragon Bet",
        "ko-KR": "드래곤 베팅",
        "zh-CHS": "龙门投注",
        "zh-CHT": "龍門投注",
        "ja-JP": "ドラゴンベット"
    },
    "HISTORY_DETAIL_INFO_TIGER_BET": {
        "en-US": "Tiger Bet",
        "ko-KR": "타이거 베팅",
        "zh-CHS": "虎门投注",
        "zh-CHT": "虎門投注",
        "ja-JP": "タイガーベット"
    },
    "HISTORY_WEB_RESULT_2006": {
        "en-US": "No game log available.",
        "ko-KR": "게임 기록이 존재하지 않습니다.",
        "zh-CHS": "没有可用的游戏日志.",
        "zh-CHT": "沒有可用的遊戲日誌.",
        "ja-JP": "ゲームログがありません."
    },
    "TEMP": {
        "en-US": "만,천,원",
        "ko-KR": "M,K",
        "zh-CHS": "百,千,万,元",
        "zh-CHT": "百，千，萬，元",
        "ja-JP": "百,千,万,元"
    },
    "LOTTO_GAME_COUNT": {
        "en-US": "제 {0}회 당첨 번호",
        "ko-KR": "제 {0}회 당첨 번호",
        "zh-CHS": "제 {0}회 당첨 번호",
        "zh-CHT": "제 {0}中獎號碼",
        "ja-JP": "제 {0}회 당첨 번호"
    },
    "LOTTO_ESTIMATE_WIN_AMOUNT": {
        "en-US": "1등 예상 당첨금",
        "ko-KR": "1등 예상 당첨금",
        "zh-CHS": "1등 예상 당첨금",
        "zh-CHT": "1等 測獎金",
        "ja-JP": "1등 예상 당첨금"
    },
    "LOTTO_JACKPOT": {
        "en-US": "JACKPOT",
        "ko-KR": "JACKPOT",
        "zh-CHS": "JACKPOT",
        "zh-CHT": "JACKPOT",
        "ja-JP": "JACKPOT"
    },
    "COMPLETE": {
        "en-US": "Complete",
        "ko-KR": "Complete",
        "zh-CHS": "Complete",
        "zh-CHT": "Complete",
        "ja-JP": "Complete"
    },
    "HALF_COMPLETE": {
        "en-US": "Half Complete",
        "ko-KR": "Half Complete",
        "zh-CHS": "Half Complete",
        "zh-CHT": "Half Complete",
        "ja-JP": "Half Complete"
    },
    "SAVE_BETS": {
        "en-US": "Save Bets",
        "ko-KR": "저장 베팅",
        "zh-CHS": "保存投注",
        "zh-CHT": "保存投注",
        "ja-JP": "Save Bets"
    },
    "EMPTY_SLOT": {
        "en-US": "Empty Slot",
        "ko-KR": "빈 저장공간",
        "zh-CHS": "空位",
        "zh-CHT": "空位",
        "ja-JP": "Empty Slot"
    },
    "MINUTE": {
        "en-US": "Minute",
        "ko-KR": "분",
        "zh-CHS": "Minute",
        "zh-CHT": "分鐘",
        "ja-JP": "Minute"
    },
    "SECOND": {
        "en-US": "Second",
        "ko-KR": "초",
        "zh-CHS": "第二",
        "zh-CHT": "第二",
        "ja-JP": "Second"
    },
    "TIP": {
        "en-US": "Tip",
        "ko-KR": "팁",
        "zh-CHS": "Tip",
        "zh-CHT": "小費",
        "ja-JP": "Tip"
    },
    "MESSAGE": {
        "en-US": "Message",
        "ko-KR": "메세지",
        "zh-CHS": "信息",
        "zh-CHT": "信息",
        "ja-JP": "Message"
    },
    "e_2line": {
        "en-US": "2 Line",
        "ko-KR": "2 라인",
        "zh-CHS": "2 Line",
        "zh-CHT": "2 行",
        "ja-JP": "2 Line"
    },
    "e_3line": {
        "en-US": "3 Line",
        "ko-KR": "3 라인",
        "zh-CHS": "3 Line",
        "zh-CHT": "3 行",
        "ja-JP": "3 Line"
    },
    "e_4line": {
        "en-US": "4 Line",
        "ko-KR": "4 라인",
        "zh-CHS": "4 Line",
        "zh-CHT": "4 行",
        "ja-JP": "4 Line"
    },
    "e_cheer": {
        "en-US": "Cheer 1",
        "ko-KR": "응원 1",
        "zh-CHS": "欢呼 1",
        "zh-CHT": "歡呼 1",
        "ja-JP": "Cheer 1"
    },
    "e_cheer2": {
        "en-US": "Cheer 2",
        "ko-KR": "응원 2",
        "zh-CHS": "欢呼 2",
        "zh-CHT": "歡呼 2",
        "ja-JP": "Cheer 2"
    },
    "e_fighting": {
        "en-US": "Fighting",
        "ko-KR": "파이팅",
        "zh-CHS": "战斗",
        "zh-CHT": "戰鬥",
        "ja-JP": "Fighting"
    },
    "e_noline": {
        "en-US": "No Line",
        "ko-KR": "노라인",
        "zh-CHS": "没有线",
        "zh-CHT": "通過",
        "ja-JP": "No Line"
    },
    "e_pass": {
        "en-US": "Pass",
        "ko-KR": "패스",
        "zh-CHS": "通过",
        "zh-CHT": "通過",
        "ja-JP": "Pass"
    },
    "e_picture": {
        "en-US": "Picture",
        "ko-KR": "그림",
        "zh-CHS": "图片",
        "zh-CHT": "圖片",
        "ja-JP": "Picture"
    },
    "e_please": {
        "en-US": "Please",
        "ko-KR": "제발",
        "zh-CHS": "请",
        "zh-CHT": "請",
        "ja-JP": "Please"
    },
    "ROOM_CHANGE_DEALER": {
        "en-US": "Dealer Change",
        "ko-KR": "딜러 교체 중",
        "zh-CHS": "换荷官",
        "zh-CHT": "换荷官",
        "ja-JP": "ディーラー交代"
    },
    "ROOM_CHANGE_SHOE": {
        "en-US": "Shoe Change",
        "ko-KR": "슈 교체 중",
        "zh-CHS": "换扑克牌",
        "zh-CHT": "換撲克牌",
        "ja-JP": "カード 交換"
    },
    "Combination": {
        "en-US": "Combination",
        "ko-KR": "조합 선택",
        "zh-CHS": "组合选择",
        "zh-CHT": "組合選擇",
        "ja-JP": "組み合わせ"
    },
    "BonusNum": {
        "en-US": "Bonus Number",
        "ko-KR": "보너스 번호",
        "zh-CHS": "奖金号码",
        "zh-CHT": "獎金號碼",
        "ja-JP": "ボーナス番号"
    },
    "BonusCol": {
        "en-US": "Bonus Colour",
        "ko-KR": "보너스 색상",
        "zh-CHS": "奖金的颜色",
        "zh-CHT": "獎金的顏色",
        "ja-JP": "ボーナスカラー"
    },
    "1stNumber": {
        "en-US": "1st number",
        "ko-KR": "첫번째 번호",
        "zh-CHS": "第一个号码",
        "zh-CHT": "第一個號碼",
        "ja-JP": "第一の数"
    },
    "TotalValue": {
        "en-US": "Total Value",
        "ko-KR": "합산의 수",
        "zh-CHS": "合算",
        "zh-CHT": "合算",
        "ja-JP": "総価値"
    },
    "OddEven": {
        "en-US": "Odd & Even",
        "ko-KR": "홀 짝",
        "zh-CHS": "单双号",
        "zh-CHT": "單雙號",
        "ja-JP": "奇数 ＆ さえ"
    },
    "Hilo": {
        "en-US": "HILO",
        "ko-KR": "업다운",
        "zh-CHS": "高低",
        "zh-CHT": "高低",
        "ja-JP": "高低"
    },
    "IncludeBonusBall": {
        "en-US": "Include Bonus Ball",
        "ko-KR": "보너스공 포함",
        "zh-CHS": "奖金的包括",
        "zh-CHT": "奖金的包括",
        "ja-JP": "ストレート"
    },
    "Single": {
        "en-US": "Single",
        "ko-KR": "싱글",
        "zh-CHS": "单个",
        "zh-CHT": "單個",
        "ja-JP": "ストレ"
    },
    "Double": {
        "en-US": "Double",
        "ko-KR": "더블",
        "zh-CHS": "双倍",
        "zh-CHT": "雙倍",
        "ja-JP": "ダブル"
    },
    "Triple": {
        "en-US": "Triple",
        "ko-KR": "트리플",
        "zh-CHS": "三倍投",
        "zh-CHT": "三倍投",
        "ja-JP": "トリプル"
    },
    "FourFold": {
        "en-US": "FOUR FOLD",
        "ko-KR": "포폴드",
        "zh-CHS": "四倍投",
        "zh-CHT": "四倍投",
        "ja-JP": "トリプル"
    },
    "FiveFold": {
        "en-US": "FIVE FOLD",
        "ko-KR": "파이브폴드",
        "zh-CHS": "五倍投",
        "zh-CHT": "五倍投",
        "ja-JP": "トリプル"
    },
    "HISTORY": {
        "en-US": "History",
        "ko-KR": "이전회차",
        "zh-CHS": "历史",
        "zh-CHT": "歷史",
        "ja-JP": "記録"
    },
    "DrawNumber": {
        "en-US": "WIN NUMBERS",
        "ko-KR": "추첨번호",
        "zh-CHS": "抽奖号码",
        "zh-CHT": "抽獎號碼",
        "ja-JP": "抽選番号"
    },
    "BonusBall": {
        "en-US": "BONUS.B",
        "ko-KR": "보너스볼",
        "zh-CHS": "奖金",
        "zh-CHT": "獎金",
        "ja-JP": "ボーナスボール"
    },
    "HISTORY_ROUND_ROW_TEXT_1": {
        "en-US": "no.$(Val_1)",
        "ko-KR": "$(Val_1)회",
        "zh-CHS": "第$(Val_1)回",
        "zh-CHT": "第$(Val_1)回",
        "ja-JP": "第$(Val_1)回"
    },
    "1-49 NUMBER": {
        "en-US": "1~49 NUMBER",
        "ko-KR": "1~49 번",
        "zh-CHS": "1~49 号码",
        "zh-CHT": "1~49 號碼",
        "ja-JP": "1~49 号码"
    },
    "times": {
        "en-US": "No.",
        "ko-KR": "번대",
        "zh-CHS": "范畴",
        "zh-CHT": "範疇",
        "ja-JP": "范畴"
    },
    "HOT NUMBER": {
        "en-US": "HOT NUMBER",
        "ko-KR": "좋은 번호",
        "zh-CHS": "好的号码",
        "zh-CHT": "熱門號碼",
        "ja-JP": "ホットナンバー"
    },
    "COLD NUMBER": {
        "en-US": "COLD NUMBER",
        "ko-KR": "나쁜 번호",
        "zh-CHS": "坏的号码",
        "zh-CHT": "冷門號碼",
        "ja-JP": "コールドナンバー"
    },
    "TIMER_TEXT_1": {
        "en-US": "Next draw in",
        "ko-KR": "다음 추첨까지",
        "zh-CHS": "旁边的彩票",
        "zh-CHT": "接下來的抽獎",
        "ja-JP": "次の抽選まで"
    },
    "TIMER_TEXT_2": {
        "en-US": "",
        "ko-KR": "남았습니다",
        "zh-CHS": "保持",
        "zh-CHT": "保持",
        "ja-JP": "残りました"
    },
    "RESULT_TEXT_1": {
        "en-US": "MAIN BALL's",
        "ko-KR": "일반볼",
        "zh-CHS": "一般的球",
        "zh-CHT": "主要滾珠",
        "ja-JP": "一般的なボール"
    },
    "PURCHASE": {
        "en-US": "PURCHASE",
        "ko-KR": "구매내역",
        "zh-CHS": "购买明细",
        "zh-CHT": "購買明細",
        "ja-JP": "購入履歴"
    },
    "LOSE": {
        "en-US": "LOSE",
        "ko-KR": "패배",
        "zh-CHS": "落",
        "zh-CHT": "落",
        "ja-JP": "外れ"
    },
    "BetPad": {
        "en-US": "BET SLIP",
        "ko-KR": "배팅 패드",
        "zh-CHS": "操作板",
        "zh-CHT": "操作板",
        "ja-JP": "バッティングパッド"
    },
    "RESET": {
        "en-US": "RESET",
        "ko-KR": "초기화",
        "zh-CHS": "删除",
        "zh-CHT": "删除",
        "ja-JP": "クリア"
    },
    "AUTO": {
        "en-US": "AUTO",
        "ko-KR": "자동 선택",
        "zh-CHS": "自动选择",
        "zh-CHT": "自動選擇",
        "ja-JP": "自動選択"
    },
    "PAD_ORDINAL_BALL": {
        "en-US": "%Val_1%st BALL",
        "ko-KR": "%Val_1%번볼",
        "zh-CHS": "第%Val_1%个号码",
        "zh-CHT": "第%Val_1%个號碼",
        "ja-JP": "第%Val_1%个号码"
    },
    "PAD_HILO_TOP_1": {
        "en-US": "25 & OVER",
        "ko-KR": "25 이상",
        "zh-CHS": "以上 25",
        "zh-CHT": "以上 25",
        "ja-JP": "以上 25"
    },
    "PAD_HILO_TOP_2": {
        "en-US": "UNDER 25",
        "ko-KR": "25 이하",
        "zh-CHS": "以下 25",
        "zh-CHT": "以下 25",
        "ja-JP": "以下 25"
    },
    "EVEN": {
        "en-US": "EVEN",
        "ko-KR": "짝",
        "zh-CHS": "双",
        "zh-CHT": "雙",
        "ja-JP": "偶数"
    },
    "ODD": {
        "en-US": "ODD",
        "ko-KR": "홀",
        "zh-CHS": "单",
        "zh-CHT": "單",
        "ja-JP": "奇数"
    },
    "HIGH": {
        "en-US": "HIGH",
        "ko-KR": "높음",
        "zh-CHS": "高",
        "zh-CHT": "高",
        "ja-JP": "高い"
    },
    "LOW": {
        "en-US": "LOW",
        "ko-KR": "낮음",
        "zh-CHS": "低",
        "zh-CHT": "低",
        "ja-JP": "低い"
    },
    "Lottery_InProgress": {
        "en-US": "IN PROGRESS",
        "ko-KR": "추첨중",
        "zh-CHS": "抽签中",
        "zh-CHT": "抽籤中",
        "ja-JP": "抽選の"
    },
    "Lottery_Win": {
        "en-US": "WIN",
        "ko-KR": "당첨",
        "zh-CHS": "中奖",
        "zh-CHT": "中獎",
        "ja-JP": "当選"
    },
    "CONGRATULATION": {
        "en-US": "CONGRATULATION",
        "ko-KR": "축하합니다",
        "zh-CHS": "恭喜恭喜",
        "zh-CHT": "恭喜恭喜",
        "ja-JP": "おめでとうございます"
    },
    "PAD_TIP": {
        "en-US": "Tip",
        "ko-KR": "안내",
        "zh-CHS": "小费",
        "zh-CHT": "尖",
        "ja-JP": "ッヒント"
    },
    "LINE": {
        "en-US": "Line",
        "ko-KR": "라인",
        "zh-CHS": "线",
        "zh-CHT": "线",
        "ja-JP": "Line"
    },
    "LEFT": {
        "en-US": "Left",
        "ko-KR": "좌",
        "zh-CHS": "左",
        "zh-CHT": "左",
        "ja-JP": "Left"
    },
    "RIGHT": {
        "en-US": "Right",
        "ko-KR": "우",
        "zh-CHS": "右",
        "zh-CHT": "右",
        "ja-JP": "Right"
    },
    "StartBet": {
        "en-US": "Start",
        "ko-KR": "시작",
        "zh-CHS": "开始",
        "zh-CHT": "開始",
        "ja-JP": "Start"
    },
    "FinishBet": {
        "en-US": "Finish",
        "ko-KR": "도착",
        "zh-CHS": "結束",
        "zh-CHT": "结束",
        "ja-JP": "Finish"
    },
    "LineBet": {
        "en-US": "Line",
        "ko-KR": "라인",
        "zh-CHS": "线",
        "zh-CHT": "线",
        "ja-JP": "Line"
    },
    "ComboBet": {
        "en-US": "Combo",
        "ko-KR": "조합",
        "zh-CHS": "组合",
        "zh-CHT": "組合",
        "ja-JP": "Combo"
    },
    "HALF": {
        "en-US": "Half",
        "ko-KR": "하프",
        "zh-CHS": "一半",
        "zh-CHT": "一半",
        "ja-JP": "Half"
    },
    "Goal": {
        "en-US": "Goal",
        "ko-KR": "골인",
        "zh-CHS": "进球",
        "zh-CHT": "进球",
        "ja-JP": "Goal"
    },
    "NoGoal": {
        "en-US": "No Goal",
        "ko-KR": "노골",
        "zh-CHS": "没有进球",
        "zh-CHT": "没有进球",
        "ja-JP": "No Goal"
    },
    "Kicker": {
        "en-US": "Kicker",
        "ko-KR": "키커",
        "zh-CHS": "踢球者",
        "zh-CHT": "踢球者",
        "ja-JP": "Kicker"
    },
    "GoalKicker": {
        "en-US": "Goal Keeper",
        "ko-KR": "골키퍼",
        "zh-CHS": "守门员",
        "zh-CHT": "守門員",
        "ja-JP": "Goal Kicker"
    },
    "MINI_LADDER_TAB": {
        "en-US": "LADDER<br>Sports games",
        "ko-KR": "사다리<br>스포츠 게임",
        "zh-CHS": "梯子<br>体育游戏",
        "zh-CHT": "梯子<br>體育遊戲",
        "ja-JP": "はしご<br>スポーツゲーム"
    },
    "LadderBaseballGame": {
        "en-US": "Ladder Baseball",
        "ko-KR": "사다리 야구",
        "zh-CHS": "阶梯棒球",
        "zh-CHT": "階梯棒球",
        "ja-JP": "Ladder Baseball"
    },
    "LadderBasketballGame": {
        "en-US": "Ladder Basketball",
        "ko-KR": "사다리 농구",
        "zh-CHS": "阶梯篮球",
        "zh-CHT": "階梯籃球",
        "ja-JP": "Ladder Baseketball"
    },
    "LadderSoccerGame": {
        "en-US": "Ladder Football",
        "ko-KR": "사다리 축구",
        "zh-CHS": "阶梯足球",
        "zh-CHT": "階梯足球",
        "ja-JP": "Ladder Football"
    },
    "RESULT": {
        "en-US": "Result",
        "ko-KR": "결과",
        "zh-CHS": "赛果",
        "zh-CHT": "賽果",
        "ja-JP": "Result"
    },
    "YEAR": {
        "en-US": "{0}.",
        "ko-KR": "{0}년",
        "zh-CHS": "{0}年份",
        "zh-CHT": "{0}年份",
        "ja-JP": "{0}."
    },
    "YEAR_MONTH_DATE": {
        "en-US": "{2}.{1}.{0}",
        "ko-KR": "{0}년 {1}월 {2}일",
        "zh-CHS": "{2}年份{1}月份{0}日期",
        "zh-CHT": "{2}年份{1}月份{0}日期",
        "ja-JP": "{2}.{1}.{0}"
    },
    "MONTH_DATE": {
        "en-US": "{0}.{1}",
        "ko-KR": "{0}월 {1}일",
        "zh-CHS": "{0}月份{1}日期",
        "zh-CHT": "{0}月份{1}日期",
        "ja-JP": "{0}.{1}"
    },
    "REMAIN_TIME": {
        "en-US": "Remain Time",
        "ko-KR": "남은 시간",
        "zh-CHS": "剩余时间",
        "zh-CHT": "剩餘時間",
        "ja-JP": "Remain Time"
    },
    "PATTERN": {
        "en-US": "Pattern",
        "ko-KR": "패턴",
        "zh-CHS": "模式",
        "zh-CHT": "模式",
        "ja-JP": "Pattern"
    },
    "CURRENT_BET_HISTORY": {
        "en-US": "Current Bet History",
        "ko-KR": "현재 베팅 내역",
        "zh-CHS": "目前的彩票记录",
        "zh-CHT": "目前的彩票記錄",
        "ja-JP": "Current Bet History"
    },
    "TYPE": {
        "en-US": "Type",
        "ko-KR": "종류",
        "zh-CHS": "样别",
        "zh-CHT": "樣别",
        "ja-JP": "Type"
    },
    "DETAIL": {
        "en-US": "Detail",
        "ko-KR": "자세히",
        "zh-CHS": "细节",
        "zh-CHT": "細節",
        "ja-JP": "Detail"
    },
    "AMOUNT": {
        "en-US": "Amount",
        "ko-KR": "금액",
        "zh-CHS": "金额",
        "zh-CHT": "金額",
        "ja-JP": "Amount"
    },
    "EXPECTED_DIVIDED": {
        "en-US": "Expected Dividend",
        "ko-KR": "예상 배당률",
        "zh-CHS": "预期收益率",
        "zh-CHT": "預期收益率",
        "ja-JP": "Expected Dividend"
    },
    "DIVIDEND": {
        "en-US": "Dividend",
        "ko-KR": "배당",
        "zh-CHS": "分配",
        "zh-CHT": "分配",
        "ja-JP": "Dividend"
    },
    "EXPECTED_AMOUNTS": {
        "en-US": "Expected Amounts",
        "ko-KR": "예상 배당금액",
        "zh-CHS": "预期金额",
        "zh-CHT": "預期金額",
        "ja-JP": "Expected Amounts"
    },
    "WAITING": {
        "en-US": "Waiting",
        "ko-KR": "대기중",
        "zh-CHS": "等待",
        "zh-CHT": "等待",
        "ja-JP": "Waiting"
    },
    "LADDER_ROUND": {
        "en-US": "No.{0}",
        "ko-KR": "{0}회차",
        "zh-CHS": "{0}循环",
        "zh-CHT": "{0}循環",
        "ja-JP": "No.{0}"
    },
    "BET_RATIO": {
        "en-US": "Bet Ratio",
        "ko-KR": "구매 분포",
        "zh-CHS": "投注比率",
        "zh-CHT": "投注比率",
        "ja-JP": "Bet Ratio"
    },
    "INFO": {
        "en-US": "Info",
        "ko-KR": "정보",
        "zh-CHS": "信息",
        "zh-CHT": "信息",
        "ja-JP": "Info"
    },
    "SERVER_TIME": {
        "en-US": "Server Time",
        "ko-KR": "서버 시간",
        "zh-CHS": "服务器时间",
        "zh-CHT": "服務器時間",
        "ja-JP": "Server Time"
    },
    "AFTER_MIN_SEC": {
        "en-US": "{0}m {1} seconds",
        "ko-KR": "{0}분 {1} 초 후",
        "zh-CHS": "{0}分钟 {1} 秒数",
        "zh-CHT": "{0}分鐘 {1} 秒数",
        "ja-JP": "{0}m {1} seconds"
    },
    "AFTER_SEC": {
        "en-US": "{0} seconds",
        "ko-KR": "{0} 초 후",
        "zh-CHS": "{0} 秒数",
        "zh-CHT": "{0} 秒数",
        "ja-JP": "{0} seconds"
    },
    "AFTER_SIMPLE_SEC": {
        "en-US": "{0}s",
        "ko-KR": "{0}초 후",
        "zh-CHS": "{0}秒数",
        "zh-CHT": "{0}秒数",
        "ja-JP": "{0}s"
    },
    "START_TIME_FULL_DATE": {
        "en-US": "{0}.{1}-{2}:{3}:{4}",
        "ko-KR": "{0}월{1}일-{2}:{3}:{4}",
        "zh-CHS": "{0}月{1}天{2}:{3}]:{4}",
        "zh-CHT": "{0}月{1}天-{2}:{3}:{4}",
        "ja-JP": "{0}.{1}-{2}:{3}:{4}"
    },
    "SUM": {
        "en-US": "Total",
        "ko-KR": "합계",
        "zh-CHS": "总额",
        "zh-CHT": "總額",
        "ja-JP": "Total"
    },
    "GAME_RESULT": {
        "en-US": "Game Result",
        "ko-KR": "게임 결과",
        "zh-CHS": "赛果",
        "zh-CHT": "賽果",
        "ja-JP": "Game Result"
    },
    "ALL_IN": {
        "en-US": "All In",
        "ko-KR": "올인",
        "zh-CHS": "下全注",
        "zh-CHT": "下全注",
        "ja-JP": "All In"
    },
    "LADDER_HISTORY_TOP_INFO_DETAIL": {
        "en-US": "no.{0} ( {1}% ) {2}straight",
        "ko-KR": "{0}번 ( {1}% ) {2}연속",
        "zh-CHS": "{0}时间 ( {1}% ) {2}直行",
        "zh-CHT": "{0}時間 ( {1}% ) {2}直行",
        "ja-JP": "no.{0} ( {1}% ) {2}straight"
    },
    "LADDER_HISTORY_TOP_INFO_SIMPLE": {
        "en-US": "no.{0}",
        "ko-KR": "{0}번",
        "zh-CHS": "{0}时间",
        "zh-CHT": "{0}時間",
        "ja-JP": "no.{0}"
    }
}