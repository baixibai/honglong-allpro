const fs = require("fs");
let game = require("./game.js");
let system = require("./system.js");
let ui = require("./ui.js");
let video = require("./video.js");

let lang = {};

["en-US", "ko-KR", "zh-CHS", "zh-CHT", "ja-JP"].forEach(el => {
    if (!lang[el]) {
        lang[el] = {};
    }
    for (let a in game) {
        lang[el][a] = game[a][el];
    }

    for (let b in system) {
        lang[el][b] = system[b][el];
    }

    for (let c in ui) {
        lang[el][c] = ui[c][el];
    }

    for (let d in video) {
        lang[el][d] = video[d][el];
    }

    fs.writeFile(`../${el}.json`, JSON.stringify(lang[el], "", 4), "utf8", err => {
        if (err) return console.log(err);
        console.log(`${el} is ok!`);
    });
});