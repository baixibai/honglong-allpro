const _baseUrl = '/'
export default {
	// 套餐列表
	goodquery () {
		return _baseUrl + 'wap/good/query'
	},
	// 相册
	albumquery () {
		return _baseUrl + 'wap/album/query'
	},
	// 登录
	login () {
		return _baseUrl + 'wap/user/login'
	},
	// 登录判断
	login_session () {
		return _baseUrl + 'wap/user/session'
	},
	// 推荐列表
	relationquery () {
		return _baseUrl + 'wap/relation/query'
	},
	// 积分列表
	scorequery () {
		return _baseUrl + 'wap/score/query'
	},
	// 积分
	scoreinfo() {
		return _baseUrl + 'wap/score/type'
	},
	// 交易明细
	tradequery() {
		return _baseUrl + 'wap/bill/query'
	},
	// 砍价列表
	bargainquery() {
		return _baseUrl + 'wap/order/query'
	},
	// 砍价排行榜
	bargainmax() {
		return _baseUrl + 'wap/bargain/query'
	},
	// 砍价
	cutprice() {
		return _baseUrl + 'wap/order/bargain'
	},
	// 套餐详情
	getgood() {
		return _baseUrl + 'wap/good/get'
	},
	// 优惠券列表
	couponquery() {
		return _baseUrl + 'wap/coupon/query'
	},
	// 优惠券详情
	couponget() {
		return _baseUrl + 'wap/coupon/get'
	},
	// 创建相册
	albumadd() {
		return _baseUrl + 'wap/album/add'
	},
	// 相册详情
	albumget() {
		return _baseUrl + 'wap/album/get'
	},
	// 砍价下单
	orderadd() {
		return _baseUrl + 'wap/order/add'
	},
	// 订单详情
	orderget() {
		return _baseUrl + 'wap/order/get'
	},
	// 编辑相册
	editalbum() {
		return _baseUrl + 'wap/album/edit'
	},
	// 删除图片
	albumpicdel() {
		return _baseUrl + 'wap/album/picdel'
	},
	// 微信sdk
	jssdk() {
		return _baseUrl + 'wap/common/js_sdk4'
	},
	// 用户信息
	userinfo() {
		return _baseUrl + 'wap/user/info'
	},
	// 领取券
	getcoupon() {
		return _baseUrl + 'wap/bargain/remark'
	},
	// 发送验证码
	sendsms() {
		return _baseUrl + 'wap/common/sendsms'
	},
	// 激活用户
	bindmobile() {
		return _baseUrl + 'wap/user/bindmobile'
	},
	// 相册地址列表
	addressquery() {
		return _baseUrl + 'wap/address/query'
	},
	// 删除图像
	delalbum() {
		return _baseUrl + 'wap/album/del'
	},
	// 订单分享
	ordershare() {
		return _baseUrl + 'wap/order/share'
	},
}
