<template>
    <div>
		<div class="ablummenu">
			<div class="mautobox">
				<!--<img  src="res/images/barbtnhead.png" />-->
				<span>编辑相册</span>
			</div>
		</div>
		<div class="ablumadd">
			<div class="input">
				<span class="lable">相册名称</span>
				<input type="text" class="text" v-model="albumname"  placeholder="编辑名称" />
			</div>
			<div class="input">
				<span class="lable">相册描述</span>
				<textarea class="textarea" placeholder="编辑对于相册的情感描述......"  v-model="description" />
			</div>
			<div class="input">
				<span class="lablel">我的照片</span>
				<span class="labler">{{imglist.length}}/8</span>
			</div>
			<div class="imgup">
				<a class="acl" :style="{width:boxwidth+'px',height:boxwidth+'px'}" @click="reupimg(index)" v-for="(item,index) in imglist">
					<img v-bind:src="item" />
				</a>
				<a v-show="imglist.length<9" class="acl" :style="{width:boxwidth+'px',height:boxwidth+'px'}" @click="upimg()">
					<i :style="{lineHeight:boxwidth+'px'}" class="iconfont icon-tianjia"></i>
				</a>
			</div>
			<div class="input">  
				<span class="lable">背景音乐</span>
				<input type="text" class="text"  placeholder="http://" v-model="music"/>
			</div>
			<div class="input">
				<span class="lable">效果展示</span>
				<select class="select" v-model="selected">
				  <option v-for="option in options" v-bind:value="option.value">
						{{ option.text }}
				  </option>
				</select>
			</div>
			<div class="input">
				<span class="lable">地点</span>
				<select class="select" v-model="selectaddress">
				  <option v-for="address in addressquery" v-bind:value="address.id">
					{{ address.address }}
				  </option>
				</select>
			</div>
			<div class="input">
				<span class="lable">类别</span>
				<select class="select" v-model="selecttype">
					<option value ="1">婚纱摄影</option>
				    <option value ="2">写真/亲子</option>
				    <option value ="3">海外婚礼</option>
				    <option value ="0">其他</option>
				</select>
			</div>
			<div class="btnsave">
				<a class="btn150" @click="editalbum()">保存</a>
			</div>
		</div>
    </div>
</template>
<style scoped>
@import '../../res/style/css/home.css?v=1884';
</style>
<script>
    import api from '../api'
	
    export default {
        data() {
            return {
				boxwidth:0,
				boxheight:0,
				albumquery:'',
				albumname:'',
				music:'http://',
				description:'',
				mediaid:[],
				albumget:'',
				modelid:'saab',
				imglist:[],
				serverlist:[],
				selected:'1',
				options: [
				  { text: '上下滑动', value: '1' },
				  { text: '左右滑动', value: '2' },
				  { text: '上下平铺', value: '3' }
				],
				selectaddress:'1',
				selecttype:'1',
				addressquery:[]
            };
        },
		created () {
			
		},
		mounted(){
			this.boxwidth = (window.screen.width - 35 ) / 4;
			let self = this;
			//相册地址列表
			$.post(api.addressquery(),function(res){
				if(res.errcode==0){
					self.addressquery = res.data;
				}else{
					self.$utils.errcode(res,self)
				}
			});
			$.post(api.albumget(),{id : this.$route.query.id},function(res){
				if(res.errcode==0){
					self.albumget = res.data;
					self.albumname = res.data.name;
					self.description = res.data.description;
					self.music = res.data.music;
					self.selected = res.data.modelid;
					self.selectaddress = res.data.addressid;
					self.selecttype = res.data.type;
				}else{
					self.$utils.errcode(res,self)
				}
			});
			let links = window.location.protocol + '//' + window.location.hostname+'/webapp/#/index?openid='+localStorage.getItem('openid');
			let obj = {shareTit:'途美婚纱全球旅拍',shareCover:window.location.protocol + '//' + window.location.hostname+'/res/images/cents1.png', shareDes:'拍满意才付款，婚纱照写真亲子照找途美旅拍',shareUri:links};
			self.$Wx.initWechat(obj);
        },
		methods:{
			editalbum(){
				let self=this;
				let albumname = this.albumname.trim();
				let music = this.music.trim();
				let description = this.description.trim();
				$.post(api.editalbum(),{id:self.$route.query.id,name :this.albumname,description:description,music:music,mediaid:self.serverlist,modelid:self.selected,addressid:self.selectaddress,type:self.selecttype},function(res){
					if(res.errcode==0){
						self.$router.push({path: '/albuminfo',query: { id: self.$route.query.id}})
					}else{
						self.$utils.errcode(res,self)
					}
				});
			},
			//--上传图片
			upimg(){
				let self = this;
				if(self.imglist.length < 8){
					self.$Wx.chooseImage((res)=>{
						let imglist = self.imglist
						let serverlist = self.serverlist
						imglist.push(res.localIds)				
						serverlist.push(res.serverId)				
					})
				}
			},
			//--替换图片
			reupimg(i){
				let self = this
				if(self.imglist.length < 8){
					self.$Wx.chooseImage((res)=>{
						let imglist = self.imglist
						imglist[i]=res.localIds				
					})
				}
			}
		}
    }
</script>