<template>
    <div>
		<div class="footmenu">
			<div class="menuchild" style="width:50%;">
				<router-link to="/home">
					<p class="pt5top"><i class="iconfont icon-denglu"></i></p>
					<p>会员中心</p>
				</router-link>
			</div>
			<div class="menuchild" style="width:50%;">
				<router-link to="/index">
					<p class="pt5top"><i class="iconfont icon-tuijiantaocan" style="font-size:35px;"></i></p>
					<p>首页</p>
				</router-link>
			</div>
		</div>
    </div>
</template>
<script>
    import api from '../api'
	
    export default {
        data() {
            return {
            };
        },
		mounted(){
        },
		methods:{
		}
    }
</script>