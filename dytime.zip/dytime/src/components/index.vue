<template xmlns:v-on="http://www.w3.org/1999/xhtml">
    <div style="background:#F0F0F0;">
		<div class="homemenu">
			<div class="menuchild" v-show="!login_status">
				<a @click="scroll('#login')">
					<p class="pt5top"><i class="iconfont icon-denglu"></i></p>
					<p>会员激活</p>
				</a>
			</div>
			<div class="menuchild" v-show="login_status">
				<router-link to="/home">
					<p class="pt5top"><i class="iconfont icon-denglu"></i></p>
					<p>会员中心</p>
				</router-link>
			</div>
			<div class="menuchild">
				<a @click="scroll('#news')">
					<p class="pt5top"><i class="iconfont icon-youhuigonggao" style="font-size:35px;"></i></p>
					<p>活动公告</p>
				</a>
			</div>
			<div class="menuchild">
				<router-link to="/packagelist">
					<p class="pt5top"><i class="iconfont icon-tuijiantaocan" style="font-size:35px;"></i></p>
					<p>推荐套餐</p>
				</a>
			</div>
			<div class="menuchild">
				<a @click="scroll('#content')">
					<p class="pt5top"><i class="iconfont icon-lianxifangshi" style="font-size:30px;"></i></p>
					<p>联系方式</p>
				</a>
			</div>
		</div>
		<div class="imgcont mt60">
			<div class="slide-main" id="touchMain"  :style="{height:heighthalf+'px'}">
				<div class="slide-box" id="slideContent"  :style="{height:heighthalf+'px'}">
					<div class="slide" id="bgstylec"  :style="{height:heighthalf+'px'}">
						<a stat="sslink-3" href="" target="_blank">
							<img :src="$utils.imgurl+'/public/uploads/imghtml/banner1.jpg?x-oss-process=style/w720'"> 
						</a>
					</div>
					<div class="slide" id="bgstylea">
						<a stat="sslink-1" href="" target="_blank">
							<img :src="$utils.imgurl+'/public/uploads/imghtml/banner2.jpg?x-oss-process=style/w720'"> 
						</a>
					</div>
					<div class="slide" id="bgstyleb">
						<a stat="sslink-2" href="" target="_blank">
							<img :src="$utils.imgurl+'/public/uploads/imghtml/banner3.jpg?x-oss-process=style/w720'"> 
						</a>
					</div>
					<div class="slide" id="bgstyleb">
						<a stat="sslink-2" href="" target="_blank">
							<img :src="$utils.imgurl+'/public/uploads/imghtml/banner4.jpg?x-oss-process=style/w720'"> 
						</a>
					</div>
				</div>
				<div class="item"  :style="{top:(heighthalf-30)+'px'}">
					<a class="cur" stat="item1001" href="javascript:;"></a><a href="javascript:;" stat="item1002"></a><a href="javascript:;" stat="item1003"></a>
					<a href="javascript:;" stat="item1004"></a>
				</div>
			</div>
		</div>
		
		<div class="imgcont" style="margin-top: 10px;">
			<img src="res/images/titledesc0.png" />
		</div>
		<div class="imgcont" style="margin-top: 10px;">
			<img src="res/images/custom.jpg" />
		</div>
		<div class="imglist-box" style="padding-top:0px;">
			<div class="imgbox">
				<router-link :to="{ path:'/albumquery', query: { id:  address.id} }" class="imgshow"  v-for="(address,index) in addressquery" v-if="index<9">
					<span>
						<img :src="'res/images/a'+(index+1)+'@2x.png'" alt="">
					</span>
				</router-link>
			</div>
		</div>
		<div class="movebox">
			<div id="banner_box" class="banner_box">
				<div class="banner_list" id="banner_list">
					<div class="page_box show">
						<div class="bg_box"><img src="res/images/guanggao1.png" /></div>
					</div>
					<div class="page_box">
						<div class="bg_box"><img src="res/images/guanggao2.png" /></div>
					</div>
					<div class="page_box  ">
						<div class="bg_box"><img src="res/images/guanggao3.png" /></div>
					</div>
				</div>
			</div>
		</div>
		<div class="imgcont" style="padding:0px 30px;">
			<img src="res/images/titledesc1.png" alt="">
		</div>
		<div class="imglist-box">
			<div class="mallimg">
				<div class="load"  v-show="!loadstatus"><img src="res/images/loading.gif" /></div>
				<router-link :to="{ path:'/packageinfo', query: { id:  good.id} }" class="imgshow" v-for="good in goodquery" >
					<span  :style="{width:boxwidth2+'px'}">
						<img v-bind:src="$utils.imgurl+good.cover+'?x-oss-process=style/w600' || 'res/images/imgdemo.png'" alt="">
					</span>
				</router-link>
			</div>
		</div>
		<div class="imgcont" style="padding:0px 30px;">
			<img src="res/images/titledesc3.png" alt="">
		</div>
		<div class="imglist-box">
			<div class="albumbox">
				<router-link :to="{ path:'/albuminfo', query: { id:  album.id} }" class="albumshow" v-for="album in albumquery.list">
					<span class="spanimg" :style="{width:boxwidth+'px',height:boxheight+'px'}">
						<img  :style="{width:boxwidth+'px',height:boxheight+'px'}" v-bind:src="album.picurl==''?'res/images/imgdemo.png':$utils.imgurl+album.picurl+'?x-oss-process=style/w400h300'" alt="">
						<div class="descbox">
							<p class="p1">{{substr8(album.name)}}</p>
							<p class="p2"><img src="res/images/imgdemo.png" alt=""><span>{{album.piccount+' 张'}}</span></p>
						</div>
					</span>
					<!--<div class="descinfo">
						<span class="readleft"><img src="res/images/imgdemo.png" alt=""><span>{{album.piccount+' 张'}}</span></span>
						<span class="readright"><span>{{album.view}}</span><img src="res/images/readimg.png" alt=""></span>
					</div>-->
				</router-link>
			</div>     
		</div>
		<div class="imgcont"  id="news" name="news" style="padding:0px 30px;">
			<img src="res/images/titledesc4.png" alt="">
		</div>
		<div class="imglist-box">
			<div class="mallimg" style="padding-top:0px;">
				<a class="imgshow">
					<span style="border-radius:0px;">
						<img src="res/images/newact.png" alt="">
					</span>
				</a>
			</div>
		</div>
		<div class="imgcont" style="padding:0px 30px;">
			<img src="res/images/tdjsbg.png" alt="">
		</div>
		<div class="imgcont" style="padding:0px 30px;" v-show="!login_status">
			<img src="res/images/titledesc6.png" alt="">
		</div>
		<div class="loginarea" id="login" name="login" v-show="!login_status">
			<div class="bglogin" style="background:url('res/images/loginbg.png') no-repeat;">
				<div class="inputbox pdt20"><span>手机号</span><input type="tel" name="mobile"  placeholder="请输入手机号" v-model="username" /></div>
				<div class="inputbox pdt10">
					<span>验证码</span>
					<input style="width:80px" type="tel" placeholder="请输入验证码" name="v_code" v-model="code" />
					<a class="codebtn" v-show="!codesta" @click="getcode()">获取验证码</a>
					<a class="codebtn" style="border:1px solid #666;"  v-show="codesta">{{re_code}}</a>
				</div>
				<div class="inputbox pdt10"><a class="btn100 mauto" @click="bindmobile()">激活</a></div>
			</div>
		</div>
		<div class="contentus"  id="content" name="content" style="padding-bottom:30px;">
			<div class="con">
				<i class="iconfont icon-dianhua"></i>
				<div class="phoneinfo">
					<span class="sp1">中国电话：  18106678223</span>
					<span class="sp1">菲律宾电话：09272422290</span>
					<span class="sp1">客服微信：tripmarry2</span>
				</div>
				<!--<div class="priveall" style="float:left;width:110px;">微信：tripmarry2</div>-->
				<img src="res/images/kfewm.jpg" style="width:80px;position:absolute;right:-10px;top:0px;" />
			</div>
		</div>
		<div class="dialog" v-show="dialog">
			<div class="dialogbox-con">{{dialogcontent}}</div>
		</div>
    </div>
</template>
<style>
@import '../../res/style/css/index.css?v=1842';
@import '../../res/style/css/banner.css?v=184';
</style>
<script>
	import api from '../api'
	
    let interval = null;
	
    export default {
        data() {
            return {
				boxwidth:0,
				boxheight:0,
				boxwidth2:0,
				boxheight2:0,
				goodquery:[],
				albumquery:[],
				username: "",
                code: "",
				login_status:true,
				setSms:'',
				re_code:'',
				codesta:false,
				dialogcontent:'',
				dialog:false,
				loadstatus:false,
				addressquery:[],
				heighthalf:0
            };
        },
		created () {
			window.clearInterval(this.setSms);
			this.loadstatus=false;
			
		},
		mounted(){
			this.$utils.banner();
			this.loadstatus=true;
			this.boxwidth = (window.screen.width - 30 ) / 2;
			this.boxheight = (((window.screen.width - 30 ) / 2)*3)/4;
			this.boxwidth2 = (window.screen.width - 20 );
			this.boxheight2 = ((window.screen.width - 20)*3 )/5;
			this.heighthalf = window.screen.width / 2;
			let self =this;
			//套餐列表
			$.post(api.goodquery(),function(res){
				if(res.errcode==0){
					self.goodquery = res.data;			
				}else{
					self.$utils.errcode(res,self)
				}
			});
			//相册列表
			$.post(api.albumquery(),function(res){
				if(res.errcode==0){
					self.albumquery = res.data;
				}else{
					self.$utils.errcode(res,self)
				}
			});
			
			//相册地址列表
			$.post(api.addressquery(),function(res){
				if(res.errcode==0){
					self.addressquery = res.data;
				}else{
					self.$utils.errcode(res,self)
				}
			});
			this.$utils.moveimg();
			this.login_token();
			let links = window.location.protocol + '//' + window.location.hostname+'/webapp/#/index?openid='+localStorage.getItem('openid');
			let obj = {shareTit:'途美婚纱全球旅拍',shareCover:window.location.protocol + '//' + window.location.hostname+'/res/images/cents1.png', shareDes:'拍满意才付款，婚纱照写真亲子照找途美旅拍',shareUri:links};
			self.$Wx.initWechat(obj);
			//self.login();
		},
		methods:{
			moveimg:function(){
				
			},
			substr8:function(value){
				return value.substr(0, 8)
			},
			login: function () {
				let self = this;
				let username = this.username.trim();
                $.post(api.login(),
				{
					mobile: '18681526997',
					password: '123456'
				},function(res){
					if(res.errcode==0){
						
					}else{
						self.$utils.errcode(res,self)
					}
				});
            },
			scroll(id){ 
				var scroll_offset = $(id).offset(); 
				$("body,html").animate({ 
					scrollTop:scroll_offset.top 
				},0); 
			},
			//判断是否激活
			login_token(){
				let self = this;
				$.post(api.login_session(),function(res){
					if(res.errcode==0){
						if(self.$base._.isUndefine(res.data.mobile) || res.data.mobile=='0'){
							self.login_status = false;
						}
					}else{
						self.$utils.errcode(res,self)
					}
				});
			},
			getcode(){
				let time = 60;
				let self=this;
				let username = this.username.trim();
				$.post(api.sendsms(),{mobile:username},function(res){
					if(res.errcode==0){
						self.codesta = true;
						self.re_code='重新获取('+time+'s)';
						self.setSms = setInterval(()=>{
							time--
							self.re_code='重新获取('+time+'s)';
							if(time < 1){
								self.re_code='';
								self.codesta = false;
								window.clearInterval(self.setSms)
							}
						},1000);
					}else{
						self.$utils.errcode(res,self)
					}
				});
			},
			bindmobile(){
				let self = this;
				let username = this.username.trim();
                let code = this.code.trim();
				let val = self.$base.GetName( [ 'mobile' ,'v_code'] )
				self.$base.Vaild({
					data	: val,
					rule	: {
						mobile : 'mobile',
						v_code : 'v_code',
					},
					error	: function(err){
						self.$utils.dialogcode(err,self)
					},
					success	: function(data){
						$.post(api.bindmobile(),{
							mobile: username,
							sms_code: code
						},function(res){
							if(res.errcode==0){
								self.$utils.dialogcode('激活成功',self)
								window.clearInterval(self.setSms)
								location.reload();
								self.login_token();
							}else{
								self.$utils.errcode(res,self)
							}
						});
					}
				})
			}
		}
    }
</script>