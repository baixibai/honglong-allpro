<template>
    <div class="bodyall">
		<scorehead></scorehead>
		<footmenu></footmenu>
		<div class="scoremenu">
			<a class="hover" style="text-align:left;padding-left:10px;">砍价记录</a>
		</div>
		<div class="cellscore">
			<div class="h60" @click="tobargain(item.id)" v-for="item in bargainquery" v-show="item.income===scorestatus || scorestatus==='0'">
				<div class="scorechild1"> 
					<b>{{item.good.name}}</b>
					<p>{{"订单号："+item.orderno}}</p>
				</div>
				<div class="scorechild2"> 
					<b style="text-decoration:line-through">{{item.good.price}}</b>
					<p class="fscolor">{{item.nowprice}}</p>
				</div>
			</div>
		</div>
		<div class="dialog" v-show="dialog">
			<div class="dialogbox-con">{{dialogcontent}}</div>
		</div>
    </div>
</template>
<style scoped>
@import '../../res/style/css/home.css?v=1884';
</style>
<script>
    import api from '../api'
	import scorehead from "./scorehead.vue"
	import footmenu from "./footmenu.vue"
	
    export default {
        data() {
            return {
				boxwidth:0,
				boxheight:0,
				bargainquery:'',
				scorestatus:'0',
				dialogcontent:'',
				dialog:false
            };
        },
		components: {
            scorehead,
			footmenu
        },
		mounted(){
			let self =this;
			$.post(api.bargainquery(),function(res){
				if(res.errcode==0){
					self.bargainquery = res.data;
				}else{
					self.$utils.errcode(res,self)
				}
			});
			let links = window.location.protocol + '//' + window.location.hostname+'/webapp/#/index?openid='+localStorage.getItem('openid');
			let obj = {shareTit:'途美婚纱全球旅拍',shareCover:window.location.protocol + '//' + window.location.hostname+'/res/images/cents1.png', shareDes:'拍满意才付款，婚纱照写真亲子照找途美旅拍',shareUri:links};
			self.$Wx.initWechat(obj);
        },
		methods:{
			scoretype(data){
				this.scorestatus=data;
			},
			tobargain(data){
				let self=this;
				self.$router.push({path: '/bargain', query: {id: data}})
			}
		}
    }
</script>