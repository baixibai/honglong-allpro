<template>
    <div>
		<div class="dialog" v-show="dialoglog" style="background-color: rgba(0,0,0,.3);">
			<div class="loginarea" id="login" name="login"  style="margin-top:70px;">
				<div class="bglogin" style="background:url('res/images/loginbg.png') no-repeat;">
					<div class="inputbox pdt20"><span>手机号</span><input type="tel" name="mobile" placeholder="请输入手机号" v-model="username" /></div>
					<div class="inputbox pdt10">
						<span>验证码</span>
						<input style="width:80px" type="tel"  name="v_code"  placeholder="请输入验证码"  v-model="code" />
						<a class="codebtn" v-show="!codesta" @click="getcode()">获取验证码</a>
						<a class="codebtn" style="color:#666;border:1px solid #666;" v-show="codesta">{{re_code}}</a>
					</div>
					<div class="inputbox pdt10"><a class="btn100 mauto" @click="bindmobile()">激活</a></div>
				</div>
			</div>
		</div>
		<div class="dialog" v-show="dialog">
			<div class="dialogbox-con">{{dialogcontent}}</div>
		</div>
    </div>
</template>

<style scoped>
@import '../../res/style/css/home.css?v=184';
</style>
<script>
    import api from '../api'
	
	
    export default {
		props: {
            show: false
		},
        data() {
            return {
				boxwidth:0,
				boxheight:0,
				scorequery:'',
				scorestatus:'0',
				scoreinfo:'',
				dialogcontent:'',
				dialog:false,
				dialoglog:this.show,
				username: "",
                code: "",
				codesta:false,
				re_code:''
            };
        },
		watch: {
            show(val){
                this.dialoglog = val;
            }
        },
		mounted(){
			let self =this;
        },
		methods:{
			login: function () {
				let self = this;
				let username = this.username.trim();
                let password = this.password.trim();
                $.post(api.login(),
				{
					mobile: username,
					password: password
				},function(res){
					if(res.errcode==0){
						self.dialog = false;
					}else{
						//self.$utils.errcode(res,self)
					}
				});
            },
			getcode(){
				let time = 60;
				let self=this;
				let username = this.username.trim();
				$.post(api.sendsms(),{mobile:username},function(res){
					if(res.errcode==0){
						self.codesta = true;
						self.re_code='重新获取('+time+'s)';
						self.setSms = setInterval(()=>{
							time--
							self.re_code='重新获取('+time+'s)';
							if(time < 1){
								self.re_code='';
								self.codesta = false;
								window.clearInterval(self.setSms)
							}
						},1000);
					}else{
						self.$utils.errcode(res,self)
					}
				});
			},
			bindmobile(){
				let self = this;
				self.dialoglog=false;
				let username = this.username.trim();
                let code = this.code.trim();
				let val = self.$base.GetName( [ 'mobile' ,'v_code'] );
				self.$base.Vaild({
					data	: val,
					rule	: {
						mobile : 'mobile',
						v_code : 'v_code',
					},
					error	: function(err){
						self.$utils.dialogcode(err,self)
					},
					success	: function(data){
						$.post(api.bindmobile(),{
							mobile: username,
							sms_code: code
						},function(res){
							if(res.errcode==0){
								self.$utils.dialogcode('激活成功',self);
								window.clearInterval(self.setSms);
								self.login_token();
							}else{
								self.$utils.errcode(res,self)
							}
						});
					}
				})
				
			}
		}
    }
</script>