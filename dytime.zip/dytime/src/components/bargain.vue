<template xmlns:v-on="http://www.w3.org/1999/xhtml">
    <div class="bodyall">
		<div class="barimgcont" style="min-height:200px;">
			<img :src="$utils.imgurl+getgoodpic+'?x-oss-process=style/w720'" alt="">
			<a class="btnbar" @click="cutprice()" style="background:url(res/images/barbtn.png) no-repeat;background-size:100%;"></a>
			<div class="sendbox" style="margin-top:40px;">
				<h2>Hi,你的好友要去途美婚纱全球旅拍拍婚纱照</h2>
				<h2>快来帮他砍价吧</h2>
				<!--<h3>（砍价后即可获得）</h3>
				<div class="jlco">『价值100元优惠券』</div>-->
				<h1>￥{{orderget.nowprice}}</h1>
			</div>
		</div>
		<div class="imgcont" style="padding:20px 20px;">
			<img src="res/images/bardes.png" alt="">
		</div>
		<div class="titlebox">
			<div class="mautobox">
				<img  src="res/images/barbtnicon.png" />
				<span>砍价排行榜</span>
			</div>
		</div>
		<div class="cellbar">
			<div class="h60" v-for="item in bargainmax.list">
				<img class="headimg" :src="item.helperheadimg" />
				<div class="scorechild1"> 
					<b>昵称：{{item.helpername}}</b>
					<p>{{$base.TranTime(item.createtime)}}</p>
				</div>
				<div class="scorechild2">-{{item.bargain}}</div>
			</div>
		</div>
		<div class="dialogmob" v-show="barstatus">
			<div class="dialogbox-con" style="background:#2fa2d7 url(res/images/diagheadbg.png)  no-repeat;background-size:100%;">
				<span class="close" @click="closedialog"><img src="res/images/close.png" style="width:15px;"/></span>
				<div class="title">你帮他砍掉{{cutpricedata.bargain}}元</div>
				<div class="h2 mt20">恭喜你获得由途美婚纱全球旅拍</div>
				<div class="h2">『价值100元优惠券』</div>
				<div class="h3" v-show="login_status">请输入手机号来领取哦</div>
				<div class="input" v-show="login_status"><input type="tel" name="mobile" placeholder="请输入手机号码领取" v-model="mobileno" /></div>
				<div class="input" v-show="login_status">
					<input type="tel" style="width:80px;float:left;" name="v_code" placeholder="输入验证码" v-model="code" />
					<a class="codebtn" v-show="!codesta" @click="getcode()">获取验证码</a>
					<a class="codebtn" style="color:#666;border:1px solid #666;" v-show="codesta">{{re_code}}</a>
				</div>
				<!--<div class="h2">领取成功</div>-->
				<div class="h3">为这对新人送上祝福吧！</div>
				<div class="input"><textarea name="a" placeholder="请输入祝福语" v-model="remark"></div>
				<div class="footer" v-show="login_status"><a class="button" @click="bindmobile()" style="background:url(res/images/lqbtn.png) no-repeat;background-size:100%;"></a></div>
				<div class="footer" v-show="!login_status"><a class="button" @click="getcoupon()" style="background:url(res/images/lqbtn.png) no-repeat;background-size:100%;"></a></div>
			</div>
		</div>
		<div class="dialogmob"  v-show="barsuccess">
			<div class="dialogbox-con" style="background:#2fa2d7 url(res/images/diagheadbg.png)  no-repeat;background-size:100%;top:20%;">
				<span class="close" @click="closesuccesdialog()"><img src="res/images/close.png" style="width:15px;"/></span>
				<div class="title">只能助砍一次</div>
				<div class="h3" style="margin-top:20px;">亲爱的朋友，很感谢您帮TA砍价成功</div>
				<div class="h3">这对新人在这里很感谢你的帮助</div>
				<div class="h2"><img src="res/images/fudai.png" width="70%" /></div>
				<div class="h1">恭喜你！</div>
				<div class="h1" style="height:30px;"></div>
				<!--<div class="h2">『价值100元优惠券』</div>
				<div class="remark">
					<div class="d1">偷偷跑进你的行囊中</div>
					<div class="d1">1.请在订单前出示你的现金券</div>
					<div class="d1">2.现金券只限规定的套系使用</div>
					<div class="d2">注：在法律允许范围内途美婚纱全球旅拍对本次活动享有最终解释权</div>
				</div>-->
			</div>
		</div>
		<div class="dialog" v-show="dialog">
			<div class="dialogbox-con">{{dialogcontent}}</div>
		</div>
		<footmenu></footmenu>
    </div>
</template>
<style scoped>
@import '../../res/style/css/bargain.css';
</style>
<script>
	import api from '../api'
	import footmenu from "./footmenu.vue"
	
    let interval = null;
    export default {
        data() {
            return {
				boxwidth:0,
				boxheight:0,
				bargainmax:'',
				albumquery:[],
				barstatus:false,
				mobileno:'',
				remark:'',
				dialog:false,
				dialogcontent:'',
				barsuccess:false,
				orderget:'',
				login_status:true,
				cutpricedata:'',
				code: "",
				setSms:'',
				re_code:'',
				codesta:false,
				getgoodpic:''
            };
        },
		components: {
			footmenu
        },
		created () {
			this.boxwidth = (window.screen.width - 50 ) / 2;
			this.boxheight = (((window.screen.width - 50 ) / 2)*2)/3;
		},
		mounted(){
			let self =this;
			self.bargainrecord();
			$.post(api.orderget(),{id:self.$route.query.id},function(res){
				if(res.errcode==0){
					self.getgoodpic=res.data.good.pic;
					self.orderget = res.data;
					
				}else{
					self.$utils.errcode(res,self)
				}
			});
			let links = window.location.protocol + '//' + window.location.hostname+'/webapp/#/bargain?id='+this.$route.query.id+'&openid='+localStorage.getItem('openid');
			let obj = {shareTit:'途美婚纱全球旅拍',shareCover:window.location.protocol + '//' + window.location.hostname+'/res/images/cents1.png', shareDes:'我在途美旅拍预约了拍摄，快来帮我砍价吧',shareUri:links,sucShare:self.ordershare};
			self.$Wx.initWechat(obj);
			self.login_token();
        },
		methods:{
			ordershare(){
				let self = this;
				$.post(api.ordershare(),{id:self.$route.query.id},function(res){
					if(res.errcode==0){
						console.log('回调成功');
					}else{
						self.$utils.errcode(res,self)
					}
				});
			},
			opencut(){
				this.barstatus=true;
			},
			cutprice(){
				let self = this;
				$.post(api.cutprice(),{id:self.$route.query.id},function(res){
					if(res.errcode==0){
						self.barstatus=true;
						self.cutpricedata=res.data;
					}else{
						self.$utils.errcode(res,self)
					}
				});
			},
			getcoupon(){
				let self = this;
                let remark = this.remark.trim();
				this.barstatus=true;
				$.post(api.getcoupon(),{id:self.cutpricedata.id,remark:remark},function(res){
					if(res.errcode==0){
						self.bargainrecord();
						self.barstatus=false;
						self.barsuccess = true;
					}else{
						self.$utils.errcode(res,self)
					}
				});
			},
			closedialog(){
				this.barstatus=false;
			},
			closesuccesdialog(){
				this.barsuccess=false;
				this.bargainrecord();
			},
			bargainrecord(){
				let self =this;
				$.post(api.bargainmax(),{oid:self.$route.query.id},function(res){
					if(res.errcode==0){
						self.bargainmax = res.data;
						
					}else{
						self.$utils.errcode(res,self)
					}
				});
			},
			//判断是否登录
			login_token(){
				let self = this;
				$.post(api.login_session(),function(res){
					if(res.errcode==0){
						if(!self.$base._.isUndefine(res.data)){
							if(!self.$base._.isUndefine(res.data.mobile) && res.data.mobile!='0'){
								self.login_status = false;
							}
						}
					}else{
						self.$utils.errcode(res,self)
					}
				});
			},
			getcode(){
				let time = 60;
				let self=this;
				let mobileno = this.mobileno.trim();
				$.post(api.sendsms(),{mobile:mobileno},function(res){
					if(res.errcode==0){
						self.codesta = true;
						self.re_code='重新获取('+time+'s)';
						self.setSms = setInterval(()=>{
							time--
							self.re_code='重新获取('+time+'s)';
							if(time < 1){
								self.re_code='';
								self.codesta = false;
								window.clearInterval(self.setSms)
							}
						},1000);
					}else{
						self.$utils.errcode(res,self)
					}
				});
			},
			bindmobile(){
				let self = this;
				let mobileno = this.mobileno.trim();
                let code = this.code.trim();
				let val = self.$base.GetName( [ 'mobile' ,'v_code'] );
				self.$base.Vaild({
					data	: val,
					rule	: {
						mobile : 'mobile',
						v_code : 'v_code',
					},
					error	: function(err){
						self.$utils.dialogcode(err,self)
					},
					success	: function(data){
						$.post(api.bindmobile(),{
							mobile: mobileno,
							sms_code: code
						},function(res){
							if(res.errcode==0){
								self.getcoupon();
							}else{
								self.$utils.errcode(res,self)
							}
						});
					}
				})
				
			}
		}
    }
</script>