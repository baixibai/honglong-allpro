<template>
    <div>
		<!--<div class="ablummenu">
			<div class="mautobox">
				<img  :src="userinfo.headimg" />
				<span>{{albumget.name}}</span>
				<router-link v-show="editstatus" :to="{ path:'/albumedit', query: { id:  $route.query.id}}" class="editablum">编辑</router-link>
				<router-link :to="{ path:'/albuminfoyl', query: { id:  $route.query.id}}" class="ylablum">自动播放</router-link>
			</div>
		</div>-->
		<!--<div class="cellablum" style="margin-bottom:60px;">
			<a class="ablumbox" v-for="(item,index) in albumget.pic" :style="{width:boxwidth+'px',height:boxwidth+'px'}">
				<img v-bind:src="item.picurl==''?'res/images/imgdemo.png':item.picurl" alt="">
				<i  v-show="editstatus" class="delete iconfont icon-guanbi" @click="deletesub(item.id)"></i>
			</a>
		</div>-->
		<div class="imglist-box" style="background: #fff;">
			<div class="imgwhauto">
				<router-link v-show="editstatus" :to="{ path:'/albumedit', query: { id:  $route.query.id}}" class="editablum">编辑</router-link>
				<router-link v-show="editstatus" :to="{ path:'/albuminfoyl', query: { id:  $route.query.id}}" class="ylablum">自动播放</router-link>
				<a v-show="editstatus" @click="delalbumdialog()" class="delablum">删除相册</a>
				<img src="res/images/albumhead.png" alt="">
			</div>
			<div class="albumlistbox" style="padding:10px;">
				<a class="albumshow" v-for="(item,index) in albumget.pic">
					<img class="showimg"  style="margin-bottom:0px;" v-bind:src="$utils.imgurl+item.picurl" alt="">
					<div class="descbox" style="width:30px;right:0px;height:30px;" v-show="editstatus">
						<p class="p3"><i class="delete iconfont icon-guanbi" @click="deletesub(item.id)"></i></p>
					</div>
				</a>
			</div>  
			<div class="imgwhauto"><img src="res/images/albumfoot.jpg" alt=""></div>			
		</div>
		<!--<div class="returnbox">
			<a @click="goback()">返回相册列表</a>
		</div>-->
		<div class="dialog" v-show="dialog">
			<div class="dialogbox-con">{{dialogcontent}}</div>
		</div>
		<!--<footmenu></footmenu>-->
		<div class="deletip" v-show="deletipstatus">
			<div class="landscapebg"></div> 
			<div class="landscapetip">
				<div class="landcontent">
					<p>是否删除此文件？</p> 
					<a class="confirm" @click="deletesub()">取消</a>
					<a class="confirm" @click="picdel(picid)">删除</a>
				</div>
			</div>
		</div>
		<div class="deletip" v-show="delealbumstatus">
			<div class="landscapebg"></div> 
			<div class="landscapetip">
				<div class="landcontent">
					<p>是否删除此相册？</p> 
					<a class="confirm" @click="cancle()">取消</a>
					<a class="confirm" @click="delalbum()">删除</a>
				</div>
			</div>
		</div>
    </div>
</template>
<style>
@import '../../res/style/css/index.css?v=1842';
@import '../../res/style/css/home.css?v=1884';
</style>
<script>
    import api from '../api'
	import footmenu from "./footmenu.vue"
	
    export default {
        data() {
            return {
				boxwidth:0,
				boxheight:0,
				albumget:'',
				dialog:false,
				dialogcontent:'',
				deletipstatus:false,
				picid:'',
				userinfo:'',
				editstatus:false,
				delealbumstatus:false
            };
        },
		created () {
			
		},
		components: {
			footmenu
        },
		mounted(){
			this.boxwidth = (window.screen.width - 30 ) / 3;
			let self =this;
			self.albumgetfun();
			$.post(api.userinfo(),function(res){
				if(res.errcode==0){
					self.userinfo=res.data;
					
				}else{
					self.$utils.errcode(res,self)
				}
			});
			
			
        },
		methods:{
			delalbum(){
				let self =this;
				this.delealbumstatus=false;
				$.post(api.delalbum(),{id : this.$route.query.id},function(res){
					if(res.errcode==0){
						self.$router.push({path: '/album'})
					}else{
						self.$utils.errcode(res,self)
					}
				})
			},
			cancle(){
				this.delealbumstatus=false;
			},
			delalbumdialog(){
				this.delealbumstatus=true;
			},
			goback(){
				window.history.back();
				location.reload()
			},
			deletesub(id){
				let e = window.event; 
				e.stopPropagation();
				if(!this.deletipstatus){
					this.deletipstatus=true;
					this.picid = id;
				}else{
					this.deletipstatus=false;
				}
			},
			albumgetfun(){
				let self =this;
				$.post(api.albumget(),{id : this.$route.query.id},function(res){
					if(res.errcode==0){
						self.albumget = res.data;
						if(window.sessionStorage.getItem('uid')===res.data.uid){
							self.editstatus=true;
							let links = window.location.protocol + '//' + window.location.hostname+'/webapp/#/albuminfo?id='+self.$route.query.id+'&openid='+localStorage.getItem('openid');
							let obj = {shareTit:'途美婚纱全球旅拍',shareCover:window.location.protocol + '//' + window.location.hostname+'/res/images/cents1.png', shareDes:'给大家分享一下我的照片，途美旅拍作品',shareUri:links};
							self.$Wx.initWechat(obj);
						}else{
							self.editstatus=false;
							let links = window.location.protocol + '//' + window.location.hostname+'/webapp/#/albuminfo?id='+self.$route.query.id+'&openid='+localStorage.getItem('openid');
							let obj = {shareTit:'途美婚纱全球旅拍',shareCover:window.location.protocol + '//' + window.location.hostname+'/res/images/cents1.png', shareDes:'拍满意才付款，途美旅拍最新客照欣赏',shareUri:links};
							self.$Wx.initWechat(obj);
						}
					}else{
						self.$utils.errcode(res,self)
					}
				})
			},
			picdel(id){
				let self=this;
				$.post(api.albumpicdel(),{id : id},function(res){
					if(res.errcode==0){
						self.deletipstatus=false;
						self.albumgetfun();
					}else{
						self.$utils.errcode(res,self)
					}
				});
			},
			viewImg(index,arr){
				let imgArr = []
				arr.map((el)=>{
					imgArr.push(location.protocol + '//' + location.hostname + '/' + el.picurl)
				})
				this.$Wx.viewImg(imgArr[index],imgArr)
			}
		}
    }
</script>