<template>
    <div class="bodyall">
		<div class="contdescbox">
			<div class="title">积分说明</div>
			<div class="content">
			推荐和消费均可获得积分。
			</div>
		</div>
		<footmenu></footmenu>
    </div>
</template>
<style scoped>
@import '../../res/style/css/home.css?v=1884';
</style>
<script>
    import api from '../api'
	import scorehead from "./scorehead.vue"
	import footmenu from "./footmenu.vue"
	
    export default {
        data() {
            return {
				boxwidth:0,
				boxheight:0,
				couponquery:'',
				dialog:false,
				dialogcontent:'',
            };
        },
		components: {
            scorehead,
			footmenu
        },
		mounted(){
			let self =this;
			$.post(api.couponquery(),function(res){
				if(res.errcode==0){
					self.couponquery = res.data;
				}else{
					self.$utils.errcode(res,self)
				}
			});
			let links = window.location.protocol + '//' + window.location.hostname+'/webapp/#/index?openid='+localStorage.getItem('openid');
			let obj = {shareTit:'途美婚纱全球旅拍',shareCover:window.location.protocol + '//' + window.location.hostname+'/res/images/cents1.png', shareDes:'拍满意才付款，婚纱照写真亲子照找途美旅拍',shareUri:links};
			self.$Wx.initWechat(obj);
        },
		methods:{
			tohref(id){
				this.$router.push({name: "couponinfo", query: {id: id}})
			}
		}
    }
</script>