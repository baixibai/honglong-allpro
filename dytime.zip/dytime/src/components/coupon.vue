<template>
    <div style="height:100%;width:100%;background:#e5e5e5;padding-bottom:60px;">
		<div class="couponmenu">
			<a class="hover" style="text-align:left;padding-left:10px;">我的优惠券</a>
		</div>
		<div class="coupon">
			<div class="couponbox" v-for="item in couponquery.list">
				<i class="cimg iconfont icon-youhuiquan" :style="{color:item.status!='0' && item.status!='-2'?'#fff':''}"></i>
				<div class="coupright"> 
					<b>途美婚纱全球旅拍</b>
					<h1>{{item.value}}元{{item.name}}<span v-show="item.status!='0' && item.status!='-2'" style="color:#666;font-size:14px;">(已失效)</span></h1>
					<h2>失效时间：{{$base.TranTime(item.expiretime)}}</h2>
				</div>
			</div>
		</div>
		<div class="dialog" v-show="dialog">
			<div class="dialogbox-con">{{dialogcontent}}</div>
		</div>
		<footmenu></footmenu>
    </div>
</template>
<style scoped>
@import '../../res/style/css/home.css';
</style>
<script>
    import api from '../api'
	import scorehead from "./scorehead.vue"
	import footmenu from "./footmenu.vue"
	
    export default {
        data() {
            return {
				boxwidth:0,
				boxheight:0,
				couponquery:'',
				dialog:false,
				dialogcontent:'',
            };
        },
		components: {
            scorehead,
			footmenu
        },
		mounted(){
			let self =this;
			$.post(api.couponquery(),function(res){
				if(res.errcode==0){
					self.couponquery = res.data;
				}else{
					self.$utils.errcode(res,self)
				}
			});
			let links = window.location.protocol + '//' + window.location.hostname+'/webapp/#/index?openid='+localStorage.getItem('openid');
			let obj = {shareTit:'途美婚纱全球旅拍',shareCover:window.location.protocol + '//' + window.location.hostname+'/res/images/cents1.png', shareDes:'拍满意才付款，婚纱照写真亲子照找途美旅拍',shareUri:links};
			self.$Wx.initWechat(obj);
        },
		methods:{
			tohref(id){
				this.$router.push({name: "couponinfo", query: {id: id}})
			}
		}
    }
</script>