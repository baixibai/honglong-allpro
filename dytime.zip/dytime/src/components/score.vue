<template>
    <div class="bodyall">
		<scorehead></scorehead>
		<footmenu></footmenu>
		<div class="scoremenu">
			<a v-bind:class="scorestatus==='0'?'hover':''" @click="scoretype('0')">全部</a>
			<a v-bind:class="scorestatus==='1'?'hover':''" @click="scoretype('1')">收入</a>
			<a v-bind:class="scorestatus==='-1'?'hover':''" @click="scoretype('-1')">支出</a>
		</div>
		<div class="cellscore">
			<div class="h60" v-for="item in scorequery" v-show="item.income===scorestatus || scorestatus==='0'">
				<div class="scorechild1"> 
					<b>{{item.scorename || '积分'}}</b>
					<p>{{item.memo}}</p>
				</div>
				<div class="scorechild2"> 
					<b>{{$base.TranTime(item.createtime,'yyyy-MM-dd')}}</b>
					<p class="fscolor">{{item.income=='1'?'+':'-'}}{{item.score}}</p>
				</div>
			</div>
		</div>
		<div class="dialog" v-show="dialog">
			<div class="dialogbox-con">{{dialogcontent}}</div>
		</div>
    </div>
</template>
<style scoped>
@import '../../res/style/css/home.css?v=1884';
</style>
<script>
    import api from '../api'
	import scorehead from "./scorehead.vue"
	import footmenu from "./footmenu.vue"
	
    export default {
        data() {
            return {
				boxwidth:0,
				boxheight:0,
				scorequery:'',
				scorestatus:'0',
				dialog:false,
				dialogcontent:'',
            };
        },
		components: {
            scorehead,
			footmenu
        },
		mounted(){
			let self =this;
			$.post(api.scorequery(),function(res){
				if(res.errcode==0){
					self.scorequery = res.data;
				}else{
					self.$utils.errcode(res,self)
				}
			});
			let links = window.location.protocol + '//' + window.location.hostname+'/webapp/#/index?openid='+localStorage.getItem('openid');
			let obj = {shareTit:'途美婚纱全球旅拍',shareCover:window.location.protocol + '//' + window.location.hostname+'/res/images/cents1.png', shareDes:'拍满意才付款，婚纱照写真亲子照找途美旅拍',shareUri:links};
			self.$Wx.initWechat(obj);
        },
		methods:{
			scoretype(data){
				this.scorestatus=data;
			}
		}
    }
</script>