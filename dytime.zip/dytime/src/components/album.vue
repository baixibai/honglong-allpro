<template>
    <div class="bodyall">
		<div class="ablummenu">
			<div class="mautobox">
				<img  :src="userinfo.headimg" />
				<span>{{userinfo.username}}的专属相册</span>
			</div>
		</div>
		<div class="cellablum">
			<router-link to="/albumadd" class="ablumbox" :style="{width:boxwidth+'px',height:boxwidth+'px'}">
				<img src="res/images/addxc.png" />
			</router-link >
			<router-link :to="{ path:'/albuminfo', query: { id:  item.id} }" class="ablumbox" v-for="item in albumquery.list" :style="{width:boxwidth+'px',height:boxwidth+'px'}">
				<img v-bind:src="item.picurl=''?'res/images/imgdemo.png':item.picurl" alt="">
				<span>{{item.name}}</span>
			</router-link>
		</div>
		<div class="dialog" v-show="dialog">
			<div class="dialogbox-con">{{dialogcontent}}</div>
		</div>
		<!--<footmenu></footmenu>-->
    </div>
</template>
<style scoped>
@import '../../res/style/css/home.css?v=184';
</style>
<script>
    import api from '../api'
	import footmenu from "./footmenu.vue"
	
    export default {
        data() {
            return {
				boxwidth:0,
				boxheight:0,
				albumquery:'',
				dialog:false,
				dialogcontent:'',
				userinfo:''
            };
        },
		created () {
			
		},
		components: {
			footmenu
        },
		mounted(){
			this.boxwidth = (window.screen.width - 30 ) / 3;
			let self =this;
			$.post(api.albumquery(),{my : '1'},function(res){
				if(res.errcode==0){
					self.albumquery = res.data;
				}else{
					self.$utils.errcode(res,self)
				}
			});
			
			$.post(api.userinfo(),function(res){
				if(res.errcode==0){
					self.userinfo=res.data;
				}else{
					self.$utils.errcode(res,self)
				}
			});
			let links = window.location.protocol + '//' + window.location.hostname+'/webapp/#/index?openid='+localStorage.getItem('openid');
			let obj = {shareTit:'途美婚纱全球旅拍',shareCover:window.location.protocol + '//' + window.location.hostname+'/res/images/cents1.png', shareDes:'拍满意才付款，婚纱照写真亲子照找途美旅拍',shareUri:links};
			self.$Wx.initWechat(obj);
        },
		methods:{
		}
    }
</script>