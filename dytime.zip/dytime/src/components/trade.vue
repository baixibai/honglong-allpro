<template>
    <div class="bodyall">
		<scorehead></scorehead>
		<footmenu></footmenu>
		<div class="scoremenu">
			<a class="hover" style="text-align:left;padding-left:10px;">交易记录</a>
		</div>
		<div class="cellscore">
			<div class="h60" v-for="item in tradequery">
				<div class="scorechild1"> 
					<b>{{item.remark}}</b>
					<p>{{$base.TranTime(item.createtime)}}</p>
				</div>
				<div class="scorechild2"> 
					<b style="text-decoration:line-through">{{item.before_amount}}</b>
					<p class="fscolor">-{{item.amount}}</p>
				</div>
			</div>
		</div>
		<div class="dialog" v-show="dialog">
			<div class="dialogbox-con">{{dialogcontent}}</div>
		</div>
    </div>
</template>
<style scoped>
@import '../../res/style/css/home.css?v=1884';
</style>
<script>
    import api from '../api'
	import scorehead from "./scorehead.vue"
	import footmenu from "./footmenu.vue"
	
    export default {
        data() {
            return {
				boxwidth:0,
				boxheight:0,
				tradequery:'',
				tradestatus:'0',
				dialog:false,
				dialogcontent:'',
            };
        },
		components: {
            scorehead,
			footmenu
        },
		mounted(){
			let self =this;
			$.post(api.tradequery(),function(res){
				if(res.errcode==0){
					self.tradequery = res.data;
				}else{
					self.$utils.errcode(res,self)
				}
			});
			let links = window.location.protocol + '//' + window.location.hostname+'/webapp/#/index?openid='+localStorage.getItem('openid');
			let obj = {shareTit:'途美婚纱全球旅拍',shareCover:window.location.protocol + '//' + window.location.hostname+'/res/images/cents1.png', shareDes:'拍满意才付款，婚纱照写真亲子照找途美旅拍',shareUri:links};
			self.$Wx.initWechat(obj);
        },
		methods:{
			tradetype(data){
				this.tradestatus=data;
			}
		}
    }
</script>