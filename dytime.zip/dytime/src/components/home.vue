<template>
    <div>
		<scorehead></scorehead>
		<footmenu></footmenu>
		<div class="cellapp-des">
			<router-link to="/score">
				<span class="iconfont icon-jifenmingxi"></span>
				<b>积分明细</b>
			</router-link>
			<router-link to="/trade">
				<span class="iconfont icon-jiaoyimingxi"></span>
				<b>交易明细</b>
			</router-link>
			<router-link to="/bargainrecord">
				<span class="iconfont icon-wodekanjia"></span>
				<b>我的砍价</b>
			</router-link>
			<router-link to="/referral">
				<span class="iconfont icon-tuijian"></span>
				<b>我的推荐</b>
			</router-link>
			<router-link to="/album">
				<span class="iconfont icon-wodexiangce"></span>
				<b>我的相册</b>
			</router-link>
			<router-link to="/coupon">
				<span class="iconfont icon-youhuiquan"></span>
				<b>我的优惠券</b>
			</router-link>
		</div>
		
    </div>
</template>
<style>
@import '../../res/style/css/home.css?v=2017';
</style>
<script>
    import api from '../api'
	import scorehead from "./scorehead.vue"
	import footmenu from "./footmenu.vue"
	
    export default {
        data() {
            return {
				boxwidth:0,
				boxheight:0,
				userinfo:''
            };
        },
		components: {
            scorehead,
			footmenu,
        },
		mounted(){
			let self =this;
			$.post(api.userinfo(),function(res){
				if(res.errcode==0){
					self.userinfo=res;
				}else{
					self.$utils.errcode(res,self)
				}
			});
			let links = window.location.protocol + '//' + window.location.hostname+'/webapp/#/home?openid='+localStorage.getItem('openid');
			let obj = {shareTit:'途美婚纱全球旅拍',shareCover:window.location.protocol + '//' + window.location.hostname+'/res/images/cents1.png', shareDes:'途美婚纱全球旅拍',shareUri:links};
			self.$Wx.initWechat(obj);
        },
    }
</script>