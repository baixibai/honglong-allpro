<template>
    <div class="bodyall">
		<div class="home-cardre">
			<img class="imgicon" :src="userinfo.headimg" />
			<div class="homeinfo">
				<!--<div class="p1"><a class="jfdesc" v-show="editstatus" @click="edittite()">编辑</a><a class="jfdesc" @click="savetite()" v-show="!editstatus">保存</a></div>-->
				<div class="p2">
					<h1>{{userinfo.username}}</h1>
					<h1 v-show="!editstatus"><input type="text"  v-model="username" maxlength="10" /></h1>
					<h2 style="float:right;">积分 {{userinfo.score}}</h2>
				</div>
				<div class="p1"><i class="iconfont icon-hehuoren"></i><h2>途美婚纱合伙人</h2></div>
			</div>
		</div>
		<div class="waymenu">
			<img src="res/images/bzbgimg.png" />
		</div>
		<div class="cellinfo">
			<div class="h80" v-for="item in relationquery.list">
				<img class="imghead" v-bind:src="item.relation.headimg  || 'res/images/demo.png'" />
				<div class="linespan"> 
					<h2>{{"昵称："+item.relation.username}}</h2>
				</div>
				<div class="linespan"> 
					<p>注册时间：{{$base.TranTime(item.createtime)}}</p>
				</div>
			</div>
		</div>
		<div class="dialog" v-show="dialog">
			<div class="dialogbox-con">{{dialogcontent}}</div>
		</div>
		<div class="dialog" v-show="dialog">
			<div class="dialogbox-con">{{dialogcontent}}</div>
		</div>
		<footmenu></footmenu>
    </div>
</template>
<style>
@import '../../res/style/css/referral.css?v=1884';
</style>
<script>
    import api from '../api'
	import footmenu from "./footmenu.vue"
	
    export default {
        data() {
            return {
				boxwidth:0,
				boxheight:0,
				relationquery:'',
				dialog:false,
				dialogcontent:'',
				editstatus:true,
				username:'HI',
				dialog:false,
				dialogcontent:'',
				userinfo:''
            };
        },
		components: {
			footmenu
        },
		mounted(){
			let self =this;
			$.post(api.userinfo(),function(res){
				if(res.errcode==0){
					self.userinfo=res.data;
				}else{
					self.$utils.errcode(res,self)
				}
			});
			$.post(api.relationquery(),function(res){
				if(res.errcode==0){
					self.relationquery = res.data;
				}else{
					self.$utils.errcode(res,self)
				}
			});
			
			
        },
		methods:{
			edittite: function () {
				this.editstatus = false;
            },
			savetite: function () {
				this.editstatus = true;
            },
		}
    }
</script>