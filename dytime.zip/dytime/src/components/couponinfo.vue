<template>
    <div>
		<div class="couponinfo">
			<div class="couponinfobox">
				<div class="couhead">
					<!--<img src="res/images/titledesc7.png" />-->
					<span>{{couponget.remark}}</span>
				</div>
				<div class="pointl"></div>
				<div class="pointr"></div>
				<div class="coucontent">
					<b>途美婚纱全球旅拍</b>
					<h1>{{couponget.value+'元'+couponget.name}}</h1>
				</div>
				<div class="coupondesc">
					<div class="p1">
						<span>使用条件：</span>
						<p>{{couponget.description}}</p>
					</div>
					<div class="p1">
						<span>可用时间：</span>
						<p>{{$base.TranTime(couponget.expiretime,'yyyy-MM-dd')}}之前，周一至周日</p>
					</div>
				</div>
			</div>
		</div>
		<div class="dialog" v-show="dialog">
			<div class="dialogbox-con">{{dialogcontent}}</div>
		</div>
    </div>
</template>
<style scoped>
@import '../../res/style/css/home.css?v=1884';
</style>
<script>
    import api from '../api'
	import scorehead from "./scorehead.vue"
	
    export default {
        data() {
            return {
				boxwidth:0,
				boxheight:0,
				couponget:'',
				dialog:false,
				dialogcontent:'',
            };
        },
		components: {
            scorehead
        },
		mounted(){
			let self =this;
			$.post(api.couponget(),{id:self.$route.query.id},function(res){
				if(res.errcode==0){
					self.couponget = res.data;
				}else{
					self.$utils.errcode(res,self)
				}
			});
			let links = window.location.protocol + '//' + window.location.hostname+'/webapp/#/index?openid='+localStorage.getItem('openid');
			let obj = {shareTit:'途美婚纱全球旅拍',shareCover:window.location.protocol + '//' + window.location.hostname+'/res/images/cents1.png', shareDes:'拍满意才付款，婚纱照写真亲子照找途美旅拍',shareUri:links};
			self.$Wx.initWechat(obj);
        },
		methods:{
		}
    }
</script>