<template>
    <div>
		<div id="dowebok" v-if="modelidstate=='1' || modelidstate=='2'">
			<div class="section" v-if="modelidstate=='1'" v-for="(item,index) in albumget.pic" style="line-height:100%;background:#272A2F;" >
				<img :src="item.picurl" style="width:100%;height:auto;" />
			</div>
			<div class="section" v-if="modelidstate=='2'">
				<div class="slide"  v-for="(item,index) in albumget.pic" style="line-height:100%;background:#272A2F;" >
					<img :src="item.picurl" style="width:100%;height:auto;" />
				</div>
			</div>
		</div>
		<!--<div class="updownbox"  v-if="modelidstate=='3'">
			<div class="imgslide"  v-for="(item,index) in albumget.pic">
				<img :src="$utils.imgurl+item.picurl" style="width:100%;height:auto;" />
			</div>
		</div>-->
		<div id="lanren" style="position:absolute;z-index:1000;">
			<div id="audio-btn" class="on" @click="playmusic()">
				<audio loop="loop" :src="albumget.music" id="media" preload="preload"></audio>
			</div>
		</div>
		<div class="imglist-box"  else>
			<div class="imgwhauto">
				<img src="res/images/albumhead.png" alt="">
			</div>
			<div class="albumlistbox" style="padding:10px;">
				<a class="albumshow" v-for="(item,index) in albumget.pic">
					<img class="showimg"  style="margin-bottom:0px;" v-bind:src="$utils.imgurl+item.picurl" alt="" style="margin-bottom:0px;">
				</a>
			</div>  
			<div class="imgwhauto"><img src="res/images/albumfoot.jpg" alt=""></div>			
		</div>
    </div>
</template>
<style>
@import '../../res/style/css/jquery.fullPage.css?v=1884';
.updownbox{
	width:100%;
	overflow:hidden;
}
.updownbox .imgslide{
	width:100%;
	height:auto;
	margin-right:10px;
}
</style>
<script>
    import api from '../api'
	import footmenu from "./footmenu.vue"
	
    export default {
        data() {
            return {
				boxwidth:0,
				boxheight:0,
				albumget:'',
				dialog:false,
				dialogcontent:'',
				deletipstatus:false,
				picid:'',
				userinfo:'',
				modelidstate:'0',
				playstatus:true
            };
        },
		created () {
			let self =this;
			
		},
		components: {
			footmenu
        },
		watch:{
		},
		mounted(){
			this.boxwidth = (window.screen.width - 30 ) / 3;
			let self =this;
			self.albumgetfun();
			let links = window.location.protocol + '//' + window.location.hostname+'/webapp/#/albuminfoyl?id='+this.$route.query.id+'&openid='+localStorage.getItem('openid');
			let obj = {shareTit:'途美婚纱全球旅拍',shareCover:window.location.protocol + '//' + window.location.hostname+'/res/images/cents1.png', shareDes:'拍满意才付款，途美旅拍最新客照欣赏',shareUri:links};
			self.$Wx.initWechat(obj);
        },
		updated(){
			let self =this;
			self.playmusic();
			if(self.modelidstate!='3'){
				if(self.modelidstate=='1'){
					$(function(){
						$('#dowebok').fullpage({
							sectionsColor: ['#272A2F', '#272A2F', '#272A2F', '#272A2F'],
							'navigation': true,
							continuousVertical: true
						});
					});
				}else{
					$(function(){
						$('#dowebok').fullpage({
							sectionsColor: ['#272A2F', '#272A2F', '#272A2F', '#272A2F']
						});
					});
				}
			}
		},
		methods:{
			deletesub(id){
				let e = window.event; 
				e.stopPropagation();
				if(!this.deletipstatus){
					this.deletipstatus=true;
					this.picid = id;
				}else{
					this.deletipstatus=false;
				}
			},
			albumgetfun(){
				let self =this;
				$.post(api.albumget(),{id : this.$route.query.id},function(res){
					if(res.errcode==0){
						self.albumget = res.data;
						self.modelidstate=res.data.modelid || '1';
					}else{
						self.$utils.errcode(res,self)
					}
				})
			},
			viewImg(index,arr){
				let imgArr = []
				arr.map((el)=>{
					imgArr.push(location.protocol + '//' + location.hostname + '/' + el.picurl)
				})
				this.$Wx.viewImg(imgArr[index],imgArr)
			},
			playmusic(){
				let self =this;
				var audio = $('#media')[0];  
				if(self.playstatus){
					self.playstatus=false;
					audio.play();
					$('#audio-btn').removeClass('off').addClass('on');
					$('#audio-btn').css("background","url(res/images/music_on.png) no-repeat 0 0");
					$('#audio-btn').css("background-size","contain");
				}else{
					self.playstatus=true;
					audio.pause();
					$('#audio-btn').removeClass('on').addClass('off');
					$('#audio-btn').css("background","url(res/images/music_off.png) no-repeat 0 0");
					$('#audio-btn').css("background-size","contain");
				}
			}
		},
		beforeDestroy(){  
			location.reload() 	
		}
    }
</script>