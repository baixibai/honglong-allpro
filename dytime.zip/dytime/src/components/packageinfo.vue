<template xmlns:v-on="http://www.w3.org/1999/xhtml">
    <div style="background:#F0F0F0;">
		<div class="headtop">
			<!--<div class="conbox">
				<h1>{{getgood.name}}</h1>
			</div>-->
			<img :src="$utils.imgurl+getgood.pic+'?x-oss-process=style/w720'" style="width:100%;" />
		</div>
		<!--<div class="photolist">
			<span class="imgshow" :style="{width:boxwidth+'px',height:boxheight+'px'}">
				<img :src="getgood.pic" alt="">
			</span>
		</div>-->
		<div class="imginfobox" style="margin-top:5px;">
			<div class="listspan">
				<table class="kjtable" border="0" width="100%">
				  <tr>
					<th>{{getgood.name}}</th>
					<th></th>
					<th style="text-align:right;padding-right:20px;">{{getgood.price}}元 </th>
				  </tr>
				  <tr>
					<td></td>
					<td></td>
					<td style="text-align:right;padding-right:20px;"><a class="btn90" @click="cutadd()">我要砍价</a></td>
				  </tr>
				</table>
			</div>
		</div>
		<!--<div class="imgcontpi mt10">
			<img src="res/images/loveway.png" alt="">
		</div>-->
		<div class="imginfobox mt10">
			<p class="ltitle">套餐详情<i></i></p>
		</div>
		<div class="content-box" v-html="getgood.description">
			
		</div>
		<div class="imgcontpi" style="text-align:center;">
			<img src="res/images/kfewm.jpg" style="width:160px;" />
			<p style="font-size:14px;">长按添加好友咨询</p>
			<p style="font-size:14px;">微信号:tripmarry2</p>
		</div>
		<div class="dialog" v-show="dialog">
			<div class="dialogbox-con">{{dialogcontent}}</div>
		</div>
		<dialogjh :show="show"></dialogjh>
    </div>
</template>
<style scoped>
@import '../../res/style/css/packageinfo.css';
</style>
<script>
	import api from '../api'
	import dialogjh from "./dialogjh.vue"
	
    let interval = null;
    export default {
        data() {
            return {
				boxwidth:0,
				boxheight:0,
				getgood:'',
				albumquery:[],
				username: "",
                password: "",
				dialog:false,
				dialogcontent:'',
				show:false,
            };
        },
		components: {
            dialogjh
        },
		created () {
			this.boxwidth = (window.screen.width - 20 ) / 3;
			this.boxheight = (((window.screen.width - 20 ) / 3)*2)/3;
		},
		mounted(){
			let self =this;
			$.post(api.getgood(),{id:self.$route.query.id},function(res){
				if(res.errcode==0){
					self.getgood = res.data;
				}else{
					self.$utils.errcode(res,self)
				}
			});
			let links = window.location.protocol + '//' + window.location.hostname+'/webapp/#/packageinfo?id='+self.$route.query.id+'&openid='+localStorage.getItem('openid');
			let obj = {shareTit:'途美婚纱全球旅拍',shareCover:window.location.protocol + '//' + window.location.hostname+'/res/images/cents1.png', shareDes:'拍满意才付款，婚纱照写真亲子照找途美旅拍',shareUri:links};
			self.$Wx.initWechat(obj);
        },
		methods:{
			cutadd(){
				let self =this;
				$.post(api.orderadd(),{gid:self.$route.query.id},function(res){
					if(res.errcode==0){
						self.$router.push({path: '/bargain', query: {id: res.data.id}})
					}else{
						//self.$utils.errcode(res,self)
						self.show = true;
					}
				});
			}
		}
    }
</script>