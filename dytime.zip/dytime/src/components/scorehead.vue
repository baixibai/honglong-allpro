<template>
    <div>
		<div class="home-card">
			<img class="imgicon" src="res/images/jfimg.png" />
			<div class="homeinfo">
				<div class="p1"><h2>我的积分</h2><router-link to="/scoredesc" class="jfdesc">积分说明<i class="iconfont icon-icon-test"></i></router-link></div>
				<div class="p1" style="height:40px;"><h1>{{scoreinfo.totalscore}}</h1></div>
				<div class="p1"><h3>待生效积分 {{scoreinfo.totalscore}} </h3></div>
			</div>
		</div>
		<div class="dialog" v-show="dialog">
			<div class="dialogbox-con">{{dialogcontent}}</div>
		</div>
    </div>
</template>
<style scoped>
@import '../../res/style/css/home.css?v=1884';
</style>
<script>
    import api from '../api'
	
    export default {
        data() {
            return {
				boxwidth:0,
				boxheight:0,
				scorequery:'',
				scorestatus:'0',
				scoreinfo:'',
				dialogcontent:'',
				dialog:false
            };
        },
		mounted(){
			let self =this;
			$.post(api.scoreinfo(),function(res){
				if(res.errcode==0){
					self.scoreinfo = res.data;
				}else{
					self.$utils.errcode(res,self)
				}
			});
        },
		methods:{
		}
    }
</script>