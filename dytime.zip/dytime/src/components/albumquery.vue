<template>
    <div class="bodyall">
		<div class="ablummenu" style="padding:10px;">
			<div class="mautobox">
				<span style="line-height:30px;">途美婚纱全球旅拍</span>
				<p style="color:#fff;font-size:22px;">{{address}}客照欣赏</p>
			</div>
		</div>
		<div class="imglist-box">
			<div class="albumlistbox" style="padding:10px;">
				<router-link :to="{ path:'/albuminfo', query: { id:  item.id} }" class="albumshow" v-for="item in albumquery.list" style="margin-bottom:20px;border: 1px solid #999;">
					<img class="showimg" v-bind:src="$utils.imgurl+item.picurl" alt="">
					<div class="descbox" style="position:relative;background:#fff;color:#333;">
						<p class="p1" style="line-height:30px;font-weight: 600;">{{item.name}}</p>
						<!-- <p class="p2"><img src="res/images/imgdemo.png" alt=""><span>{{item.piccount+' 张'}}</span></p>-->
					</div>
				</router-link>
			</div>     
		</div>
		<div class="dialog" v-show="dialog">
			<div class="dialogbox-con">{{dialogcontent}}</div>
		</div>
		<footmenu></footmenu>
    </div>
</template>
<style>
@import '../../res/style/css/index.css?v=1842';
@import '../../res/style/css/home.css?v=1884';
</style>
<script>
    import api from '../api'
	import footmenu from "./footmenu.vue"
	
    export default {
        data() {
            return {
				boxwidth:0, 
				boxheight:0,
				albumquery:'',
				dialog:false,
				dialogcontent:'',
				userinfo:'',
				address:''
            };
        },
		created () {
			
		},
		components: {
			footmenu
        },
		mounted(){
			this.boxwidth = (window.screen.width - 30 ) / 3;
			let self =this;
			$.post(api.albumquery(),{addressid : this.$route.query.id},function(res){
				if(res.errcode==0){
					self.albumquery = res.data;
					if(res.data.list.length>0){
						self.address = res.data.list[0].address;
					}
				}else{
					self.$utils.errcode(res,self)
				}
			});
			
			$.post(api.userinfo(),function(res){
				if(res.errcode==0){
					self.userinfo=res.data;
				}else{
					self.$utils.errcode(res,self)
				}
			});
			let links = window.location.protocol + '//' + window.location.hostname+'/webapp/#/albumquery?id='+this.$route.query.id+'&openid='+localStorage.getItem('openid');
			let obj = {shareTit:'途美婚纱全球旅拍',shareCover:window.location.protocol + '//' + window.location.hostname+'/res/images/cents1.png', shareDes:'途美婚纱全球旅拍客照欣赏',shareUri:links};
			self.$Wx.initWechat(obj);
        },
		methods:{
		}
    }
</script>