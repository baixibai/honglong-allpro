<template xmlns:v-on="http://www.w3.org/1999/xhtml">
    <div class="bodyall">
		<div class="headtop">
			<img src="res/images/headtopbg.jpg" style="width:100%;" />
			<div class="conbox">
				<h1></h1>
			</div>
		</div>
		<div class="imglist-show" style="margin-top:5px;">
			<p class="ltitle">套餐展示</p>
			<router-link :to="{ path:'/packageinfo', query: { id:  item.id} }" class="listspan" v-for="item in goodquery" style="color:#666;">
				<img v-bind:src="$utils.imgurl+item.pic+'?x-oss-process=style/w400h400'" class="imgl" />
				<div class="descbox">
					<span class="stitle">{{item.name}}</span><span class="titlepoint">{{item.point || '人气爆棚'}}</span>
					<h2 class="price">￥ {{item.price}}</h2>
					<div class="infobox">
						<span>造型:{{item.model}}套</span><span>精修:{{item.truing}}张</span><span>摄影:{{item.camerist}}</span>
					</div>
				</div>
			</router-link>
		</div>
		<div class="imgcontpl mt10">
			<img src="res/images/loveway.png" alt="">
		</div>
		<div class="contentlist-box">
		  <img src="res/images/tcbgimg.jpg" width="100%" />
		</div>
		<div class="dialog" v-show="dialog">
			<div class="dialogbox-con">{{dialogcontent}}</div>
		</div>
    </div>
</template>
<style scoped>
@import '../../res/style/css/packagelist.css';
</style>
<script>
	import api from '../api'
	
    let interval = null;
    export default {
        data() {
            return {
				boxwidth:0,
				boxheight:0,
				goodquery:'',
				dialog:false,
				dialogcontent:'',
            };
        },
		created () {
			this.boxwidth = (window.screen.width - 50 ) / 2;
			this.boxheight = (((window.screen.width - 50 ) / 2)*2)/3;
		},
		mounted(){
			let self =this;
			$.post(api.goodquery(),function(res){
				if(res.errcode==0){
					self.goodquery = res.data;
					
				}else{
					self.$utils.errcode(res,self)
				}
			});
			let links = window.location.protocol + '//' + window.location.hostname+'/webapp/#/index?openid='+localStorage.getItem('openid');
			let obj = {shareTit:'途美婚纱全球旅拍',shareCover:window.location.protocol + '//' + window.location.hostname+'/res/images/cents1.png', shareDes:'拍满意才付款，婚纱照写真亲子照找途美旅拍',shareUri:links};
			self.$Wx.initWechat(obj);
			
        },
		methods:{
		}
    }
</script>