/**
 * 整个app的路由设置
 */
import Vue from 'vue'
import VueRouter from 'vue-router'
Vue.use(VueRouter)

import Index from '../components/index.vue'
import Home from '../components/home.vue'
import Score from '../components/score.vue'
import Referral from '../components/referral.vue'
import Packagelist from '../components/packagelist.vue'
import Packageinfo from '../components/packageinfo.vue'
import Bargain from '../components/bargain.vue'
import Trade from '../components/trade.vue'
import Bargainrecord from '../components/bargainrecord.vue'
import Coupon from '../components/coupon.vue'
import Couponinfo from '../components/couponinfo.vue'
import Album from '../components/album.vue'
import Albuminfo from '../components/albuminfo.vue'
import Albumadd from '../components/albumadd.vue'
import Scoredesc from '../components/scoredesc.vue'
import Albumedit from '../components/albumedit.vue'
import Albuminfoyl from '../components/albuminfoyl.vue'
import Albumquery from '../components/albumquery.vue'

const router = new VueRouter({
  // mode: 'history',
  routes: [
		{ path: "/", redirect: "/index" },
		{
			name:'index',path: "/index", component: Index
		},
		{
			name:'home',path: "/home", component: Home
		},
		{
			name:'score',path: "/score", component: Score
		},
		{
			name:'referral',path: "/referral", component: Referral
		},
		{
			name:'packagelist',path: "/packagelist", component: Packagelist	
		},
		{
			name:'packageinfo',path: "/packageinfo", component: Packageinfo	
		},
		{
			name:'bargain',path: "/bargain", component: Bargain	
		},
		{
			name:'bargainrecord',path: "/bargainrecord", component: Bargainrecord	
		},
		{
			name:'trade',path: "/trade", component: Trade	
		},
		{
			name:'coupon',path: "/coupon", component: Coupon,
			
		},
		{
			name:'couponinfo',path: "/couponinfo", component: Couponinfo		
		},
		{
			name:'album',path: "/album", component: Album		
		},
		{
			name:'albuminfo',path: "/albuminfo", component: Albuminfo		
		},
		{
			name:'albumadd',path: "/albumadd", component: Albumadd		
		},
		{
			name:'scoredesc',path: "/scoredesc", component: Scoredesc		
		},
		{
			name:'albumedit',path: "/albumedit", component: Albumedit		
		},
		{
			name:'albuminfoyl',path: "/albuminfoyl", component: Albuminfoyl		
		},
		{
			name:'albumquery',path: "/albumquery", component: Albumquery		
		},
    ]
})

export default router
