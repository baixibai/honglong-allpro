/**
 * Created by ck on 1/14/2017.
 */
import Vue from 'vue'
import VueRouter from "vue-router"
import VueResource from "vue-resource"
import VueI18n from "vue-i18n"

import errorCode from "./error-code.js";

 
if (!String.prototype.padLeft) {
    String.prototype.padLeft = function (max, c) {
        let self = this;
        let len = max - self.length;
        if (len < 0)
            return self;
        if (c === undefined)
            c = ' ';
        while (len--)
            self = c + self;
        return self;
    };
}

let utils = {};

// 处理错误
utils.errcode = function (data, self) {
    self.dialog=true;
	self.dialogcontent=data.errmessage;
	if(data.errcode==-2){
		setTimeout(function(){
			self.dialog=false;
			window.location.href= "/";
		},1500);
	}else{
		setTimeout(function(){self.dialog=false;},1500);
	}
	
};
// 弹出信息
utils.dialogcode = function (data, self) {
    self.dialog=true;
	self.dialogcontent=data;
	setTimeout(function(){self.dialog=false;},1500);
	
};
utils.setNull = function(data){
	if(data=='null'){
		data ='-';
	}
	return data;
};
utils.imgurl = "http://imgcdn.tripmarry.com";
utils.banner = function(){
	var UA = window.navigator.userAgent,IsAndroid = (/Android|HTC/i.test(UA)),IsIPad = !IsAndroid && /iPad/i.test(UA),IsIPhone = !IsAndroid && /iPod|iPhone/i.test(UA),IsIOS = IsIPad || IsIPhone,clearAnimatea = null;
var testStyle=document.createElement('div').style,
camelCase=function(str){
    return str.replace(/^-ms-/, "ms-").replace(/-([a-z]|[0-9])/ig, function(all, letter){
        return (letter+"").toUpperCase();
    });
},
cssVendor=(function(){
    var ts=testStyle,
        cases=['-o-','-webkit-','-moz-','-ms-',''],i=0;
    do {
        if(camelCase(cases[i]+'transform') in ts){
            return cases[i];
        }
    } while(++i<cases.length);
    return '';
})(),
transitionend=(function(){
    return ({
        '-o-':'otransitionend',
        '-webkit-':'webkitTransitionEnd',
        '-moz-':'transitionend',
        '-ms-':'MSTransitionEnd transitionend',
        '':'transitionend'
    })[cssVendor];
})(),
isCSS = function(property){
    var ts=testStyle,
        name=camelCase(property),
        _name=camelCase(cssVendor+property);
    return (name in ts) && name || (_name in ts) && _name || '';
};
var liebaoBrowser = {
    domAnimation: function(ele){
        ele.detBtn.hover(function(){
            $(this).addClass('btn-hover');
        },function(){
            $(this).removeClass('btn-hover');
        });
        ele.navhover.hover(function(){
            $(this).find("i").addClass('nav-hover');
        },function(){
            $(this).find("i").removeClass('nav-hover');
        });
        ele.downBtn.hover(function(){
            $(this).addClass('down-btn');
        },function(){
            $(this).removeClass('down-btn');
        });
        ele.watchLb.hover(function(){
            ele.code.addClass('code-show').show();
        },function(){
            ele.code.removeClass('code-show').hide();
        });
        ele.fnLi.hover(function(){
            var radiusEle = $(this).find('div');
            $(this).addClass('span-img');
            if(ele.aniMation){
                radiusEle.addClass('zoom');
            }else{
                radiusEle.show();
            }
        },function(){
            var radiusEle = $(this).find('div');
            $(this).removeClass('span-img');
            if(ele.aniMation){
                radiusEle.removeClass('zoom');
            }else{
                radiusEle.hide();
            }
        });
    },
    banSlide: function(item,time,ele,speed){
        clearTimeout(clearAnimatea);
        var length = ele.slide.length- 1;
        /*自动播放*/
        function autoPlay() {
            item++;
            if (item == length+1) {
                item = 0;
                aniObj(item);
            }else{
                aniObj(item);
            }
            spanCur(item);
            clearAnimatea = setTimeout(autoPlay, time);
        }
        clearAnimatea = setTimeout(autoPlay, time);
        /*点击切换动画*/
        function slidePrev(e){
            e.preventDefault();
            if(!ele.slide.is(':animated')){
                if (item == 0) {
                    item = length;
                    aniObj(item);
                } else {
                    item--;
                    aniObj(item);
                }
                spanCur(item);
            }
        };
        function slideNext(e){
            e.preventDefault();
            if(!ele.slide.is(':animated')){
                if (item == length) {
                    item = 0;
                    aniObj(item);
                } else {
                    item++;
                    aniObj(item);
                }
                spanCur(item);
            }
        };
        /* 点击切换动画 */
        ele.slideCur.click(function() {
            clearTimeout(clearAnimatea);
            ele.slideCur.removeClass('cur');
            $(this).addClass('cur');
            item = $(this).index();
            if (item <= length) {
                aniObj(item);
            }
        });
        /*执行动画方法*/
        function aniObj(getNum){
            ele.slide.hide().css({ opacity: 0.5,zIndex: 0});
            ele.slide.eq(getNum).show().stop(true,true).animate({opacity:1,zIndex:8},speed);
            if(ele.aniMation){
                ele.slide.removeClass('banAnimate');
                ele.slide.eq(getNum).addClass('banAnimate');
            }
        }
        /*当前动画指示*/
        function spanCur(eqNum) {
            ele.slideCur.removeClass('cur');
            ele.slideCur.eq(eqNum).addClass('cur');
        }
        /* 触发执行事件 */
        ele.prev.click(slidePrev);
        ele.next.click(slideNext);
        /* 手机上执行touch事件 */
        if(IsIOS || IsAndroid){
            var touchMain = document.getElementById('touchMain');
            var page = {
                x:0,
                y:0
            }
            var touched;
            touchMain.addEventListener('touchstart',function(e){
                clearTimeout(clearAnimatea);
                page.x = e.changedTouches[0].pageX;
                page.y = e.changedTouches[0].pageY;
            });
            touchMain.addEventListener('touchend',function(e){
                var pageX = e.changedTouches[0].pageX-page.x;
                var pageY = e.changedTouches[0].pageY-page.y;
                if(Math.abs(pageX)>50){
                    if(pageX>0){
                        slidePrev(e);
                    }else{
                        slideNext(e);
                    }
                }
                clearAnimatea = setTimeout(autoPlay, time);
                touched=null;
            });
            /* 防止阻止touchend事件 */
            touchMain.addEventListener('touchmove',function(e){
                if(null==touched){
                    var pageX = e.changedTouches[0].pageX-page.x;
                    var pageY = e.changedTouches[0].pageY-page.y;
                    touched=Math.abs(pageX-page.x)<Math.abs(pageY-page.y);
                }
                if(!touched)e.preventDefault();
            });
        }else{
            /*滑过主体区域停止动画*/
            ele.stopAnimte.hover(function() {
                clearTimeout(clearAnimatea);
            }, function() {
                clearAnimatea = setTimeout(autoPlay, time);
            });
        }
        /*初始化动画*/
        ele.slide.eq(0).show().addClass('banAnimate');
    },
    maxImgInit: function(ele){
        if(ele.windowMain.width()>760){
            ele.maxImg.hover(function(){
                if(ele.aniMation){
                    $(this).addClass('aniimgstyle');
                }else{
                    $(this).addClass('imgstyle');
                }
            },function(){
                if(ele.aniMation){
                    $(this).removeClass('aniimgstyle');
                }else{
                    $(this).removeClass('imgstyle');
                }
            });
        }else{
            return false;
        }
    },
    windowEvent: function(ele){
        if(!IsIOS && !IsAndroid){
            if(ele.windowMain.height() < 640){
                ele.downlaodMain.removeClass('position');
                ele.downlaodMain.addClass('padding');
            }else{
                ele.downlaodMain.removeClass('padding');
                ele.downlaodMain.addClass('position');
            }
        }
    },
    flipObj: function(ele,time){
        if(!IsIOS && !IsAndroid){
            setTimeout(function(){
                if(ele.aniMation){
                    ele.codeImg.show().addClass('flip');
                    ele.phoneImg.hide();
                }else{
                    ele.codeImg.show();
                    ele.phoneImg.hide();
                }
            },time);
            ele.phoneImg.click(function(){
                ele.phoneImg.hide().removeClass('flip');
                ele.codeImg.show().addClass('flip');
            });
            ele.codeImg.click(function(){
                ele.codeImg.hide().removeClass('flip');
                ele.phoneImg.show().addClass('flip');
            });
        }else{
            $('.pc-download').css({position:'absolute',left:'0',zIndex:'11',top:'156px;'});
            $('.phone-download').css({position:'absolute',left:'0',zIndex:'12',top:'-156px'});
        }
    },
    staJS: function(){
        $(document).on('click','a',function(e){
            var statData = $(this).attr('stat');
            try {
                _hmt.push(['_trackEvent',statData, 'webLB', 'click', 'download',statData]);
            } catch (e) {}
        });
    },
    init: function(ele){
        liebaoBrowser.banSlide(0,5000,ele,500);
        liebaoBrowser.domAnimation(ele);
        liebaoBrowser.windowEvent(ele);
        liebaoBrowser.maxImgInit(ele);
        ele.windowMain.on('resize',function(){
            liebaoBrowser.windowEvent(ele);
            liebaoBrowser.maxImgInit(ele);
        });
        liebaoBrowser.flipObj(ele,2000);
        liebaoBrowser.staJS();
    }
};
$(function(){
    var domEle = {
		navhover: $('.nav-main a'), detBtn: $('.details'),
		maxImg: $('.news-img'), fnLi: $('.ft-list li'), 
		aniMation: isCSS('animation'), watchLb: $('#watch-lb'), 
		code: $('.watch-code'), 
		downBtn: $('.beta-info a'), 
		downlaodMain: $('.downlaod-main'), 
		windowMain: $(window), 
		bodyEle: $('body'), 
		stopAnimte: $('.slide,.prev,.next,.item'), 
		prev: $('.prev'),
		next: $('.next'), 
		slide: $('.slide'), 
		slideCur: $('.item a'),
		phoneImg: $('.phone-img'),
		codeImg: $('.code-img') 
	};
	domEle.downlaodMain.show();
	liebaoBrowser.init(domEle);
});
};
utils.moveimg = function(){
	var $banner_box = $("#banner_box"),
		$pages = $("#banner_list").find(".page_box"),
		  $mainBoxs = $pages.find(".main_box"),
		   $bgs = $pages.find("img"),
		$controlBox = $("#control_box"),
		$productBtns = $("#product_btns"),
		$controls = $controlBox.find("a");
	var data = {
		pLength: $pages.length,//记录一共有多少个page_box
		curP: 0,
		isCan: true,
		isOnbtn: false,
		fColor: [2, 2, 1, 1, 1],
		dur: 3000,
		cNum: 0
	};

	//自动轮播换页函数
	var cId;
	var pageChange = function (idx) {
		if (data.isOnbtn)
			return;
		if (idx >= -1 && idx < data.pLength && idx != data.curP && data.isCan) {
			data.isCan = false;
			data.cNum++;
			clearInterval(cId);//停止动画
			idx = idx == -1 ? data.pLength - 1 : idx;//条件表达式 真前假后 指向最后一张
			$controls.removeClass("icon_show").eq(idx).addClass("icon_show");
			$pages.eq(data.curP).css({ zIndex: 0 });
			$pages.eq(idx).addClass("show").css({ opacity: 0, zIndex: 1 }).animate({ opacity: 1 }, 400, function () {
				$pages.eq(data.curP).removeClass("show");
				$(this).addClass("show");
				data.isCan = true;
				data.curP = idx;
				data.cNum--;
				if (data.cNum == 0) {
					//setInterval() 方法会不停地调用函数，直到 clearInterval() 被调用或窗口被关闭。
					cId = setInterval(function () {
						pageChange((data.curP + 1) % data.pLength);
						//% 求余数 当要处理 X % Y时, 如果, X < Y 的话, 回传值就是 X 自己 1 % 4 = 1
					}, data.dur);//data.dur 是时间
				}
			});
		}
	}
	//鼠标经过 下方导航
	$controls.on("mouseenter", function () {
		data.isCan = true;
		pageChange($controls.index(this));
		data.isOnbtn = true;
	});
	$controls.on("mouseleave", function () {
		data.isOnbtn = false;
	});

	cId = setInterval(function () {
		pageChange((data.curP + 1) % data.pLength);
	}, data.dur);

	//网页自由缩放  2016-10-12 调整
	var isIE6 = navigator.userAgent.indexOf("MSIE 6.0") > 0;//获取浏览器的版本
	//调整
	//页面自缩放
	

	function resize_img(w, h) {
		var snoww = w * 593 / 1920,
		   snowh = h * 448 / 1080;
		var roomw = w * 668 / 1920,
			roomh = h * 585 / 1080;
		var forestw = w * 500 / 1920,
			foresth = h * 636 / 1080;
		var skyw = w * 371 / 1920,
			skyh = h * 341 / 1080;
		if (w / h < 1920 / 1080) {
			//$(".snow_cot").height(snowh).css({ width: snowh * 宽 / 高 + "px", margin: "0 0 0" + -.5 * 宽 / 高 * snowh + "px" });
			$(".snow_cot").height(snowh).css({ width: snowh * 593 / 448 + "px", margin: "0 0 0" + -.5 * 593 / 448 * snowh + "px" });
			$(".room_cot").height(roomh).css({ width: roomh * 668 / 585 + "px", margin: "0 0 0" + -.5 * 400 / 585 * roomh + "px" });
			$(".forest_cot").height(foresth).css({ width: foresth * 500 / 636 + "px", margin: "0 0 0" + -.5 * 500 / 636 * foresth + "px" });
			$(".sky_cot").height(skyh).css({ width: skyh * 371 / 341 + "px" });

		} else {
			//$(".snow_cot").width(snoww).css({ height: snoww * 高 / 宽 + "px", margin: "0 0 0" + -.5 * snoww + "px" });
			$(".snow_cot").width(snoww).css({ height: snoww * 448 / 593 + "px", margin: "0 0 0" + -.5 * snoww + "px" });
			$(".room_cot").width(roomw).css({ height: roomw * 585 / 668 + "px", margin: "0 0 0" + -.5 * 400 * roomw / 668 + "px" });
			$(".forest_cot").width(forestw).css({ height: forestw * 636 / 500 + "px", margin: "0 0 0" + -.5 * forestw + "px" });
			$(".sky_cot").width(skyw).css({ height: skyw * 341 / 371 + "px" });
		}

	}
}

export default {
    install(Vue){
        Vue.prototype.$utils = utils;
    }
};
