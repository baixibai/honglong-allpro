import Vue from 'vue'
import VueRouter from "vue-router"
import VueResource from "vue-resource"
import VueI18n from "vue-i18n"
import router from './router/router'

import errorCode from "./utils/error-code.js";
import Utils from "./utils/utils.js"
import Base from "./utils/base.js"
import Wechat from "./utils/wechat.js"
import App from './App.vue'


Vue.use({
    install: (Vue) => {
        Vue.prototype.ERRORCODE = errorCode; 
    }
});
Vue.use(Utils);
Vue.use(Base);
Vue.use(Wechat);
Vue.use(VueRouter);
Vue.use(VueResource);
Vue.use(VueI18n);
$.post('/wap/user/session',function(res){
	if(res.errcode==0){
		if(typeof(res.data)!='undefined'){
			localStorage.setItem('openid',res.data.openid);
			window.sessionStorage.setItem('openid',res.data.openid);
			window.sessionStorage.setItem('uid',res.data.uid);
			if(typeof(res.data.uid)=='undefined'){
				location.href = window.location.protocol+'//'+window.location.hostname+'/wap/user/wxlogin?rurl='+encodeURIComponent(window.location.href);
			}
		}else if(typeof(res.data)=='undefined'){
			location.href = window.location.protocol+'//'+window.location.hostname+'/wap/user/wxlogin?rurl='+encodeURIComponent(window.location.href);
		}else{
			window.sessionStorage.setItem('openid',res.data.openid);
			localStorage.setItem('openid',res.data.openid);
			window.sessionStorage.setItem('uid',res.data.uid);
		}
	}else{
		console.log('授权失败');
	}
});

new Vue({
  el: '#app',
  router,
  template: '<App/>',
  components: { App }
})

      



