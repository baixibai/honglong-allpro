<template>
  <div>
     <router-view>
        <div class="mask"></div>
        <div class="loading">
            <div class="circle01">
                <div class="circle02"></div>
            </div>
        </div>
    </router-view>
  </div>
</template>
