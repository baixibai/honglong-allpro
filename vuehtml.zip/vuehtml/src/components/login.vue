<template xmlns:v-on="http://www.w3.org/1999/xhtml">
    <div class="loginbg" style="background:url(res/images/loginbg.jpg) no-repeat;background-size: cover;height:1000px;">
		<div class="loginbox">
			vue前端模板
		</div>
    </div>
</template>

<script>
	import api from '../api'
	
    let interval = null;
    export default {
        data() {
            return {
				username:'',
				password:'',
				isLogin:'1', //1 是未登录  2已登录
            };
        },
		created () {
		},
		mounted(){
			
        },
		methods:{
		}
    }
</script>