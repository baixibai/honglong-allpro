/**
 * Created by ck on 1/18/2017.
 */
export default {
    "0": "成功",
    "-1": "请求错误",
    "-2": "未授权登录",
};