import Vue from 'vue'
import VueRouter from "vue-router"
import VueResource from "vue-resource"
import VueI18n from "vue-i18n"
import { formtype, formtip }	from './form'
//-- DOM操作
const DOM = {
	//-- 获取标签
	getTag(name) {
		return window.document.getElementsByTagName(name)[0]
	},
	//-- 更换标题
	title(name){
		this.getTag('title').innerHTML = name
	},
	//-- 创建DOM
	create(name='div'){
		return document.createElement(name)
	},
	//-- 设置属性
	setAttr(node,name,value){
		node && node.setAttribute(name.replace(/\s/g,''),value)
	},
	//-- 添加DOM
	addBody(child){
		this.getTag('body').appendChild(child)
	},
	//-- 移除body中的dom
	removeBody(child){
		this.getTab('body').removeChild(child);	
	},
	//-- 插入script
	script(url,callback){
		let script = this.create('script')
		this.setAttr(script,'src',url+'?callback=callback')
		script.onload = script.onreadystatechange = function(){  
			if(script.readyState && script.readyState != 'loaded' && script.readyState != 'complete') return
			script.onreadystatechange = script.onload = null  
			callback && callback() 
		}  
		this.addBody(script)
	}
}

//-- 基础，类似underscore
const _ = {
	op(){
		let op = Object.prototype
		return {
			ostring	: op.toString,
			hasOwn	: op.hasOwnProperty,
		}
	},
	isFunction(it){
		return this.op().ostring.call(it) === '[object Function]'
	},
	isArray(it) {
		return this.op().ostring.call(it) === '[object Array]'
	},
	isObject(it) {
		return this.op().ostring.call(it) === '[object Object]'
	},
	isString(it) {
		return this.op().ostring.call(it) === '[object String]'
	},
	isUndefine(it) {
		return this.op().ostring.call(it) === '[object Undefined]'
	},
	isBool(it) {
		return this.op().ostring.call(it) === '[object Boolean]'
	},
	isNumber(it) {
		return it%1 >= 0
	},
	hasArr(val,array){
		let res = false
		array.map((value) => {
			if(value === val){
				res = true
			}
		})
		return res
	},
	removeArr(val,array){
		array.map((value,i) => {
			value === val && array.splice(i,1)
		})
		return array
	},
	hasProp(obj, prop){
		return this.op().hasOwn.call(obj, prop)
	},
	eachProp(obj, func){
		for(let prop in obj){
			if(this.hasProp(obj, prop)){
				if(func(obj[prop], prop)){
					break;
				}
			}
		}
	},
	mixin(target, source) {  
		if(source){
			this.eachProp(source, function(value, prop) {
				if (!this.hasProp(target, prop)) {
					if (this.isObject(value) && value &&
						!this.isArray(value) && !this.isFunction(value) &&
						!(value instanceof RegExp)){
						if(!target[prop]){
							target[prop] = {};
						}
						_.mixin(target[prop], value);
					}else{
						target[prop] = value;
					}
				}else{
					target[prop] = value;
				}
			}.bind(this))
		}
		return target;
	},
	now(){
		return parseInt( new Date() / 1000 )
	},
	filterSpace(txt){
		return txt.replace(/\s/g,'')
	},
	cut(txt){
		return this.filterSpace(txt).split('|')
	},
	random(min,max){
		let under	= max ? min : 0
		let top		= max || min
		return parseInt(Math.random()*(top-under+1) + under)
	},
	objEqual(a, b){
		let objA = Object.getOwnPropertyNames(a)
		let objB = Object.getOwnPropertyNames(b)
		if (objA.length != objB.length) {
			return false
		}
		for (var i = 0; i < objA.length; i++) {
			var propName = objA[i]
			if(_.isArray(a[propName])){
				console.log('array')
				if(a[propName].length != b[propName].length){
				}else{
					for (let j = 0; j < a[propName].length; j++){
						let cItemA = a[propName][j]
						let cItemB = b[propName][j]
						if(_.isObject(cItemA)){
							_.objEqual(cItemA, cItemB)
						}
					}
				}
			}else{
				if(_.isObject(a[propName])){
					_.objEqual(a[propName], b[propName])
				}else{
					if (a[propName] !== b[propName]) {
						return false
					}					
				}
			}
		}
		return true
	}
}
//-- 改造时间
const TranTime = (data,mat) => {
	if(data=='0' || data==''){
		return format="--";
	}
	let time = new Date(data*1000)
	let format = mat || 'yyyy-MM-dd hh:mm:ss'
       var date = {
			"M+": time.getMonth() + 1,
			"d+": time.getDate(),
			"h+": time.getHours(),
			"m+": time.getMinutes(),
			"s+": time.getSeconds(),
			"q+": Math.floor((time.getMonth() + 3) / 3),
			"S+": time.getMilliseconds()
       }
       if(/(y+)/i.test(format)){
			format = format.replace(RegExp.$1, (time.getFullYear() + '').substr(4 - RegExp.$1.length))
       }
       for (var k in date) {
              if (new RegExp("(" + k + ")").test(format)) {
                     format = format.replace(RegExp.$1, RegExp.$1.length == 1
                            ? date[k] : ("00" + date[k]).substr(("" + date[k]).length))
              }
       }
       return format;
}
//-- ajax请求，不公开
const Ajax = () => {
	var map = []
	var ajax = {
		//-- 获取XML
		XML(){
			let XMLHttpReq
			try{
				XMLHttpReq = new ActiveXObject("Msxml2.XMLHTTP");
			}catch(e){
				try{
					XMLHttpReq = new ActiveXObject("Microsoft.XMLHTTP");
				}catch(e){
					XMLHttpReq = new XMLHttpRequest();
				}
			}
			return XMLHttpReq
		},
		//-- ajax请求过程
		process(XML,option){
			if(XML.readyState == 4){
				if(XML.status == 200){
					var res = XML.responseText
					try{
						res = JSON.parse(res)
					}catch(e){
						console.warn('返回数据不为JSON')
					}	
					if(res.status != 1){
						option.error(res)
						return
					}
					option.success(res.data)
				}else{
					option.error(XML)
				}
			}
		},
	}
	
	return function(option){
		if(_.hasArr(option.api,map)){
			return
		}
		var xml = ajax.XML()
		option.async		= !option.async			|| true
		option.contentType	= option.contentType	|| 'application/x-www-form-urlencoded'
		option.error		= option.error		|| function(){}
		option.success		= option.success		|| function(){}
		option.type			= option.type		|| 'POST'
		let dataArr = []
		_.eachProp(option.data,function(value,name){
			if(_.isArray(value)){
				value.map(function(val,i){
					dataArr.push( name + '[]=' + encodeURIComponent(val) )
				})
			}else{
				dataArr.push( name + '=' + encodeURIComponent(value) )
			}
		})
		let newData = dataArr.join('&')
		//-- 防止重复提交
		let newapi
		if(option.url==''){
			newapi = option.api
		}else{
			newapi = option.url
		}
		var api = newapi
		map.push(api)
		setTimeout(function(){
			_.removeArr(api,map)
		},500)
		xml.open(option.type,newapi,option.async);
		xml.setRequestHeader("Content-Type",option.contentType);
		xml.onreadystatechange = function(){
			ajax.process(xml,option)
		}
		xml.send(newData)
	}
}

//-- AJAX实例
const AJAX = Ajax()

//-- 缓存
const Store = {	
	set(key,value,type = true){
		if(value === void 0){
			return this.remove(key)
		}
		this.has(key) && this.remove(key)
		var name = !!type ? 'localStorage' : 'sessionStorage'
		try{
			value = JSON.stringify(value)
		}catch(e){
			console.warn('数据不为JSON格式')
		}
		window[name].setItem(key,value)
		return value
	},
	get(key){
		var value = window.localStorage.getItem(key) || window.sessionStorage.getItem(key)
		try{
			value = JSON.parse(value)
		}catch(e){
		}
		return value || false
	},
	has(key){
		return !!this.get(key)
	},
	remove(key){
		window.localStorage.removeItem(key)
		window.sessionStorage.removeItem(key)
	},
	clear(){
		window.localStorage.clear()
		window.sessionStorage.clear()
	},
	//设置cookie
	setCookie(cname, cvalue, exdays) {
		 var d = new Date();
		 d.setTime(d.getTime() + (exdays*24*60*60*1000));
		 var expires = "expires="+d.toUTCString();
		 document.cookie = cname + "=" + cvalue + "; " + expires;
	},
	//获取cookie
	getCookie(cookie_name)
	{//获取单个cookies 
		var acookie=document.cookie.split("; ")
		for(var i=0;i<acookie.length;i++){ 
			var arr=acookie[i].split("="); 
			if(cookie_name==arr[0]){ 
			if(arr.length>1) 
			return unescape(arr[1]); 
			else 
			return ""; 
		}} 
		return ""; 
	} 
}


//-- 跳转
const GO = (data,type) => {
	if(type){
		browserHistory.replace(data)		
	}else{		
		browserHistory.push(data)
	}
}

//-- 返回GET对象
// const GET = () => {
	// let search	= decodeURIComponent(location.search).replace('?','').split('&')
	// let obj = {};
	// for ( let val of new Set(search) ) {
		// let arr = val.split('=')
		// obj[arr[0]] = arr[1]
	// }
	// return obj
// }

const GET = () => {
	let search	= decodeURIComponent(location.search).replace('?','').split('&')
	let obj = {}
	search.map((val,i) => {
		let newArr = val.split('=')
		let name = newArr[0]
		let value = newArr[1]
		obj[name] = value
	})
	return obj
}

//-- 通过name获取DOM，返回对象
const GetName = (arr) => {
	let obj = {}
	arr.map(function(el){
		obj[el] = document.getElementsByName(el)[0]
	})
	return obj
}

//-- Focus
const Focus = (name) => {
	let input = GetName([name])
	input[name].focus()
}

//-- 表单验证
const Vaild = (option)=>{
	let data	= option.data
	let rule	= option.rule
	let error	= option.error
	let success	= option.success
	for( let name in data ){
		let value = data[name].value
		if(rule[name]){
			let rulename = rule[name]
			if(formtype[rulename] && formtip[rulename]){
				if(!value.match(formtype[rulename])){	
					data[name].focus()
					error(formtip[rulename])
					return
				}
			}else{
				console.warn('未配置此正则')
				return
			}
		}
	}
	success(data)				
}

//-- 转义成html字符串 
const HTMLString = (val) => {
	console.log(val);
	let txt = JSON.stringify(val).replace(/ /g,'&nbsp;').replace(/\\n/g,'</br>')
	return txt.substr(1,(txt.length - 2))
}

//-- 检查图片是否存在
var imgcheck = {}

const imgExit = (url,cb,path) => {
//	console.log(url)
	imgcheck[url] = imgcheck[url] || {}
	let ImgObj = new Image()
	let baseUrl = location.protocol + '//' + location.hostname + '/'
	let baseArr = [
		// 'http://7xqbkx.com1.z0.glb.clouddn.com/',
		baseUrl,
		baseUrl + 'uploads/'
	]
//	console.log(path)
	let resurl = path ? path + url : url.match(/^http/) ? url : baseArr[0] + url
//	console.log('=========================='+resurl)
	ImgObj.src = resurl
	ImgObj.onload = function(res){
		imgcheck = {}
		cb.success(resurl)
	}
	ImgObj.onerror = function(res){
		if(imgcheck[url]==undefined){
			return
		}
		imgcheck[url]['checkimg'] = !!imgcheck[url]['checkimg'] ? imgcheck[url]['checkimg'] + 1 : 1
		console.log(url + imgcheck[url]['checkimg'])
		let pathnum = imgcheck[url]['checkimg']
		console.log(pathnum)
		let imgpath = baseArr[pathnum]
		console.log(imgpath)
		// pathnum == 1 && cb.error()
		// console.log(pathnum)
		pathnum < 2 && imgExit(url,cb,imgpath)
	}
}

const Pricedeal = (data)=>{
	let price = '0'
	if( ( data * 1 ) > 0 ){
		let arr = [data].join('').split('.')
		let integer = arr[0]
		let deci = arr[1]
		deci = deci
			? deci.length >= 2
				? deci.substr(0,2)
				: ( deci + '0' )
			: '00'
		price = [integer,deci].join('.')
	}
	return price
}
let base = {
	Store,
	DOM,
	GO,
	GetName,
	Vaild,
	HTMLString,
	imgcheck,
	imgExit,
	Focus,
	_,
	GET,
	TranTime,
	Pricedeal,
};
export default {
	base,
    install(Vue){
        Vue.prototype.$base = base;
    }
};

