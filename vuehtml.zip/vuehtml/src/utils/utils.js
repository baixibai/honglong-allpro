/**
 * Created by ck on 1/14/2017.
 */
import Vue from 'vue'
import VueRouter from "vue-router"
import VueResource from "vue-resource"
import VueI18n from "vue-i18n"

import errorCode from "./error-code.js";

 
if (!String.prototype.padLeft) {
    String.prototype.padLeft = function (max, c) {
        let self = this;
        let len = max - self.length;
        if (len < 0)
            return self;
        if (c === undefined)
            c = ' ';
        while (len--)
            self = c + self;
        return self;
    };
}

let utils = {};

// 处理错误
utils.errcode = function (data, self) {
    self.dialog=true;
	self.dialogcontent=data.errmessage;
	if(data.errcode==-2){
		setTimeout(function(){
			self.dialog=false;
			window.location.href= "/";
		},1500);
	}else{
		setTimeout(function(){self.dialog=false;},1500);
	}
	
};
// 弹出信息
utils.dialogcode = function (data, self) {
    self.dialog=true;
	self.dialogcontent=data;
	setTimeout(function(){self.dialog=false;},1500);
	
};
utils.setNull = function(data){
	if(data=='null'){
		data ='-';
	}
	return data;
}

export default {
    install(Vue){
        Vue.prototype.$utils = utils;
    }
};
