const _baseUrl = '/'
export default {
	// 登录
	login () {
		return _baseUrl + 'chat/user/login'
	},
	// 初始化
	init () {
		return _baseUrl + 'chat/user/init'
	},
	// 查看群组成员
	members () {
		return _baseUrl + 'chat/user/members'
	},
	// uid绑定socket标识
	chatbind () {
		return _baseUrl + 'chat/chat/bind'
	},
	// 发送消息
	sendMessage () {
		return _baseUrl + 'chat/chat/sendMessage'
	},
	// 创建群组
	createGroup () {
		return _baseUrl + 'chat/chat/createGroup'
	},
	// 申请加入群组
	addFriendGroup() {
		return _baseUrl + 'chat/chat/addFriendGroup'
	}
}
