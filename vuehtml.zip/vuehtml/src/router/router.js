
import Vue from 'vue'
import VueRouter from 'vue-router'
Vue.use(VueRouter)

import index from '../components/index.vue'
import login from '../components/login.vue'

const router = new VueRouter({
  // mode: 'history',
  routes: [
		{ path: "/", redirect: "/login" },
		{
			name:'login',path: "/login", component: login
		},
		{
			name:'index',path: "/index", component: index
		}
    ]
})

export default router
