import Vue from 'vue'
import VueRouter from "vue-router"
import VueResource from "vue-resource"
import VueI18n from "vue-i18n"
import router from './router/router'

import errorCode from "./utils/error-code.js";
import Utils from "./utils/utils.js"
// import Base from "./utils/base.js"
import App from './App.vue'


Vue.use({
    install: (Vue) => {
        Vue.prototype.ERRORCODE = errorCode; 
    }
});
Vue.use(Utils);
// Vue.use(Base);
// Vue.use(Wechat);
Vue.use(VueRouter);
Vue.use(VueResource);
Vue.use(VueI18n);

new Vue({
  el: '#app',
  router,
  template: '<App/>',
  components: { App }
})
      



