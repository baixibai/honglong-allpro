<template>
    <div>
        <ul>
            <li v-for="item in rooms">
                <div>房间ＩＤ：{{item.room_id}}</div>
                <div>荷官名字：{{item.dealer_id}}</div>
                <div>下注时间：{{item.bet_timer}}</div>
                <div>剩余时间：{{item.remains}}</div>
                <div>房间状态：{{item.room_state}}</div>
                <div>历史记录：{{item.histories}}</div>
            </li>
        </ul>
        <div v-countdown="t"></div>
        <button @click="login">登录</button>
        <button @click="runningGame">进入大厅</button>
    </div>
</template>

<script>
    var testData = [{
        "bet_timer": 24000,
        "dealer_id": "penelope",
        "histories": [32, 32, 32, 32, 32, 32, 32, 32, 32, 32, 32, 32, 32, 32],
        "minigame_history": null,
        "remains": 10627,
        "room_id": 1,
        "room_state": 0,
        "rules": [0, 1],
        "vendor_id": 2,
        "win_count": null
    }, {
        "bet_timer": 24000,
        "dealer_id": "amelia",
        "histories": [80, 80, 80, 80, 80, 80],
        "minigame_history": null,
        "remains": 0,
        "room_id": 2,
        "room_state": 0,
        "rules": [0, 1],
        "vendor_id": 2,
        "win_count": null
    }];
    export default {
        data() {
            return {
                rooms: [],
                msg: 'Welcome to Your Vue.js App',
                t:12200
            }
        },
        created(){
            let that = this;
            this.rooms = testData;
//            setInterval(() => {
//                that.rooms[1].bet_timer = new Date();
//                //that.$set(that.rooms, 1, that.rooms[1])
//            }, 3000);
//
            setTimeout(()=>{
                that.t = 22000
            },5000)
        },
        methods: {
            login() {
                this.$router.replace("/login");
            },
            runningGame() {
                console.log("lobby")
                //this.$socket.emit(104);
                //this.$router.replace("/lobby")
            }
        }
    }
</script>
