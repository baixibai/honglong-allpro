<template xmlns:v-on="http://www.w3.org/1999/xhtml">
	
    <div class="full-height">
		
        <Loading :show="isLogin===0||submitting"></Loading>
		<div id="tip" v-show="landscapestatus==true">
			<div class="landscapebg"></div>
			<div class="landscapetip">
				<div class="landcontent">
					<p>请使用横屏体验</p>
					<img src="../res/images/fullScreen.png" width="60"/>
				</div>
				<a class="confirm" @click="fullScreen">知道了</a>
			</div>
		</div>
        <div class="login-box">
            <!--<div class="logo"></div>-->
            <div class="login-form">
                <div style="padding:5px 0;color:#fff;">{{error}}</div>
                <form autocomplete="off" @submit.prevent="login">
                    <div class="form-control id-box">
                        <i v-on:click="showInput($event)"></i>
                        <input type="text" placeholder="user name" v-model="username"/>
                    </div>
                    <div class="form-control pw-box">
                        <i v-on:click="showInput($event)"></i>
                        <input type="password" placeholder="Password" v-model="password"/>
                    </div>
                    <input class="btn btn-login on" style="margin-bottom:1rem;" type="submit" value="OK">
					<label style="color:#fff;"><input id="cookiesave" name="cookiesave" style="float:left;width:1.5rem;height:1.5rem;margin-left:37%;" type="checkbox" value="" /><span style="float:left;height:1.5rem;line-height:1.5rem;">{{savename}}</span> </label> 
                </form>
            </div>
            <div class="footer">
                <a class="btn btn-guest"><span></span></a>
            </div>
            <div class="Qr_code">
                <div class="ios"><img src="/res/images/iosqrcode.png"/></div>
                <div class="android"><img src="/res/images/Androidqrcode.png"/></div>
            </div>
            <div class="lang">
                <div class="current_lang" v-on:click="showLang($event)"><span class=""><i class="other" :class="active"></i></span></div>
                <div class="other_lang lang_nav">
                    <span class="other_chi" @click="switchLang('icon_chi','zh-CHS')"><i class="other icon_chi"></i></span>
                    <span class="other_usa" @click="switchLang('icon_usa','en-US')"><i class="other icon_usa"></i></span>
                    <span class="other_kor" @click="switchLang('icon_kor','ko-KR')"><i class="other icon_kor"></i></span>
                    <!--
					<span class="other_jap"><i class="other icon_jap"></i></span>
					<span class="other_malay"><i class="other icon_malay"></i></span>
                    <span class="other_spain"><i class="other icon_spain"></i></span>
                    <span class="other_th"> <i class="other icon_th"></i></span>
                    <span class="other_thai"><i class="other icon_thai"></i></span>
                    <span class="other_te"><i class="other icon_tw"></i></span>
                    <span class="other_hk"><i class="other icon_usa"></i></span>
                    <span class="other_viet"><i class="other icon_viet"></i></span>-->
                </div>
            </div>
        </div>
		<div class="ui-dialog" v-show="tip">
			<a href="javascript:;" class="close-btn" @click="tip=false">x</a>
			<div class="d-body succeed-con">{{relogin}}</div>
		</div>
    </div>
</template>

<script>
    import Loading from "./Loading.vue"
    let interval = null;
    export default {
        data() {
            return {
                isLogin: 0, /// 0检查中，1已登录，2未登录
                username: this.$utils.getCookie('id') || "",
                password: this.$utils.getCookie('password') || "",
                submitting: false,
                error: "",
				active:this.$t("ICON_LANGUAGE"),
				landscapestatus:false,
				alertInfo:'',
				tip:false,
				relogin:this.$t("RE_LOGIN"),
				savename:this.$t("SAVENAME")
            };
        },
		created () {
			 if(document.documentElement.clientWidth < document.documentElement.clientHeight){
				this.landscapestatus=true
			 }else{
				this.landscapestatus=false
			 }
		},
        mounted(){
            this.auth();
			let input = document.getElementsByTagName('input');
			document.body.scrollTop  = 80;
			input[0].onfocus=function(){
				document.getElementsByTagName('body')[0].style.height = window.innerHeight+'px';
			}; 
			input[1].onfocus=function(){
				document.getElementsByTagName('body')[0].style.height = window.innerHeight+'px';
			};		
			this.tip = false;
			
        },
        components: {
            Loading
        },
        methods: {
			showLang(event){
				if(document.getElementsByClassName('other_lang')[0].style.display!='block')
				{
					document.getElementsByClassName('other_lang')[0].style.display = "block";
					event.target.style.position='absolute';
					event.target.style.zIndex='1';
				}else{
					document.getElementsByClassName('other_lang')[0].style.display = "none";
				}
			},
			switchLang:function(lang,alllang){
				document.getElementsByClassName('other_lang')[0].style.display = "none";
				this.active=lang
				this.$utils.changeLange(alllang)
				location.reload()
			},
            showInput(event){
                event.target.nextElementSibling.style.display = "inline-block";
                event.target.nextElementSibling.focus();
            },
            login: function () {
				if(navigator.platform.indexOf("Win")!=0){
					this.$utils.fullScreen(document.getElementsByTagName('body')[0]);
					document.getElementsByTagName('body')[0].style.width="100%";
					document.getElementsByTagName('body')[0].style.height=document.documentElement.clientHeight+'px';
					$('.full-height').height(document.documentElement.clientHeight);
				}
                let that = this;
                let username = this.username.trim();
                let password = this.password.trim();
                if (username.length === 0 || password.length === 0) return;
                this.error = "";
                this.submitting = true;
				//this.$http.get("http://h5api.belcdev.com/main/desktop_login", {
                this.$http.get("http://api.888beteast.com/main/desktop_login", {
                    params: {
                        id: username,
                        password: password,
						platfrom:4
                    }
                }).then(res => {
                    console.log(res)
                    if (res.ok) {
                        let data = typeof res.body==='string' ? JSON.parse(res.body) : res.body;
                        console.log(data)
                        if (data.result === 0) {
							let cook = document.getElementById('cookiesave');
							if(document.getElementById('cookiesave').checked){
								let date=new Date()
								date.setTime(date.getTime()+10*24*3600*1000)
								document.cookie='id='+encodeURIComponent(username).replace(/!/g, '%21').replace(/'/g, '%27').replace(/\(/g, '%28').  
								replace(/\)/g, '%29').replace(/\*/g, '%2A').replace(/%20/g, '+')+'; path=/;expires='+date.toGMTString()
								document.cookie='password='+encodeURIComponent(password).replace(/!/g, '%21').replace(/'/g, '%27').replace(/\(/g, '%28').  
								replace(/\)/g, '%29').replace(/\*/g, '%2A').replace(/%20/g, '+')+'; path=/;expires='+date.toGMTString()
							}
							
                            window.STORE.token = data.login_token;
                            sessionStorage.setItem("token", data.login_token);
                            this.auth();
							
                        } else {
                            that.error = that.$t("LOGIN_FALED");
                            interval = setTimeout(() => {
                                that.error = "";
                            }, 2000);
                            //console.log("登录失败，错误代码：", data.result);
                        }
                    }
                }).then(() => {
                    this.submitting = false;
                });
            },
            /// 检查是否已经登录
            auth(){
                let that = this;
                let token = window.STORE.token || sessionStorage.getItem("token")||this.$utils.geturlvalue('login_token');
                if (!token ) return this.isLogin = 2;
				sessionStorage.setItem("token", token);
                this.isLogin = 0;
                this.socket(105, {
                    token: token,
                    "patch_ver": "1.0.3",
                    "platform": 4
                }, {
                    "115": (data) => {
                        if (data.result === 0) {
							if(data.user.credit<0){
								sessionStorage.removeItem("token");
								window.STORE.token = null;
								this.$router.replace("/")
							}else{
								window.STORE.token = token;
								data.user.credit = (data.user.credit/100).toFixed(9) - 0;
								window.STORE["113"] = data;
								return that.$router.replace({name: "lobby"});
							}
                        }else if(data.result === 3){
							sessionStorage.removeItem("token");
							window.STORE.token = null;
							that.tip = true;
							this.$router.replace("/")
						}else{
							sessionStorage.removeItem("token");
							window.STORE.token = null;
							this.relogin=this.$t("LOGIN_TIMEOUT");
							that.tip = true;
							this.$router.replace("/")
						}
                        that.isLogin = 2;
                    }
                });
            },
			fullScreen(){
				this.landscapestatus=false
				document.getElementById('tip').style.display="none"
				
			}
        }
    }
</script>