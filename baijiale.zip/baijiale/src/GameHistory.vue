<template>
    <div>
        <Loading :show="loading"></Loading>
        <!--游戏记录-->
        <div class="code-dialog" style="display:none;" v-show="showProtocol">
         <!--loading -->
            <div class="mask" style="display:none;"></div>
            <div class="loading" style="display:none;">
                <div class="circle01">
                    <div class="circle02"></div>
                </div>
            </div>
            <!--loading  end -->
            <a class="btn btn-close-1" @click="showProtocol=false;loading=false;"></a>
            <div class="title" id="history">{{GAME_HISTORY}}</div>
            <div class="load-box" id='datacontainer'>
                <div class='table-container'>
                    <table class='gamehistory'>
                    <tr id="history-head"><th style='min-width:80px;'>{{DATE}}</th><th style='min-width:80px;'>{{GAME}}</th><th>{{STAKE}}</th><th style="width:25%;min-width:250px;">{{ANNOUNCE_OF_LOTTERY}}</th><th id="payout">{{PAYOUT}}</th><th id="asset">{{WINBALANCE}}</th></tr>
                    <tr v-if='gameName=="baccarat"' v-for="item in gameResult">
                        <td>{{item.time}}</td>
                        <td><p>{{baijiale}}</p> <p>{{room}}:{{item.tableInfo}}</p><p>{{number_of_games}}:{{item.round}}</p></td>
                        <td>{{item.betCash}}</td>
                        <td>
                          <div class="history-player">
                        <img :class="{'cardpic':true,'updown cardpic':item.cardplayer.length==3&&index===0}" v-for="(key,index) in item.cardplayer" v-bind:src="'/res/images/origin_small/S_'+['S','H','C','D'][key.type]+key.num+'.png'" alt="" style="height:35px;width:23px;">
                        <span>{{item.playercval}}</span>
                        </div>
                        <span v-bind:class='{"winnerb":item.winner=="B","winnerp":item.winner=="P","winnert":item.winner=="T"}'>{{item.winner=="P"?P:(item.winner=="B"?B:T)}}</span>
                        
                        <div class="history-banker">
                        <span>{{item.bankercval}}</span>
                         <img :class="{'cardpic':true,'updown cardpic':item.cardbanker.length==3&&index===2}" v-for="(key,index) in item.cardbanker" v-bind:src="'/res/images/origin_small/S_'+['S','H','C','D'][key.type]+key.num+'.png'" alt="" style="height:35px;width:23px;">
                         </div>
                         
                        </td>
                        <td>{{item.winCash}}</td>
                        <td>{{item.winBalance}}</td>
                         
                    </tr>

                    <tr v-if='gameName=="DNT"' v-for="item in gameResult">
                        <td>{{item.time}}</td>
                        <td><p>{{dragonandtiger}}</p> <p>{{room}}:{{item.tableInfo}}</p><p>{{number_of_games}}:{{item.round}}</p></td>
                        <td>{{item.betCash}}</td>
                        <td>
                          <div class="history-player">
                        <img :class="{'cardpic':true,'updown cardpic':item.cardplayer.length==3&&index===0}" v-for="(key,index) in item.cardplayer" v-bind:src="'/res/images/origin_small/S_'+['S','H','C','D'][key.type]+key.num+'.png'" alt="" style="height:35px;width:23px;">
                        <span>{{item.playercval}}</span>
                        </div>
                        <span v-bind:class='{"winnerb":item.winner=="B","winnerp":item.winner=="P","winnert":item.winner=="T"}'>{{item.winner=="P"?DRAGON:(item.winner=="B"?TIGER:T)}}</span>
                        
                        <div class="history-banker">
                        <span>{{item.bankercval}}</span>
                         <img :class="{'cardpic':true,'updown cardpic':item.cardbanker.length==3&&index===2}" v-for="(key,index) in item.cardbanker" v-bind:src="'/res/images/origin_small/S_'+['S','H','C','D'][key.type]+key.num+'.png'" alt="" style="height:35px;width:23px;">
                         </div>
                         
                        </td>
                        <td>{{item.winCash}}</td>
                        <td>{{item.winBalance}}</td>
                         
                    </tr>
					
					<tr v-if='gameName=="ROULETTE"' v-for="item in gameResult">
                        <td>{{item.time}}</td>
                        <td><p>{{$t('Roulette')}}</p> <p>{{room}}:{{item.tableInfo}}</p><p>{{number_of_games}}:{{item.round}}</p></td>
                        <td>{{item.betCash}}</td>
                        <td>
                         {{item.winner}}
                         
                        </td>
                        <td>{{item.winCash}}</td>
                        <td>{{item.winBalance}}</td>
                         
                    </tr>
					
					<tr v-if='gameName=="SICBO"' v-for="item in gameResult">
                        <td>{{item.time}}</td>
                        <td><p>{{$t('SicBo')}}</p> <p>{{room}}:{{item.tableInfo}}</p><p>{{number_of_games}}:{{item.round}}</p></td>
                        <td>{{item.betCash}}</td>
                        <td>
                         {{item.winner}}
                         
                        </td>
                        <td>{{item.winCash}}</td>
                        <td>{{item.winBalance}}</td>
                         
                    </tr>


                    </table>

                </div>
               
            </div>
        </div>

    </div>

</template>
<style type="text/css">
th{
    text-indent: 0rem;
}
.table-container{
    width:100%;
}
    .gamehistory{
        width:100%;

    }
    .gamehistory th{
        width:15%;
        font-size:1.5rem;
        color:#1A6BE6;
        font-weight: 600;
        /* text-align: left; */

    }
    #history{
        margin:0 auto;
        width: 200px;
        display:block;
        font-size: 2rem;
        /* left: -50%; */
        padding: 1rem;
        text-align: center;

    }
    #aim table{
        width:100%;
    }
    .gamehistory td{
        width:15%;
        font-size:1.15rem;
        font-family: 微软雅黑;
        color:#f4ebe9;
        text-align: center;
        vertical-align: middle;
        text-indent: 0rem;
    }
        .gamehistory tr{
        border-bottom: 1px solid #808080;
    }
    .container .code-dialog .btn-close-1 {
    background: url("../res/images/ui_001.png") no-repeat -100px -917px;
    height: 37px;
    position: absolute;
    right: 2rem;
    top: 0.8rem;
    width: 37px;
    z-index: 210;
   }

   #cardsout{
    text-indent:0em;
    text-align: center;
    /* width:40%; */

   }
   .cardpic{
    vertical-align: middle;
    margin:1px;

   }
   .updown{
       
       transform:rotate(90deg);
       -ms-transform:rotate(90deg);    
       -moz-transform:rotate(90deg);   
       -webkit-transform:rotate(90deg);
       -o-transform:rotate(90deg);  
       position: relative;
       bottom:-6px;
       margin:0 6px 0 6px;
   }
   #payout{
    /* width: 10% !important; */
    min-width: 60px;
   }
   #payout-down{
    /* width: 7% !important; */
   }
   #history-head{
    border-bottom: 2px solid #1A6BE6 !important;
    width: 100%;
   }
   #asset{
  /* width:10%; */
   }
   .history-banker{   
    border:2px solid #EE0000 ;
    display: inline-block;
    padding:3px;
    position: relative;
    border-radius: 6px;
    
   }
   .history-player{
    border:2px solid #2222FF;
    display: inline-block;
    padding:3px;
    position: relative;
    border-radius: 6px;
   }
.history-player span{
  display: inline-block;
  height: 20px;
  width: 20px;
  position: absolute;
  left:-7px;
  top:-5px; 
  background-color:#2222FF;
  border-radius: 50%;
  color: white;
  vertical-align: center;
  line-height: 20px;
}
.history-banker span{
  display: inline-block;
  height: 20px;
  width: 20px;
  position: absolute;
  right:-7px;
  top:-5px; 
  background-color: #EE0000 ;
  border-radius: 50%;
  color: white;
  vertical-align: center;
  line-height: 20px;


}
.winnerb{
    color: white;
    font-family: 微软雅黑;
    background-color:#EE0000;
    display: inline-block;
    border:1px;
    border-radius: 2px;
}
.winnerp{
    color: white;
    font-family: 微软雅黑;
    background-color:   #2222FF;
    display: inline-block;
    border:1px;
    border-radius: 2px;

}
.winnert{
    color: white;
    font-family: 微软雅黑;
    background-color: #38B751;
    display: inline-block;
    border:1px;
    border-radius: 2px;
}
.load-box{
    font-size: 1.2rem;
    line-height: 2.2rem;
    color: #fff;
    text-indent: 2.8rem;
    position: absolute;
    top: 2rem;
    left: 0;
    right: 0;
    bottom: 0;
    margin: 2.4rem 1.2rem 2.2rem;
    overflow: auto;
}
</style>

 
<script>
 import Loading from "./Loading.vue"
    export default {
        data(){
            return {
                loading: false,
                showProtocol: false,
                showRule: false,
                ruleIndex: 0,
                tableStr:'',
                gameResult:[],
                B:this.$t('B'),
                P:this.$t('P'),
                T:this.$t('T'),
                baijiale:this.$t('BAIJIALE'),
                WINBALANCE:this.$t('WINBALANCE'),
                PAYOUT:this.$t('PAYOUT'),
                ANNOUNCE_OF_LOTTERY:this.$t('ANNOUNCE_OF_LOTTERY'),
                DATE:this.$t('DATE'),
                GAME:this.$t('GAME'),
                STAKE:this.$t('STAKE'),
                number_of_games:this.$t("NUMBER_OF_GAMES"),
                room:this.$t("ROOM"),
                GAME_HISTORY:this.$t("GAME_HISTORY"),
                gameName:'',
                dragonandtiger:this.$t("LIVE DRAGON TIGER"),
                TIGER:this.$t("TIGER"),
                DRAGON:this.$t("DRAGON"),
                loadbegin:0


            };
        },
        components: {
            Loading
        },
        created(){
            this.$parent.$on("show-history", (status) => {
                this.showProtocol = status;
                this.gameName=window.STORE.gameName;

            });
           this.$parent.$on("load-history", (gameResult) => {
				if(gameResult){
						this.loading=false;
					}
				this.gameResult= gameResult;
				var loadnewdata=document.getElementById('datacontainer');
				var loadbegin=this.gameResult.length>0?this.gameResult[this.gameResult.length-1].sno:'';
				this.loadbegin=loadbegin;
				loadnewdata.onscroll=(function (e){
					if(e.target.scrollHeight==e.target.scrollTop+e.target.offsetHeight){

					   this.$parent.$emit("load-new-history", loadbegin);

					}
				}).bind(this);
			});

            this.$parent.$on("show-rule", (status) => {
                this.showRule = status;
            });
            this.$parent.$on("loading", (status) => {
                this.loading = status;
            })

        },

    
    }



</script>
