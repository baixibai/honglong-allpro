/**
 * Created by ck on 1/14/2017.
 */
import Vue from 'vue'
import VueRouter from "vue-router"
import VueResource from "vue-resource"
import VueI18n from "vue-i18n"
import Utils from "./utils.js"

import Ws from "./ws.js"
import Login from "./Login.vue" // 登录
import Lobby from "./Lobby.vue" // 大厅
import Baccarat from "./Baccarat.vue" /// 百家乐大厅
import Room from "./Room.vue" /// 房间
import errorCode from "./error-code.js";

window.onresize=function(){
	let tip=document.getElementById('tip')
	if(tip){
		if(document.documentElement.clientWidth<document.documentElement.clientHeight){
			tip.style.display="block"
		}else{
			tip.style.display="none"
		}
	}
}
 
if (!String.prototype.padLeft) {
    String.prototype.padLeft = function (max, c) {
        let self = this;
        let len = max - self.length;
        if (len < 0)
            return self;
        if (c === undefined)
            c = ' ';
        while (len--)
            self = c + self;
        return self;
    };
}

let utils = {};

/**
 * 金额缩写
 * @param val {Number}
 * @param lang {String} 语言简称
 * @returns {String}
 */
utils.abbr = function (val, lang) {
    let int = String(Math.floor(val));
    let len = int.length;
    let result;
    
    switch (true) {
        /// billion / 十亿
        case len >= 10:
            result = Number(String(val).replace(/^(\d+)(\d{9})$/, '$1.$2')) + "B";
            break;
        /// million / 百万
        case len >= 8:
            result = Number(String(val).replace(/^(\d+)(\d{7})$/, '$1.$2')) + "M";
            break;
        /// 千
        case len >= 4:
            result = Number(String(val).replace(/^(\d+)(\d{3})$/, '$1.$2')) + "K";
            break;
        default:
            result = String(val);
    }
    return result;
};

utils.fullScreen = function (element) {
	var exitMethod = element.exitFullscreen || //W3C
	  element.mozCancelFullScreen ||  //Chrome等
	  element.webkitExitFullscreen || //FireFox
	  element.webkitExitFullscreen; //IE11
	  if (exitMethod) {
		exitMethod.call(element);
	  }
	var requestMethod = element.requestFullScreen || element.webkitRequestFullScreen || element.mozRequestFullScreen || element.msRequestFullScreen;
	if(requestMethod) { 
		requestMethod.call(element); 
	}else if (typeof window.ActiveXObject !== "undefined") {//for Internet Explorer
        var wscript = new ActiveXObject("WScript.Shell");
        if (wscript !== null) {
            wscript.SendKeys("{F11}");
        }
    }
	// document.getElementsByTagName('body')[0].style.transform="rotate(90deg)";
	if(window.orientation==180||window.orientation==0){
		// document.getElementsByTagName('body')[0].style.transform="rotate(90deg)";
	}
	if(window.orientation==90||window.orientation==-90){
		console.log("横屏状态！")
	}
};
// window.addEventListener("onorientationchange" in window ? "orientationchange" : "resize", this.fullScreen, false);
utils.computedWinner = function (num) {
    let winner = Number(num).toString(2).split("").reverse();
	if(winner.length>6){
		winner=winner.slice(0,6)
	}
    let winList = ["闲对", "庄对", "超级六", "闲", "庄", "和"]; /// #参照Room.vue中的gameResult方法
    let result = "";
    winner.forEach((el, index) => {
        if (index === 2)return;
		if (el - 1 === 0) result = winList[index];
    });
	result = result+winner.join("")
    return result;
};
utils.computedWinnerDT = function (num) {
    let winner =num;
    let winList = ["龙", "虎",  "和"]; /// #参照Room.vue中的gameResult方法
    let result = "";
    result = winList[winner];
    return result;
};

utils.computedWinner2 = function (num) {
    let winner = Number(num).toString(2).split("").reverse();
	if(winner.length>6){
		winner=winner.slice(0,6)
	}
    let winList = [null, null, null, "闲", "庄", "和"]; /// #参照Room.vue中的gameResult方法
    let result = "";
    winner.forEach((el, index) => {
        if (index === 2)return;
        if (el - 1 === 0 && winList[index]) result = winList[index];
    });
    return result;
};


utils.prevLoad = function (urls, callback) {
    let loaded = 0;
    urls.forEach(el => {
        let img = new Image();
        img.src = el;
        img.onload = () => loaded++;
        img.onerror = () => loaded++;
    });
    let f = setInterval(() => {
        if (loaded === urls.length) {
            clearInterval(f);
            callback();
        }
    }, 200);
};

/// 返回牌的点数
utils.getCardsValue = function (cards) {
    let total = 0;
    cards.forEach(el => {
        total += el.num > 9 ? 0 : el.num;
    });
    return String(total).substr(-1,1);
};
utils.getDTCardsValue = function (cards) {
    let total = 0;
    cards.forEach(el => {
        total += el.num;
    });
    return String(total);

};
utils.getCardsValueHistory = function (cards) {
    let total = 0;
    cards.forEach(el => {
        total += el > 9 ? 0 : el;
    });
    return String(total).substr(-1,1);
};
utils.getDTCardsValueHistory = function (cards) {
    let total = 0;
    cards.forEach(el => {
        total += el;
    });
    return String(total);
};



utils.changeLange = function (data) {
	let date=new Date()
	date.setTime(date.getTime()+10*24*3600*1000)
	document.cookie='language='+encodeURIComponent(data).replace(/!/g, '%21').replace(/'/g, '%27').replace(/\(/g, '%28').  
	replace(/\)/g, '%29').replace(/\*/g, '%2A').replace(/%20/g, '+')+'; path=/;expires='+date.toGMTString()
	let cnChips = [1, 5, 10, 20, 100, 500, 1000, 2000, 5000, 10000];
	
    STORE.nation.KRW=data
	let lang = STORE.nation.KRW;
	
	
	Vue.locale(lang, function () {
		return Vue.resource("./lang/" + lang + ".json?v="+Math.random()).get().then(res => res.json()).then(json => {
			if (Object.keys(json).length === 0) {
				return Promise.reject(new Error('locale empty !!'))
			} else {
				return Promise.resolve(json)
			}
		}).catch(err => {
			console.log(err);
			return Promise.reject();
		});
	}, () => {
		Vue.config.lang = lang;
	});
};

///获取单个cookies 
utils.getCookie = function(cookie_name)
{
	var acookie=document.cookie.split("; ")
    // alert(acookie)
	for(var i=0;i<acookie.length;i++){ 
		var arr=acookie[i].split("="); 
		if(cookie_name==arr[0]){ 
		if(arr.length>1) {
        
		return unescape(arr[1]); 
    }
		else {
		return ""; }
	}} 
	return ""; 
} 

utils.xmlToJson=function(xml) {
    // Create the return object
    // var obj = {};
    if (xml.nodeType == 1) { // element
        // do attributes
        if (xml.attributes.length > 0) {
        obj["@attributes"] = {};
        for (var j = 0; j < xml.attributes.length; j++) {
                var attribute = xml.attributes.item(j);
                obj["@attributes"][attribute.nodeName] = attribute.nodeValue;
            }
        }
    } else if (xml.nodeType == 3) { // text
    obj = xml.nodeValue;
    }
 
    // do children
    if (xml.hasChildNodes()) {
        for(var i = 0; i < xml.childNodes.length; i++) {
            var item = xml.childNodes.item(i);
            var nodeName = item.nodeName;
            if (typeof(obj[nodeName]) == "undefined") {
                obj[nodeName] = xmlToJson(item);
            } else {
                if (typeof(obj[nodeName].length) == "undefined") {
                    var old = obj[nodeName];
                    obj[nodeName] = [];
                    obj[nodeName].push(old);
                }
                obj[nodeName].push(xmlToJson(item));
            }
        }
    }
    return obj;
};


/// 控制声音播放
utils.playVoice = function (voiceurl,voicestyle) {
	if(voicestyle=="bgvoice"){
		// console.log(this.getCookie("voicebgstate"));
		if(this.getCookie("voicebgstate")=='true' || !this.getCookie("voicebgstate")){
			// console.log(voicestyle)
			let audio = new Audio(voiceurl);
			audio.play();
		} 
	}else{
		if(this.getCookie("voicetipstate")=='true' || !this.getCookie("voicetipstate")){
			let audio = new Audio(voiceurl);
			audio.play();
		} 
	}
	
};
utils.playVoice1 = function (audio) {
    document.addEventListener('DOMContentLoaded', function () {
		function audioAutoPlay() {
				audio.play();
			document.addEventListener("WeixinJSBridgeReady", function () {
				audio.play();
			}, false);
		}
		audioAutoPlay();
	});
	if(this.getCookie("voicetipstate")=='true' || !this.getCookie("voicetipstate")){
		audio.play();
	} 

    
};
utils.playbgVoice=function(voiceurl,voicestyle){
    if(voicestyle=="bgvoice"){
            let bgaudio = new Audio(voiceurl);
        if(this.getCookie("voicebgstate")=='true' || !this.getCookie("voicebgstate")){

            bgaudio.play();
        } else{
            bgaudio.pause();
        }
    }
};
utils.toLowerCase=function(value){
	return value.toLowerCase();
};
utils.fmoney=function(s, n) {
	n = n > 0 && n <= 20 ? n : 2;
	s = parseFloat((s + "").replace(/[^\d\.-]/g, "")).toFixed(n) + "";
	var l = s.split(".")[0].split("").reverse(), r = s.split(".")[1],t = "";
	for (var i = 0; i < l.length; i++) {
		t += l[i] + ((i + 1) % 3 == 0 && (i + 1) != l.length ? "," : "");
	}
	return t.split("").reverse().join("") + "." + r;
};
utils.LoadImg=function(){
	window.loadImg = (function loadImg(win,doc){
		function LoadImg(){
			this.s = {
				datasrc : 'src',
				onstart : function(){},
				progress : function(){},
				complete : function(){}
			};
		};
		LoadImg.prototype = {
			init : function(a,o){
				var _t = this;
				_t.source = a;
				_t.count = 0;
				_t.extend(_t.s,o);
				_t.s.onstart()
				if(_t.source[0].nodeName){
					_t.source = [];
					for(var i=0;i<a.length;i++){
						_t.source.push(a[i].getAttribute(_t.s.datasrc));
					};
				};
				_t.source.map(function(o) {
					/\.js$/.test(o) ? _t.script(o) : _t.image(o);	
				});
			},
			extend : function(n,n1){
				for(var i in n1){n[i] = n1[i]};
			},
			load : function(o){
				var _t = this,len = _t.source.length
				o.onload = o.onerror = o.onabort =function(){
					_t.count++;
					_t.s.progress(_t.count/len,_t.count-1);
					if(_t.count === len){
						_t.s.complete(_t.count);
						for(var i=0;i<3;i++){
							// doc.head.removeChild()
						}
					}
				};
			},
			image : function(o){
				var imgs = new Image();
				this.load(imgs);
				imgs.src = o;
			},
			script : function(o){
				var script = doc.createElement('script');  
				script.className =  'loadJS__cls';  
				script.src = o;  
				doc.head.appendChild(script);
				this.load(script)
			}
		};
		return {
			init : function(a,o){
				new LoadImg().init(a,o)
			}
		};
	})();
};
utils.isContained=function(a, b){
    if(!(a instanceof Array) || !(b instanceof Array)) return false;
    if(a.length < b.length) return false;
    var aStr = a.toString();
    for(var i = 0, len = b.length; i < len; i++){
       if(aStr.indexOf(b[i]) == -1) return false;
    }
    return true;
};
utils.geturlvalue=function(valuename){
	console.log(valuename)
	var args = {};
	var query = location.search.substring(1)||location.href.substring(location.href.indexOf('?')+1);
	var pairs = query.split('&');
	for(var i = 0; i < pairs.length; i++){
		var pos = pairs[i].indexOf('=');
		if(pos == -1) continue;
		var name = pairs[i].substring(0,pos);
		var value = pairs[i].substring(pos + 1);
		value = decodeURIComponent(value);
		args[name] = value;
	}  
	return args[valuename];
};

//咪牌
utils.openCard=function(data,ower,index,openindex,openturnStyle){
	if(data=="stop"){
		return false;
	}
	var css=function(t,s){
		s=document.createElement('style');
		s.innerText=t;
		document.body.appendChild(s);
	};

	var isTouch = 'ontouchstart' in window;
	var mouseEvents = (isTouch) ?
			{
			  down: 'touchstart',
			  move: 'touchmove',
			  up: 'touchend',
			  over: 'touchstart',
			  out: 'touchend'
			}
			:
			{
			  down: 'onmousedown',
			  move: 'onmousemove',
			  up: 'onmouseup',
			  over: 'onmouseover',
			  out: 'onmouseout'
			}
	var btn = document.getElementById('current_'+ower+'_'+index);
	if(btn==null){
		return false;
	}
	var zzimg = document.getElementById('zzimg_'+ower+'_'+index);	
	var hand1 = document.getElementById('hand_'+index+'_'+ower+'1');	
	var hand2 = document.getElementById('hand_'+index+'_'+ower+'2');	
	var hand3 = document.getElementById('hand_'+index+'_'+ower+'3');	
	var hand4 = document.getElementById('hand_'+index+'_'+ower+'4');	
	var hand5 = document.getElementById('hand_'+index+'_'+ower+'5');	
	var hand6 = document.getElementById('hand_'+index+'_'+ower+'6');	
	var hand7 = document.getElementById('hand_'+index+'_'+ower+'7');	
	var hand8 = document.getElementById('hand_'+index+'_'+ower+'8');	

	var drag1 = document.getElementById('area_'+index+'_'+ower+'1');
	var drag2 = document.getElementById('area_'+index+'_'+ower+'2');
	var drag3 = document.getElementById('area_'+index+'_'+ower+'3');
	var drag4 = document.getElementById('area_'+index+'_'+ower+'4');
	var drag5 = document.getElementById('area_'+index+'_'+ower+'5');
	var drag6 = document.getElementById('area_'+index+'_'+ower+'6');
	var drag7 = document.getElementById('area_'+index+'_'+ower+'7');
	var drag8 = document.getElementById('area_'+index+'_'+ower+'8');
	var turn = document.getElementById('turn');
	var turntop = turn.offsetTop;
	var handinit = function (){
		hand1.style.top = "-180px";
		hand2.style.top = "-180px";
		hand3.style.top = "-180px";
		hand4.style.top = "-180px";
		hand5.style.top = "-180px";
		hand6.style.top = "-180px";
		hand7.style.top = "-180px";
		hand8.style.top = "-180px";
	}
	let that=this;
	drag5.addEventListener(mouseEvents['down'],function(ev){ 
		hand1.style.display = "none";
		hand2.style.display = "none";
		hand3.style.display = "none";
		hand4.style.display = "none";
		hand5.style.display = "block";
		hand6.style.display = "none";
		hand7.style.display = "none";
		hand8.style.display = "none";
		zzimg.style.transform="rotate(90deg)";
		zzimg.style.top="70px";
		zzimg.style.left="70px";
		zzimg.style.zIndex="3";
		hand5.style.bottom="-40px";
		hand5.style.left="-30px";
		hand5.style.transform="rotate(60deg)";
		 //禁用手机默认的触屏滚动行为
		var ev = ev.touches[0];
		var top = (98-parseInt(zzimg.style.left))/2+'px';
		var top1 = 20+parseInt(zzimg.style.top)+'px';
		var top2 = parseInt(zzimg.style.top)-20+'px';
		css('.zzt::after{position: absolute;right: '+top2+';top: '+top1+';width: 0;content: "";display: block;border: '+top+' solid #7201aa; border-color: rgba(0,0,0, 1) rgba(0,0,0, 1) transparent transparent;}');
		drag5.addEventListener(mouseEvents['move'], function(ev){
			zzimg.style.top="70px";
			zzimg.style.left="70px";
			ev.preventDefault();
			var ev = ev.touches[0];
			zzimg.style.top=(ev.pageX-drag5.getBoundingClientRect().left+drag5.offsetLeft)+'px';
			zzimg.style.left=(ev.pageX-drag5.getBoundingClientRect().left+drag5.offsetLeft)+'px';
			var top = (98-parseInt(zzimg.style.left))/2+'px';
			var top1 = 20+parseInt(zzimg.style.top)+'px';
			var top2 = parseInt(zzimg.style.top)-20+'px';
			css('.zzt::after{position: absolute;right: '+top2+';top: '+top1+';width: 0;content: "";display: block;border: '+top+' solid #7201aa; border-color: rgba(0,0,0, 1) rgba(0,0,0, 1) transparent transparent;}');
			if(parseInt(zzimg.style.left)<20){
				zzimg.style.left = "20px";
				zzimg.style.top = "20px";
				css('.zzt::after{position: absolute;right: 0;top: 39px;width: 0;content: "";display: block;border: 40px solid #7201aa; border-color: rgba(0,0,0, 1) rgba(0,0,0, 1) transparent transparent;}');
			}
			// endTouchX = ev.pageX;
		},false)
		
	},false)
	drag5.addEventListener('touchend', function(ev){
		zzimg.style.zIndex="1";
		openturnStyle(index,ower,'5','74','74',parseInt(zzimg.style.top),parseInt(zzimg.style.left));
	},false)
	drag3.addEventListener(mouseEvents['down'],function(ev){ 
		hand1.style.display = "none";
		hand2.style.display = "none";
		hand3.style.display = "block";
		hand4.style.display = "none";
		hand5.style.display = "none";
		hand6.style.display = "none";
		hand7.style.display = "none";
		hand8.style.display = "none";
		zzimg.style.transform="rotate(-90deg)";
		zzimg.style.top="-70px";
		zzimg.style.left="70px";
		zzimg.style.zIndex="3";
		hand3.style.bottom="60px";
		hand3.style.left="-30px";
		hand3.style.transform="rotate(60deg)";
		 
		var ev = ev.touches[0];
		var top = (110-parseInt(zzimg.style.left))/2+'px';
		var top1 = 20+(-parseInt(zzimg.style.top))+'px';
		var top2 = -parseInt(zzimg.style.top)-23+'px';
		css('.zzt::after{position: absolute;right: '+top2+';top:-5px;width: 0;content: "";display: block;border: '+top+' solid #7201aa; border-color:transparent rgba(0,0,0, 1) rgba(0,0,0, 1) transparent;}');
		drag3.addEventListener('touchmove', function(ev){
			zzimg.style.top="-70px";
			zzimg.style.left="70px";
			ev.preventDefault();
			var ev = ev.touches[0];
			zzimg.style.top=-(ev.pageX-drag3.getBoundingClientRect().left+drag3.offsetLeft)+'px';
			zzimg.style.left=(ev.pageX-drag3.getBoundingClientRect().left+drag3.offsetLeft)+'px';
			var left = parseInt(zzimg.style.left)<20?20:parseInt(zzimg.style.left);
			var up = parseInt(zzimg.style.left)<20?-20:parseInt(zzimg.style.top);
			var top = (110-left)/2+'px';
			var top1 = 20+(-parseInt(zzimg.style.top))+'px';
			var top2 = -up-23+'px';
			css('.zzt::after{position: absolute;right: '+top2+';top: -5px;width: 0;content: "";display: block;border: '+top+' solid #7201aa; border-color:transparent rgba(0,0,0, 1) rgba(0,0,0, 1) transparent;}');
			if(parseInt(zzimg.style.left)<20){
				zzimg.style.left = "20px";
				zzimg.style.top = "-20px";
				css('.zzt::after{position: absolute;right: 2;top: -5px;width: 0;content: "";display: block;border: 100px solid #7201aa; border-color:transparent rgba(0,0,0, 1) rgba(0,0,0, 1) transparent;}');
			}
		},false)
		
	},false)
	drag3.addEventListener('touchend', function(ev){
		zzimg.style.zIndex="1";
		openturnStyle(index,ower,'3','-74','74',parseInt(zzimg.style.top),parseInt(zzimg.style.left));
	},false)
	
	drag6.addEventListener(mouseEvents['down'],function(ev){
		hand1.style.display = "none";
		hand2.style.display = "none";
		hand3.style.display = "none";
		hand4.style.display = "none";
		hand5.style.display = "none";
		hand6.style.display = "block";
		hand7.style.display = "none";
		hand8.style.display = "none";
		zzimg.style.transform="rotate(180deg)";
		zzimg.style.left="0px";
		zzimg.style.top="100px";
		btn.style.top = '20px';
		zzimg.style.zIndex="3";
		hand6.style.top="80px";
		hand6.style.left="0px";
		 
		css('.zzt::after{position: absolute;right: 0px;top: -5px;width: 0;content: "";display: block;border: 1px solid #7201aa; border-color:transparent rgba(0,0,0, 0) rgba(0,0,0, 0) transparent;}');
		drag6.addEventListener('touchmove', function(ev){
			zzimg.style.left="0px";
			zzimg.style.top="100px";		
			var ev = ev.touches[0];
			zzimg.style.top=(ev.pageY-turntop-50+1)+'px';
			var a1=120-parseInt(zzimg.style.top);
			btn.style.top=(a1+1)+'px';
			
			if(parseInt(zzimg.style.top)<1){
				openindex[ower][index] = index;
				zzimg.style.top = "0px";
			}
		},false)
		
	},false)
	drag6.addEventListener('touchend', function(ev){
		zzimg.style.zIndex="1";
		btn.style.top = '0px'
		openturnStyle(index,ower,'6','95','0',parseInt(zzimg.style.top),parseInt(zzimg.style.left));
	},false)
	drag2.addEventListener(mouseEvents['down'],function(ev){
		hand1.style.display = "none";
		hand2.style.display = "block";
		hand3.style.display = "none";
		hand4.style.display = "none";
		hand5.style.display = "none";
		hand6.style.display = "none";
		hand7.style.display = "none";
		hand8.style.display = "none";
		zzimg.style.transform="rotate(180deg)";
		zzimg.style.left="0px";
		zzimg.style.top="-100px";
		btn.style.top = '-20px';
		zzimg.style.zIndex="3";
		hand2.style.top="-30px";
		hand2.style.left="0px";
		hand2.style.transform="rotate(180deg)";
		 
		css('.zzt::after{position: absolute;right: 0px;top: -5px;width: 0;content: "";display: block;border: 1px solid #7201aa; border-color:transparent rgba(0,0,0, 0) rgba(0,0,0, 0) transparent;}');
		drag2.addEventListener('touchmove', function(ev){
			zzimg.style.left="0px";
			zzimg.style.top="-100px";
			var ev = ev.touches[0];
			zzimg.style.top=(ev.pageY-1)-turntop-120+'px';
			var a1=-parseInt(zzimg.style.top)-100;
			btn.style.top=a1+'px';
			if(parseInt(zzimg.style.top)>0){
				openindex[ower][index] = index;
				zzimg.style.top = "0px";
				btn.style.top = '0px'
			}
		},false)
		
	},false)
	drag2.addEventListener('touchend', function(ev){
		zzimg.style.zIndex="1";
		btn.style.top = '0px'
		openturnStyle(index,ower,'2','-84','0',parseInt(zzimg.style.top),parseInt(zzimg.style.left));
	},false)
	
	drag1.addEventListener(mouseEvents['down'],function(ev){ 
		hand1.style.display = "block";
		hand2.style.display = "none";
		hand3.style.display = "none";
		hand4.style.display = "none";
		hand5.style.display = "none";
		hand6.style.display = "none";
		hand7.style.display = "none";
		hand8.style.display = "none";
		zzimg.style.transform="rotate(-90deg)";
		zzimg.style.top="-70px";
		zzimg.style.left="-70px";
		zzimg.style.zIndex="3";
		hand1.style.bottom="-40px";
		hand1.style.left="-20px";
		hand1.style.transform="rotate(60deg)";
		 
		var ev = ev.touches[0];
		var top = (105+parseInt(zzimg.style.left))/2+'px';
		var top1 = 20+(-parseInt(zzimg.style.top))+'px';
		var top2 = -parseInt(zzimg.style.top)-23+'px';
		css('.zzt::after{position: absolute;right: '+top2+';top:'+top1+';width: 0;content: "";display: block;border: '+top+' solid #7201aa; border-color:rgba(0,0,0, 1) rgba(0,0,0, 1) transparent transparent;}');
		drag1.addEventListener('touchmove', function(ev){
			zzimg.style.top="-70px";
			zzimg.style.left="-70px";
			ev.preventDefault();
			var ev = ev.touches[0];
			zzimg.style.top=ev.pageX-drag1.getBoundingClientRect().left-80+'px';
			zzimg.style.left=ev.pageX-drag1.getBoundingClientRect().left-80+'px';
			var left = parseInt(zzimg.style.left)>-22?-22:parseInt(zzimg.style.left);
			var up = parseInt(zzimg.style.left)>-22?-22:parseInt(zzimg.style.top);
			var top = (105+left)/2+'px';
			var top1 = 20+(-parseInt(zzimg.style.top))+'px';
			var top2 = -up-23+'px';
			css('.zzt::after{position: absolute;right: '+top2+';top:'+top1+';width: 0;content: "";display: block;border: '+top+' solid #7201aa; border-color:rgba(0,0,0, 1) rgba(0,0,0, 1) transparent transparent;}');
			if(parseInt(zzimg.style.left)>-22){
				zzimg.style.left = "-20px";
				zzimg.style.top = "-20px";
				css('.zzt::after{position: absolute;right: -2px;top: 39px;width: 0;content: "";display: block;border: 41px solid #7201aa; border-color:rgba(0,0,0, 1) rgba(0,0,0, 1) transparent transparent;}');
			}
		},false)
		
	},false)
	drag1.addEventListener('touchend', function(ev){
		zzimg.style.zIndex="1";
		openturnStyle(index,ower,'1','-74','-74',parseInt(zzimg.style.top),parseInt(zzimg.style.left));
	},false)
	drag7.addEventListener(mouseEvents['down'],function(ev){ 
		hand1.style.display = "none";
		hand2.style.display = "none";
		hand3.style.display = "none";
		hand4.style.display = "none";
		hand5.style.display = "none";
		hand6.style.display = "none";
		hand7.style.display = "block";
		hand8.style.display = "none";
		zzimg.style.transform="rotate(-90deg)";
		zzimg.style.top="70px";
		zzimg.style.left="-70px";
		zzimg.style.zIndex="3";
		hand7.style.bottom="-40px";
		hand7.style.left="30px";
		hand7.style.transform="rotate(60deg)";
		 
		var ev = ev.touches[0];
		var top = (105+parseInt(zzimg.style.left))/2+'px';
		var top1 = 20+parseInt(zzimg.style.top)+'px';
		var top2 = -parseInt(zzimg.style.top)-23+'px';
		css('.zzt::after{position: absolute;right: 0px;top:'+top1+';width: 0;content: "";display: block;border: '+top+' solid #7201aa; border-color:rgba(0,0,0, 1) transparent transparent rgba(0,0,0, 1);}');
		drag7.addEventListener('touchmove', function(ev){
			zzimg.style.top="-70px";
			zzimg.style.left="-70px";
			ev.preventDefault();
			var ev = ev.touches[0];
			zzimg.style.top=drag7.getBoundingClientRect().left-ev.pageX+drag7.offsetTop+'px';
			zzimg.style.left=ev.pageX-drag7.getBoundingClientRect().left-drag7.offsetTop+'px';
			var left =parseInt(zzimg.style.left);
			var up = parseInt(zzimg.style.top);
			var top = (105+left)/2+'px';
			var top1 = 20+parseInt(zzimg.style.top)+'px';
			var top2 = -up-23+'px';
			css('.zzt::after{position: absolute;right: 0px;top:'+top1+';width: 0;content: "";display: block;border: '+top+' solid #7201aa; border-color:rgba(0,0,0, 1) transparent transparent rgba(0,0,0, 1);}');
			if(parseInt(zzimg.style.left)>-20){
				zzimg.style.left = "-20px";
				zzimg.style.top = "20px";
				css('.zzt::after{position: absolute;right: 0px;top: 40px;width: 0;content: "";display: block;border: 41px solid #7201aa; border-color:rgba(0,0,0, 1) transparent transparent rgba(0,0,0, 1);}');
			}
		},false)
		
	},false)
	drag7.addEventListener('touchend', function(ev){
		zzimg.style.zIndex="1";
		openturnStyle(index,ower,'7','87','-87',parseInt(zzimg.style.top),parseInt(zzimg.style.left));
	},false)
	
	drag8.addEventListener(mouseEvents['down'],function(ev){ 
		hand1.style.display = "none";
		hand2.style.display = "none";
		hand3.style.display = "none";
		hand4.style.display = "none";
		hand5.style.display = "none";
		hand6.style.display = "none";
		hand7.style.display = "none";
		hand8.style.display = "block";
		
		zzimg.style.top="0px";
		zzimg.style.left="-60px";
		zzimg.style.transform="rotate(0deg)";
		zzimg.style.zIndex="3";
		btn.style.left = '-20px';
		hand8.style.top="0px";
		hand8.style.left="50px";
		hand8.style.transform="rotate(180deg)";
		
		css('.zzt::after{position: absolute;right: -20px;top: 0px;width: 0;content: "";display: block;border: 1px solid #7201aa; border-color:transparent rgba(0,0,0, 0) rgba(0,0,0, 0) transparent;}');
		drag8.addEventListener('touchmove', function(ev){
			zzimg.style.top="0px";
			zzimg.style.left="-60px";		
			var ev = ev.touches[0];
			zzimg.style.left=ev.pageX-drag8.getBoundingClientRect().left-drag8.offsetTop-40+'px';
			//var a1=-25-(55+parseInt(zzimg.style.left));
			//btn.style.left=a1+'px';
			if(parseInt(zzimg.style.left)>1){
				openindex[ower][index] = index;
				zzimg.style.left = "0px";
				btn.style.left = "-80px";
			}
		},false)
		
	},false)
	drag8.addEventListener('touchend', function(ev){
		zzimg.style.zIndex="1";
		btn.style.left='0px';
		hand8.style.top="0px";
		hand8.style.left="0px";
	},false)
	
	drag4.addEventListener(mouseEvents['down'],function(ev){ 
		hand1.style.display = "none";
		hand2.style.display = "none";
		hand3.style.display = "none";
		hand4.style.display = "block";
		hand5.style.display = "none";
		hand6.style.display = "none";
		hand7.style.display = "none";
		hand8.style.display = "none";
		
		zzimg.style.top="-1px";
		zzimg.style.left="60px";
		zzimg.style.transform="rotate(180deg)";
		zzimg.style.zIndex="3";
		btn.style.left = '20px';
		hand4.style.top="0px";
		hand4.style.left="37px";
		hand4.style.transform="rotate(0deg)";
		
		css('.zzt::after{position: absolute;right: -20px;top: 0px;width: 0;content: "";display: block;border: 1px solid #7201aa; border-color:transparent rgba(0,0,0, 0) rgba(0,0,0, 0) transparent;}');
		drag4.addEventListener('touchmove', function(ev){
			zzimg.style.top="-1px";
			zzimg.style.left="60px";		
			var ev = ev.touches[0];
			zzimg.style.left=ev.pageX-drag4.getBoundingClientRect().left+drag4.offsetLeft+20+'px';
			//var a1=80-parseInt(zzimg.style.left);
			//btn.style.left=a1+'px';
			if(parseInt(zzimg.style.left)<1){
				openindex[ower][index] = index;
				zzimg.style.left = "0px";
				btn.style.left = "80px";
			}
		},false)
		
	},false)
	drag4.addEventListener('touchend', function(ev){
		zzimg.style.zIndex="1";
		btn.style.left='0px';
	},false)
	
	
};
//传递咪牌
utils.getCardaction=function(data){
	var css=function(t,s){
		s=document.createElement('style');
		s.innerText=t;
		document.body.appendChild(s);
	};
	if(data.contents!=null){
		if(data.contents.openindex!=null){
			console.log('231');
			this.openindex[data.contents.owner][data.contents.openindex] = data.contents.openindex;
			return false;
		}
		console.log(this.openindex);
	}
	this.owner = data.contents!=null?data.contents.owner:'';
	if(data.contents!=null){
		let owner = data.contents.owner;
		let cardindex = data.contents.cardindex;
		var hand1 = document.getElementById('hand_'+cardindex+'_'+owner+'1');	
		var hand2 = document.getElementById('hand_'+cardindex+'_'+owner+'2');	
		var hand3 = document.getElementById('hand_'+cardindex+'_'+owner+'3');	
		var hand4 = document.getElementById('hand_'+cardindex+'_'+owner+'4');	
		var hand5 = document.getElementById('hand_'+cardindex+'_'+owner+'5');	
		var hand6 = document.getElementById('hand_'+cardindex+'_'+owner+'6');	
		var hand7 = document.getElementById('hand_'+cardindex+'_'+owner+'7');	
		var hand8 = document.getElementById('hand_'+cardindex+'_'+owner+'8');
		var btn = document.getElementById('current_'+owner+'_'+cardindex);
		
		hand1.style.display = "none";
		hand2.style.display = "none";
		hand3.style.display = "none";
		hand4.style.display = "none";
		hand5.style.display = "none";
		hand6.style.display = "none";
		hand7.style.display = "none";
		hand8.style.display = "none";
		var areaNo=data.contents.index;
		
		var zzimg = document.getElementById('zzimg_'+owner+'_'+cardindex);
		var hand = document.getElementById('hand_'+cardindex+'_'+owner+areaNo);
		var moveimg = "#zzimg_"+owner+'_'+cardindex;
		var movecurrent = movecurrent+owner;
		if(areaNo=='1'){
			zzimg.style.transform="rotate(-90deg)";
			hand1.style.display = "block";
			hand.style.bottom="-40px";
			hand.style.left="-20px";
			hand.style.transform="rotate(60deg)";
			zzimg.style.top=data.contents.pre[0]+"px";
			zzimg.style.left=data.contents.pre[1]+"px";
			zzimg.style.zIndex="3";
		
			$(moveimg).animate({
			  top:data.contents.pre[2]+'px',
			  left:data.contents.pre[3]+'px',
			  zIndex:'1'
			},3000);
			$(".zzt::after").animate(css('.zzt::after{position: absolute;right: -2px;top: 39px;width: 0;content: "";display: block;border: 41px solid #7201aa; border-color: rgba(0,0,0, 1) rgba(0,0,0, 1) transparent transparent;}'),3000);
		}else if(areaNo=='2'){
			hand2.style.display = "block";
			zzimg.style.transform="rotate(180deg)";
			hand.style.top="-30px";
			hand.style.left="0px";
			hand.style.transform="rotate(180deg)";
			zzimg.style.top=data.contents.pre[0]+"px";
			btn.style.top=data.contents.pre[1]+"px";
			zzimg.style.zIndex="3";
			css('.zzt::after{position: absolute;right: -2px;top: 39px;width: 0;content: "";display: block;border: 0px solid #7201aa; border-color: rgba(0,0,0, 1) rgba(0,0,0, 1) transparent transparent;}')
			$(moveimg).animate({
			  top:data.contents.pre[2]+'px',
			  zIndex:'1'
			},3000);
			$(movecurrent).animate({
			  top:data.contents.pre[3]+'px',
			},3000);
		}else if(areaNo=='3'){
			hand3.style.display = "block";
			zzimg.style.transform="rotate(-90deg)";
			zzimg.style.top=data.contents.pre[0]+"px";
			zzimg.style.left=data.contents.pre[1]+"px";
			zzimg.style.zIndex="3";
			hand.style.bottom="60px";
			hand.style.left="-30px";
			hand.style.transform="rotate(60deg)";
			
			$(moveimg).animate({
			  top:data.contents.pre[2]+'px',
			  left:data.contents.pre[3]+'px',
			  zIndex:'1'
			},3000);
			$(".zzt::after").animate(css('.zzt::after{position: absolute;right: 2;top: -5px;width: 0;content: "";display: block;border: 100px solid #7201aa; border-color:transparent rgba(0,0,0, 1) rgba(0,0,0, 1) transparent;}'),3000);
		}else if(areaNo=='4'){
			hand4.style.display = "block";
			zzimg.style.transform="rotate(180deg)";
			hand.style.top="0px";
			hand.style.left="37px";
			hand.style.transform="rotate(0deg)";
			zzimg.style.left=data.contents.pre[1]+"px";
			zzimg.style.top="-1px";
			btn.style.left="0px";
			zzimg.style.zIndex="3";
			css('.zzt::after{position: absolute;right: -20px;top: 0px;width: 0;content: "";display: block;border: 1px solid #7201aa; border-color:transparent rgba(0,0,0, 0) rgba(0,0,0, 0) transparent;}');
			$(moveimg).animate({
			  left:data.contents.pre[3]+'px',
			  zIndex:'1'
			},3000);
		}else if(areaNo=='5'){
			hand5.style.display = "block";
			zzimg.style.transform="rotate(90deg)";
			zzimg.style.top=data.contents.pre[0]+"px";
			zzimg.style.left=data.contents.pre[1]+"px";
			zzimg.style.zIndex="3";
			hand.style.bottom="-40px";
			hand.style.left="-30px";
			hand.style.transform="rotate(60deg)";
			$(moveimg).animate({
			  top:data.contents.pre[2]+'px',
			  left:data.contents.pre[3]+'px',
			  zIndex:'1'
			},3000);
			$(".zzt::after").animate(css('.zzt::after{position: absolute;right: 0;top: 39px;width: 0;content: "";display: block;border: 40px solid #7201aa; border-color: rgba(0,0,0, 1) rgba(0,0,0, 1) transparent transparent;}'),3000);
		}else if(areaNo=='6'){
			hand6.style.display = "block";
			zzimg.style.transform="rotate(180deg)";
			hand.style.top="80px";
			hand.style.left="0px";
			hand.style.transform="rotate(180deg)";
			zzimg.style.top=data.contents.pre[0]+"px";
			zzimg.style.left="0px";
			btn.style.top=data.contents.pre[1]+"px";
			zzimg.style.zIndex="3";
			css('.zzt::after{position: absolute;right: -2px;top: 39px;width: 0;content: "";display: block;border: 0px solid #7201aa; border-color: rgba(0,0,0, 1) rgba(0,0,0, 1) transparent transparent;}')
			$(moveimg).animate({
			  top:data.contents.pre[2]+'px',
			  zIndex:'1'
			},3000);
			$(movecurrent).animate({
			  top:data.contents.pre[3]+'px',
			},3000);
		}else if(areaNo=='7'){
			hand7.style.display = "block";
			zzimg.style.transform="rotate(-90deg)";
			zzimg.style.top=data.contents.pre[0]+"px";
			zzimg.style.left=data.contents.pre[1]+"px";
			zzimg.style.zIndex="3";
			hand.style.bottom="-40px";
			hand.style.left="30px";
			hand.style.transform="rotate(60deg)";
			$(moveimg).animate({
			  top:data.contents.pre[2]+'px',
			  left:data.contents.pre[3]+'px',
			  zIndex:'1'
			},3000);
			$(".zzt::after").animate(css('.zzt::after{position: absolute;right: 0px;top: 40px;width: 0;content: "";display: block;border: 41px solid #7201aa; border-color:rgba(0,0,0, 1) transparent transparent rgba(0,0,0, 1);}'),3000);
		}else if(areaNo=='8'){
			hand8.style.display = "block";
			zzimg.style.transform="rotate(0deg)";
			hand.style.top="0px";
			hand.style.left="50px";
			hand.style.transform="rotate(180deg)";
			zzimg.style.left=data.contents.pre[1]+"px";
			zzimg.style.top="0px";
			btn.style.left="0px";
			zzimg.style.zIndex="3";
			css('.zzt::after{position: absolute;right: -2px;top: 39px;width: 0;content: "";display: block;border: 0px solid #7201aa; border-color: rgba(0,0,0, 1) rgba(0,0,0, 1) transparent transparent;}')
			$(moveimg).animate({
			  left:data.contents.pre[3]+'px',
			  zIndex:'1'
			},3000);
		}
		
		
		
		
	}
};

export default {
    install(Vue){
        Vue.directive("countdown", function (el, binding) {
            if (binding.value === binding.oldValue) return;
            clearInterval(el.dataset.interval);
            let remains = String(binding.value).split("-")[0];
			el.textContent = STORE.nation.KRW=='zh-CHS'?"等待":'wait';
            if (!/^\d+$/.test(remains)) {
                return el.textContent = remains;
            } else {
                remains = Math.floor(remains / 1000);
                if (remains === 0){return el.textContent = STORE.nation.KRW=='zh-CHS'?"等待":'wait';}
                el.textContent = (remains + '').padLeft(2, '0');
                el.dataset.interval = setInterval(() => {
                    remains -= 1;
                    //remains = remains <= 0 ? 0 : remains;
                    if (remains < 0) {	
                        el.textContent = STORE.nation.KRW=='zh-CHS'?"GAME":'GAME';
                        clearInterval(el.dataset.interval);
                    } else {
                        el.textContent = (remains + '').padLeft(2, '0');
                    }     
                   // utils.playbgVoice();
                }, 1000);
            }
        });
        Vue.filter("toLowerCase", function(value) {
			return value.toLowerCase();
		});
        Vue.prototype.$utils = utils;
        Vue.prototype.$goble = [];
    }
};
