import Vue from 'vue'
import VueRouter from "vue-router"
import VueResource from "vue-resource"
import VueI18n from "vue-i18n"
import Utils from "./utils.js"

import Ws from "./ws.js"
import Login from "./Login.vue" // 登录
import Lobby from "./Lobby.vue" // 大厅
import Baccarat from "./Baccarat.vue" /// 百家乐大厅
import Dragontiger from "./Dragontiger.vue" /// 百家乐大厅
import Baccaratturn from "./Baccaratturn.vue" 
import Room from "./Room.vue" /// 房间
import DtRoom from "./DtRoom.vue" 
import Roulette from "./Roulette.vue" 
import Rouleroom from "./Rouleroom.vue" 
import Sicbo from "./Sicbo.vue" 
import Sicboroom from "./Sicboroom.vue" 
import SideMenu from "./SideMenu.vue" 
import Baccaratvip from "./Baccaratvip.vue" 
import errorCode from "./error-code.js";


//获取cookie
let getCookie = function(cookie_name)
{
	var acookie=document.cookie.split("; ")
	for(var i=0;i<acookie.length;i++){ 
		var arr=acookie[i].split("=");  
		if(cookie_name==arr[0]){ 
		if(arr.length>1) 
		return unescape(arr[1]); 
		else 
		return ""; 
	}} 
	return ""; 
} 

let geturlvalue=function(valuename){
	var args = {};
	var query = location.search.substring(1)||location.href.substring(location.href.indexOf('?')+1);
	var pairs = query.split('&');
	for(var i = 0; i < pairs.length; i++){
		var pos = pairs[i].indexOf('=');
		if(pos == -1) continue;
		var name = pairs[i].substring(0,pos);
		var value = pairs[i].substring(pos + 1);
		value = decodeURIComponent(value);
		args[name] = value;
	}  
	return args[valuename];
};

// 判断浏览器语言
let browsertype=navigator.appName
let browserlang=''
if (browsertype=="Netscape"){
	 browserlang = navigator.language
}
else{
	 browserlang = navigator.userLanguage
}
browserlang = browserlang.substr(0,2)
const langtype = {
	'en' : 'en-US',
	'zh' : 'zh-CHS',
	'ko' : 'ko-KR',
}

const langcookie = {
	'en-us' : 'en-US',
	'zh-cn' : 'zh-CHS',
	'ko-kr' : 'ko-KR',
	'ja-jp' : 'ja-JP',
	'zh-tw' : 'zh-CHT',
}
let langnation = function(){
	if(geturlvalue('lang')){
		return langcookie[geturlvalue('lang')];
	}else if(getCookie('language')){
		return getCookie('language');
	}else{
		return langtype[browserlang];
	}
}
let cnChips = [1, 5, 10, 20, 100, 500, 1000, 2000, 5000, 10000];
window.STORE = {
    chips: {
        CNY: cnChips,
        HKD: cnChips,
        TWD: [1, 10, 50, 100, 200, 500, 1000, 5000, 10000, 50000],
        KRW: [100, 500, 1000, 5000, 10000, 50000, 100000, 500000, 1000000, 5000000],
        JPY: [1, 10, 100, 200, 1000, 5000, 10000, 50000, 100000, 200000],
        IDR: [10, 100, 1000, 5000, 10000, 50000, 100000, 200000, 500000, 1000000],
        THB: [5, 10, 100, 500, 1000, 2000, 5000, 10000, 20000, 50000],
        USD: [0.2, 0.5, 1, 5, 10, 50, 100, 500, 1000, 5000],
		EUR: [0.2, 0.5, 1, 5, 10, 50, 100, 500, 1000, 5000],
		GBP: [0.2, 0.5, 1, 5, 10, 50, 100, 500, 1000, 5000],
		MYR: cnChips,
    },
    nation: {
        KRW: langnation() //"KO-KR",
    }
	
}; /// 用于缓存数据

Vue.use(Utils);
Vue.use({
    install: (Vue) => {
        Vue.prototype.ERRORCODE = errorCode; /// 错误代码
    }
});
Vue.use(VueRouter);
Vue.use(VueResource);
Vue.use(VueI18n);


const router = new VueRouter({
    routes: [
        //{path: "/", component: App},
        {path: "/", component: Login},
        {path: "/lobby", component: Lobby, name: "lobby"},
        {path: "/baccarat", component: Baccarat},
        {path: "/room", component: Room, name: "room"},
        {path: "/dtroom", component: DtRoom, name: "DtRoom"},
        {path: "/dragontiger", component: Dragontiger, name: "Dragontiger"},
        {path: "/baccaratturn", component: Baccaratturn, name: "Baccaratturn"},
        {path: "/roulette", component: Roulette, name: "Roulette"},
        {path: "/rouleroom", component: Rouleroom, name: "Rouleroom"},
        {path: "/sicbo", component: Sicbo, name: "Sicbo"},
        {path: "/sicboroom", component: Sicboroom, name: "Sicboroom"},
        {path: "/sideMenu", component: SideMenu, name: "SideMenu"},
        {path: "/baccaratvip", component: Baccaratvip, name: "Baccaratvip"}
    ]
});

router.beforeEach((to, from, next) => {
    if (!window.STORE.token && to.path !== "/") {
        next("/");
    } else {
        next();
    }
});

      
let date=new Date();
date.setTime(date.getTime()+10*24*3600*1000)
document.cookie='language='+encodeURIComponent(STORE.nation.KRW).replace(/!/g, '%21').replace(/'/g, '%27').replace(/\(/g, '%28').  
replace(/\)/g, '%29').replace(/\*/g, '%2A').replace(/%20/g, '+')+'; path=/;expires='+date.toGMTString()

let lang = STORE.nation.KRW || 'zh-CHS';

Vue.locale(lang, function () { 
    return Vue.resource("./lang/" + lang + ".json?_="+Math.random()).get().then(res => res.json()).then(json => {
		console.log(json)
        if (Object.keys(json).length === 0) {
            return Promise.reject(new Error('locale empty !!'))
        } else {
            return Promise.resolve(json)
        }
    }).catch(err => {
        return Promise.reject();
    });
}, () => {
    Vue.config.lang = lang;
    //const app = new Vue({router}).$mount("#app");
	
    let ws = new Ws("ws://game.be1888.com:24500", router);
    // let ws = new Ws("ws://h5api.belcdev.com:24500", router);
    Vue.use(ws);
    ws.connect((err) => {
        if (err) return console.log("连接错误", err);
        const app = new Vue({
            router
        }).$mount("#app");
    });
});



