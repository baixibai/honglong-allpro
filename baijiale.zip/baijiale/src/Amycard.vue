<template>
    <div style="font-size:20px;color:red;position:absolute;z-index:999999999;top:10px;left:15px;" v-show="player.length>0">
        {{player.length>0?player[0].num:''}}
	</div>
</template>
<style>
.divLoadWrap{width: 100%; height: auto;overflow: hidden;}
.divLoadWrap img{width: 100px;height: 100px; position: relative; z-index: 10 }
.loadImgWrap p{ text-align: center!important;margin-top: 20px;}
.divLoadWrap div.list{float: left;width: 100px;height: 100px;margin:5px; border:1px solid #ccc;padding: 1px;overflow: hidden; position: relative;background: #222}
.loadImgWrap{width: 100%;height: 100%; text-align: center;background: rgba(0,0,0,.95); position: fixed; left: 0px; top: 0; color: #fff;font-size: 16px;transition:all 1s .1s ease;-moz-transition:all 1s  .1s ease;-webkit-transition:all 1s  .1s ease;display: none; z-index: 999999}
.loadImgWrap .cons div{display: inline-block;width: 94%;height: 12px; background: #fff; border-radius: 5px;overflow: hidden;margin-bottom: 0px!important;}
.loadImgWrap  .cons div em{display: block;width: 0%; background: red;height: 100%;border-radius: 5px;
transition:all 0.2s ease;-moz-transition:all 0.2s ease;-webkit-transition:all 0.2s ease;
}
.loadImgWrap span{width: 200px;display: inline-block;}
.loadImgWrap .cons{position: absolute; width: 300px;height: 80px; top: 50%;margin-top: -40px;left:50%;margin-left:-150px;}
.startLoadimg{display: block;width: 160px;height: 45px;font-size: 16px; border:none; background: #000;color: #fff;cursor: pointer;margin-bottom: 20px;}
.divLoadWrap div.list:after{
content: '';display: block;
width: 36px;height: 36px; border:2px solid rgba(0,255,255,.2); border-radius: 50%; border-top-color:rgba(0,255,255,1);
-webkit-animation: turn 1s linear infinite; position: absolute; left: 50%;top:50%;margin-left: -18px;margin-top: -18px;
-moz-animation: turn 1s linear infinite;
}
@-webkit-keyframes turn
{
0%   {-webkit-transform:rotate(0deg)}
100% {-webkit-transform:rotate(360deg)}
}
@-moz-keyframes turn
{
0%   {-moz-transform:rotate(0deg)}
100% {-moz-transform:rotate(360deg)}
}
	</style>
<script>
  // import $ from 'jquery'
    export default{
		props:{
			player: {},
		},
        data(){
        },
        watch: {
           
        },
		created(){
			
        },
		mounted(){
        },
        methods: {
			
        }
    }
</script>
