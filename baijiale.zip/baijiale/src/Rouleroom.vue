<template>
    <div class="full-height">
        <div class="content">
            <!--loading -->
            <div class="mask" style="display:none;"></div>
            <div id="load" class="loading" style="display:none;">
                <div class="circle01">
                    <div class="circle02"></div>
                </div>
            </div>
            <!--loading  end -->
            <!--玩家介面-->
            <div class="menu-close" style="display: none"></div>
            <header class="header clear-fix">
                <!--视讯-->
                <canvas id="VIDEO" class="streaming-box" style="z-index:-1" @click="videoreturn()"></canvas>
                <!--<video class="streaming-box">
                    <source />
                </video>
                <img src="images/bg/video-bg.jpg" alt="" class="streaming-box" />-->
                <!--上-->
                <div><a class="btn btn-menu" @click="showSideMenu=true"></a></div>
                <Notice></Notice>
                <div class="playerinfo-box">
                    <div class="userid">{{userInfo.name}}</div>
                    <div class="usermoney">
                        {{userInfo.currency}}<span style="margin-left:0.5rem">{{userInfo.credit}}</span>
                    </div>
                </div>
                <!--<div class="signal-box type2"></div>-->
            </header>
            <!--左
            <div class="menu-left">
                <a class="btn" @click="showRoad=showRoad===1?0:1" v-bind:class="[showRoad===1?'active':'','btn-big-'+language]"></a>
                <a class="btn" @click="showRoad=showRoad===2?0:2" v-bind:class="[showRoad===2?'active':'','btn-path-'+language]"></a>
                <a class="btn" @click="showRoad=showRoad===3?0:3" v-bind:class="[showRoad===3?'active':'','btn-eye-'+language]"></a>
                <a class="btn" @click="showRoad=showRoad===4?0:4" v-bind:class="[showRoad===4?'active':'','btn-small-'+language]"></a>
                <a class="btn" @click="showRoad=showRoad===5?0:5" v-bind:class="[showRoad===5?'active':'','btn-road-'+language]"></a>
            </div>-->
            <!--右-->
            <div class="menu-right" id="menu-right">
                <!--按钮列表-->
                <audio id='audiobg' preload="auto" loop="loop" src="../res/audio/bgm/BeatriceBlossom.mp3"></audio>
                <audio id='countsec' src="../res/audio/effect/countdown.mp3"></audio>
                <audio id='flipcard'   src="../res/audio/effect/flipcard.mp3"></audio>
                <audio id='chipsup' src="../res/audio/effect/chips.mp3"></audio>
                <audio id='chipsdown' src="../res/audio/game/click_chip.mp3"></audio>
                <audio id='resultturn'  v-bind:src="resultturn"></audio>
                <audio id='playervoic' :src="PLAYER_HAS_VOICE"></audio>
                <audio id='bankervoic' :src="BANKER_HAS_VOICE"></audio>
                <audio id='BankerWins' :src="BANKER_WIN_VOICE"></audio>
                <audio id='PlayerWins' :src="PLAYER_WIN_VOICE"></audio>
                <audio id='placeBet' :src="PLACE_YOUR_BETS_VOICE"></audio>
                <audio id='noBet' :src="NO_YOUR_BETS_VOICE"></audio>
                <audio id='Tiewins' :src="tie_win"></audio>
                </a>
            </div>
            <!--对话内容-->
            <div class="message-box">
            </div>
            <!--打赏排行榜-->
            <div></div>
            <!--旁观玩家-->
            <div></div>
            <!--筹码选择-->
            <div class="bottomfunction-box">
               <!-- <a class="btn btn-pataward" @click="showLimitsModal=!showLimitsModal"></a>-->
                <div class="chips-box">
                    <a class="btn" v-for="chip in chips.slice(chipsIndex,chipsIndex+3)" v-bind:class="[chip.toString().split('.').length>1?'btn-chip'+chip.toString().split('.').join('_'):'btn-chip'+chip,selectedChip-chip===0?'select':'']"
                       @click="changechips(chip,selectedChip)"></a>
                    <div class="chipcustom-box" v-bind:class="{select:customChip-0>0}">
                        <a class="btn btn-chipCustom">
                            <span><input id="CustomChip" type='number' v-model="customChip" v-bind:disabled="!showCustomChip" @blur="saveCustomChip"></span>
							<!--<span>{{customChip}}</span>-->
                        </a>
                        <a class="btn btn-edit" @click="editCustomChip"></a>
                    </div>
                    <a class="slick-arrow slick-prev" @click="slideChips(-1)"></a>
                    <a class="slick-arrow slick-next" @click="slideChips(1)"></a>
                </div>
				<a class="resbet"  v-show="showRemains" @click="resbet()">{{$t("RE_BET")}}</a>
            </div>
			<!--轮盘下注区-->
			<div class="roulebet">
				<div class="r_bet">
					<div class="r_bgleft">
						<div class="r_bgh3 bggreen">0</div>
					</div>
					<div class="r_bgcenter">
						<div class="r_bgh3w3 bgred" id="a3">3</div>
						<div class="r_bgh3w3 bgblack" id="a6">6</div>
						<div class="r_bgh3w3 bgred" id="a9">9</div>
						<div class="r_bgh3w3 bgred" id="a12">12</div>
						<div class="r_bgh3w3 bgblack" id="a15">15</div>
						<div class="r_bgh3w3 bgred" id="a18">18</div>
						<div class="r_bgh3w3 bgred" id="a21">21</div>
						<div class="r_bgh3w3 bgblack" id="a24">24</div>
						<div class="r_bgh3w3 bgred" id="a27">27</div>
						<div class="r_bgh3w3 bgred" id="a30">30</div>
						<div class="r_bgh3w3 bgblack" id="a33">33</div>
						<div class="r_bgh3w3 brnone bgred" id="a36">36</div>
						<div class="r_bgh3w3 bgblack" id="a2">2</div>
						<div class="r_bgh3w3 bgred" id="a5">5</div>
						<div class="r_bgh3w3 bgblack" id="a8">8</div>
						<div class="r_bgh3w3 bgblack" id="a11">11</div>
						<div class="r_bgh3w3 bgred" id="a14">14</div>
						<div class="r_bgh3w3 bgblack" id="a17">17</div>
						<div class="r_bgh3w3 bgblack" id="a20">20</div>
						<div class="r_bgh3w3 bgred" id="a23">23</div>
						<div class="r_bgh3w3 bgblack" id="a26">26</div>
						<div class="r_bgh3w3 bgblack" id="a29">29</div>
						<div class="r_bgh3w3 bgred" id="a32">32</div>
						<div class="r_bgh3w3 brnone" id="a35">35</div>
						<div class="r_bgh3w3 bgred" id="a1">1</div>
						<div class="r_bgh3w3 bgblack" id="a4">4</div>
						<div class="r_bgh3w3 bgred" id="a7">7</div>
						<div class="r_bgh3w3 bgblack" id="a10">10</div>
						<div class="r_bgh3w3 bgblack" id="a13">13</div>
						<div class="r_bgh3w3 bgred" id="a16">16</div>
						<div class="r_bgh3w3 bgred" id="a19">19</div>
						<div class="r_bgh3w3 bgblack" id="a22">22</div>
						<div class="r_bgh3w3 bgred" id="a25">25</div>
						<div class="r_bgh3w3 bgblack" id="a28">28</div>
						<div class="r_bgh3w3 bgblack" id="a31">31</div>
						<div class="r_bgh3w3 brnone bgred" id="a34">34</div>
						<div class="r_bgh3w12"><p class="s1">{{$t("FRIST_R")}}</p><p class="s2">1st 12</p></div>
						<div class="r_bgh3w12"><p class="s1">{{$t("SECOND_R")}}</p><p class="s2">2nd 12</p></div>
						<div class="r_bgh3w12 brnone"><p class="s1">{{$t("THREE_R")}}</p><p class="s2">3rd 12</p></div>
						<div class="r_bgh3w6"><p class="s1">{{$t("SMALL")}}</p><p class="s2">(1to18)</p></div>
						<div class="r_bgh3w6"><p class="s1">{{$t("EVEN")}}</p><p class="s2">Even</p></div>
						<div class="r_bgh3w6 bgred"><p class="s1">{{$t("RED")}}</p><p class="s2">Red</p></div>
						<div class="r_bgh3w6 bgblack"><p class="s1">{{$t("BLACK")}}</p><p class="s2">Black</p></div>
						<div class="r_bgh3w6"><p class="s1">{{$t("ODD")}}</p><p class="s2">Odd</p></div>
						<div class="r_bgh3w6 brnone"><p class="s1">{{$t("BIG")}}</p><p class="s2">(19to36)</p></div>
					</div>
					<div class="r_bgright">
						<div class="r_bgh3w3"><p class="s1">{{$t("THREE_L")}}</p><p class="s2">2tol</p></div>
						<div class="r_bgh3w3"><p class="s1">{{$t("SECOND_L")}}</p><p class="s2">2tol</p></div>
						<div class="r_bgh3w3"><p class="s1">{{$t("FRIST_L")}}</p><p class="s2">2tol</p></div>
					</div>
					<div class="areabet">
						<a v-bind:class="el.className2"  v-for="el in betters"  @click="addAmount(el)">
							<i class="chips-item" v-for="(chip,index) in el.hasBetted.concat(el.chips).slice(-4)" v-bind:style="{top:-(5*index)+'px'}" v-bind:class="chip.toString().split('.').length>1?'chip'+chip.toString().split('.').join('_'):'chip'+chip">
							&nbsp;</i>
							<span class="selfbet type1" v-show="el.hasBetted.concat(el.chips).length>0 && el.chipstatus">{{el.amount+el.history}}<i class="unchecked"></i></span>
						</a>
						<div class="betleft" @click="openbetinfo()">
							<span>{{$t("MIN_LIMIT")}}:{{this.bet_limit.bet_min / 100}}</span>
							<span>{{$t("MAX_LIMIT")}}:{{(this.bet_limit.bet_max / 100)/1000}}K</span>
						</div>
						<div class="betright">
							<span>{{$t("MY_BET")}}:{{totalAmount>10000?(totalAmount/1000)+'K':totalAmount}}</span>
							<span>{{$t("TOTAL_BET")}}:{{Allamount>10000?(Allamount/1000)+'K':Allamount}}</span>
						</div>
					</div>
					
				</div>
			</div>
			<div class="roulearea" @click="videoclick()">
				<div class="ra_left" style="margin-top:5px;">
					<img src="/res/images/currenthot.png" style="height:7rem;" />
					<div class="hotbox">
						<p>{{$t("HOT")}}</p>
						<div class="number">
							<span v-for="item in hotdata">{{item}}</span>
						</div>
						<p style="background:#2A6DAD;">{{$t("COLD")}}</p>
						<div class="number blue">
							<span v-for="item in nohotdata">{{item}}</span>
						</div>
					</div>
				</div>
				<div class="ra_center" v-show="showRemains">
					<div class="betimg">
						<div v-bind:class="el.className2"  v-for="(el,index) in allbetters"  @click="moreAmount(el,index)"><span :style="language=='cn'?{textAlign:'right'}:''">{{el.name}}</span></div>
					</div>
				</div>
				<div class="ra_right" style="width:11.0rem;">
					<div class="hginfo">
						<span class="le">{{$t("DEALER")}}:{{dealer}}</span>
						<span class="ri">{{$t("GAME_ROUND")}}:{{round}}</span>
					</div>
					<div class="roule-waybill" style="top:3px;">
						<div>
							<div v-html="road.bead"></div>
						</div>
					</div>
				</div>
			</div>
            <!--<div class="desktop-bg"></div>-->
           

            <!--荷官
            <div class="dealer-box">
                <div class="dealer-pic">
                    <img v-bind:src="'http://dealerpix.belcsc201602.com/east/'+$utils.toLowerCase(dealer)+'.jpg'"/>
                </div>
                <div class="dealer-info">
                    <div class="name">{{dealer}}</div>
                    <div class="gametype">{{''}}</div>
                    <div class="id">{{number_of_games}}: {{round}}</div>
                </div>
            </div>-->

            <!--右下角下注确认-->
            <div class="betcheck-box">
                <!--<a class="btn btn-repeat show"></a>-->
                <a :class="'btn '+language +' '+'btn-confirm show'" v-show="betstatus" @click="bet"></a>
                <a :class="'btn '+language +' '+'btn-cancel show'" v-show="betstatus" @click="cancelBet"></a>
				<a :class="'btn '+language +' '+'btn-confirm show'" v-show="unbetstatus"  style="-webkit-filter: grayscale(100%);-moz-filter: grayscale(100%);-ms-filter: grayscale(100%);-o-filter: grayscale(100%);filter: grayscale(100%);filter: gray;"></a>
                <a :class="'btn '+language +' '+'btn-cancel show'" v-show="unbetstatus" @click="cancelBet"></a>
                <!--<a class="btn btn-delete"></a>-->
                <!--<a class="btn btn-end"></a>-->
            </div>
            <!--下注倒数-->
            <div class="countdown-box roulecount" v-show="showRemains">
                <div class="wrapper">
                    <div class="back"></div>
                    <div class="pie spinner"></div>
                    <div class="pie filler"></div>
                    <div class="mask"></div>
                    <div class="time-text">
                        <span class="time" id='countDown' v-countdown="remains">2</span>
                        <span class="text">{{betting_please}}</span>
                    </div>
                </div>
            </div>
			
            

            <div class="pataward-box">
                <div class="item">
                    <i></i>
                </div>
                <div class="item">
                    <i></i>
                </div>
                <div class="item">
                    <i></i>
                </div>
            </div>

            <!--提示框-->
            <div class="ui-dialog" v-show="tip">
                <a href="javascript:;" class="close-btn" @click="tip=null">x</a>
                <div class="d-body succeed-con">{{tip}}</div>
            </div>

            <!--房间限额-->
            <div class="xiane-dialog" v-show="showLimitsModal">
                <a class="btn btn-close" @click="showLimitsModal=false"></a>
                <div class="title">{{room_limit}}</div>
                <table>
                    <thead>
                    <tr>
                        <th>{{designation}}</th>
                        <th>{{odds1}}</th>
                        <th>{{Minimum_bet}}</th>
                        <th>{{Maximum_bet}}</th>
                    </tr>
                    </thead>
                    <tbody>
                    <tr v-for="item in limits">
                        <td>{{item.title}}</td>
                        <td>{{item.odds.join(" : ")}}</td>
                        <td>{{item.min}}</td>
                        <td>{{item.max}}</td>
                    </tr>
                    </tbody>
                </table>
            </div>

            <!--派奖效果-->
            <div class="paicaiinfo-box" style="display:none;" v-show="winTotalAmount>0">
                <div class="paicai-box">
                    <div class="paicai-pic"></div>
                    <div :class="'getno-box'+' '+language">
                        <span>{{winTotalAmount}}</span>
                    </div>
                </div>
            </div>

            
	
		<div class="record-dialog" style="background: rgba(0,0,0,0.8);" v-show="resultstatus">
			<a href="javascript:;" class="close-btn" @click=""></a>
			<div class="recordscontent">
				<div class="recordsmode" id="resulttu">
					<span class="titlename" style="width:100%;text-align:center;"><i :class="turnresultcolor" style="width:25px;height:25px;border-radius:50%;line-height:26px;margin-right:5px;text-align:center;color:#fff;display:inline-block;">{{turnresultnum}}</i>{{turnresulttype}},{{turnresultrank}}</span>
					<span class="titlename" style="width:100%;text-align:center;">{{$t("WIN")}}：{{turnresultprize}}</span>
				</div>
			</div>
		</div>
		<div class="voice-dialog" v-show="supersixstate==true">
			<div class="voicecontent">
				<div class="voicemode">
					<span class="titlename">{{supertitle}}：</span>
					<div id="applebtn" class="open1" v-bind:class="{ 'open1' : isA, 'close1': !isA}">
						<div id="applecon" v-bind:class="{ 'open2' : isA, 'close2': !isA}" class="open2" @click="toggleState"></div>
					</div>
				</div>
			</div>
		</div>
		<div class="dialogbetinfo" style="display:none;">
			<p class="title" @click="closebetinfo()">{{$t("BET_INFO")}}<span>X</span></p>
			<ul class="limitbox">
				<li>
					<p><span class="left">Straight</span><span class="right">35 to 1</span></p>
					<p><span class="left">{{$t("MIN_LIMIT")}}</span><span class="right">{{bet_limitbox.bet_straight_min / 100}}</span></p>
					<p><span class="left">{{$t("MAX_LIMIT")}}</span><span class="right">{{(bet_limitbox.bet_straight_max / 100)/1000}}K</span></p>
				</li>
				<li>
					<p><span class="left">Split</span><span class="right">17 to 1</span></p>
					<p><span class="left">{{$t("MIN_LIMIT")}}</span><span class="right">{{bet_limitbox.bet_split_min / 100}}</span></p>
					<p><span class="left">{{$t("MAX_LIMIT")}}</span><span class="right">{{(bet_limitbox.bet_split_max / 100)/1000}}K</span></p>
				</li>
				<li>
					<p><span class="left">Street</span><span class="right">11 to 1</span></p>
					<p><span class="left">{{$t("MIN_LIMIT")}}</span><span class="right">{{bet_limitbox.bet_street_min / 100}}</span></p>
					<p><span class="left">{{$t("MAX_LIMIT")}}</span><span class="right">{{(bet_limitbox.bet_street_max / 100)/1000}}K</span></p>
				</li>
				<li>
					<p><span class="left">Corner/Four</span><span class="right">8 to 1</span></p>
					<p><span class="left">{{$t("MIN_LIMIT")}}</span><span class="right">{{bet_limitbox.bet_corner_min / 100}}</span></p>
					<p><span class="left">{{$t("MAX_LIMIT")}}</span><span class="right">{{(bet_limitbox.bet_corner_max / 100)/1000}}K</span></p>
				</li>
				<li>
					<p><span class="left">Line</span><span class="right">5 to 1</span></p>
					<p><span class="left">{{$t("MIN_LIMIT")}}</span><span class="right">{{bet_limitbox.bet_line_min / 100}}</span></p>
					<p><span class="left">{{$t("MAX_LIMIT")}}</span><span class="right">{{(bet_limitbox.bet_line_max / 100)/1000}}K</span></p>
				</li>
				<li>
					<p><span class="left">Column</span><span class="right">2 to 1</span></p>
					<p><span class="left">{{$t("MIN_LIMIT")}}</span><span class="right">{{bet_limitbox.bet_column_min / 100}}</span></p>
					<p><span class="left">{{$t("MAX_LIMIT")}}</span><span class="right">{{(bet_limitbox.bet_column_max / 100)/1000}}K</span></p>
				</li>
				<li>
					<p><span class="left">Dozen</span><span class="right">2 to 1</span></p>
					<p><span class="left">{{$t("MIN_LIMIT")}}</span><span class="right">{{bet_limitbox.bet_dozen_min / 100}}</span></p>
					<p><span class="left">{{$t("MAX_LIMIT")}}</span><span class="right">{{(bet_limitbox.bet_dozen_max / 100)/1000}}K</span></p>
				</li>
				<li>
					<p><span class="left">1 - 18</span><span class="right">1 to 1</span></p>
					<p><span class="left">{{$t("MIN_LIMIT")}}</span><span class="right">{{bet_limitbox.bet_lowhigh_min / 100}}</span></p>
					<p><span class="left">{{$t("MAX_LIMIT")}}</span><span class="right">{{(bet_limitbox.bet_lowhigh_max / 100)/1000}}K</span></p>
				</li>
				<li>
					<p><span class="left">19 - 36</span><span class="right">1 to 1</span></p>
					<p><span class="left">{{$t("MIN_LIMIT")}}</span><span class="right">{{bet_limitbox.bet_min / 100}}</span></p>
					<p><span class="left">{{$t("MAX_LIMIT")}}</span><span class="right">{{(bet_limitbox.bet_max / 100)/1000}}K</span></p>
				</li>
				<li>
					<p><span class="left">Red/Black</span><span class="right">1 to 1</span></p>
					<p><span class="left">{{$t("MIN_LIMIT")}}</span><span class="right">{{bet_limitbox.bet_redblack_min / 100}}</span></p>
					<p><span class="left">{{$t("MAX_LIMIT")}}</span><span class="right">{{(bet_limitbox.bet_redblack_max / 100)/1000}}K</span></p>
				</li>
				<li>
					<p><span class="left">Even/Odd</span><span class="right">1 to 1</span></p>
					<p><span class="left">{{$t("MIN_LIMIT")}}</span><span class="right">{{bet_limitbox.bet_evenodd_min / 100}}</span></p>
					<p><span class="left">{{$t("MAX_LIMIT")}}</span><span class="right">{{(bet_limitbox.bet_evenodd_max / 100)/1000}}K</span></p>
				</li>
				<li>
					<p><span class="left"></span><span class="right"></span></p>
					<p><span class="left"></span><span class="right"></span></p>
					<p><span class="left"></span><span class="right"></span></p>
				</li>
			</ul>
		</div>
        <SideMenu :show="showSideMenu" :backToLobby="true" :ruleMenu="true" v-on:showMenu="showMenu"  :roomMenu="true"></SideMenu>
        <RuleProtocol :gameID="gameID">  </RuleProtocol>
        <RouleRoomProtocol :roomID="roomID">  </RouleRoomProtocol>
        <GameHistory></GameHistory>
		<NoticeControl :voiceProtocol="voicestate"></NoticeControl>
		<div class="loadImgWrap">
			<div class="cons">
				<div><em></em></div>
				<p><span>0%</span>
			</div>
		</div>
    </div>
</template>

<script>
    import GameHistory from "./GameHistory.vue"
    import Loading from "./Loading.vue"
    import SideMenu from "./SideMenu.vue"
    import Notice from "./Notice.vue"
    import Waybill from "./waybill"
    import RuleProtocol from "./RuleProtocol.vue"
    import RouleRoomProtocol from "./RouleRoomProtocol.vue"
	import NoticeControl from "./NoticeControl.vue"
    let TEMP = {};
    export default {
        data(){
            return {
                togglebgAudio:this.$utils.getCookie('voicebgstate'),
				language:this.$t("LANGUAGE_TYPE"),
                loading: true,
                room_limit:this.$t("ROOM_LIMIT"),
                number_of_games:this.$t("NUMBER_OF_GAMES"),
                designation:this.$t("DESIGNATION"),
                odds1:this.$t("ODDS"),
                Maximum_bet:this.$t("MAXIMUM_BET"),
                Minimum_bet:this.$t("MINIMUM_BET"),
                betting_please:this.$t("BETTING_PLEASE"),
                betting_please:this.$t("BETTING_PLEASE"),
                Select_the_text_you_want_to_send:this.$t("SELECT_THE_TEXT_YOU_WANT_TO_SEND"),
                Select_the_expression_you_want_to_send:this.$t("SELECT_THE_EXPRESSION_YOU_WANT_TO_SEND"),
                ranking_list:this.$t("RANKING_LIST"),
                Asset_details:this.$t("ASSET_DETAILS"),
                today:this.$t("TODAY"),
                Last_3_days:this.$t("LAST_3_DAYS"),
                Last_2_weeks:this.$t("LAST_2_WEEKS"),
                date:this.$t("DATE"),
                game:this.$t("GAME"),
                stake:this.$t("STAKE"),
                announce_of_lottery:this.$t("ANNOUNCE_OF_LOTTERY"),
                Payout:this.$t("PAYOUT"),
                review:this.$t("REVIEW"),
                Whether_to_give_tips:this.$t("WHETHER_TO_GIVE_TIPS"),
                no:this.$t("NO"),
                yes:this.$t("YES"),
                highroad:this.$t("HIGHROAD"),
                Dish_Road:this.$t("DISH_ROAD"),
                Big_Eye_Road:this.$t("BIG_EYE_ROAD"),
                trail:this.$t("TRAIL"),
                Cockroach_Road:this.$t("COCKROACH_ROAD"),
                Total_Games:this.$t("TOTAL_GAMES"),
                banker:this.$t("BANKER"),
                tie_win:this.$t("TIE_VOICE"),
                players:this.$t("PLAYER"),
                RESULT_0:this.$t("RESULT_0"),
				resultturn:'',
                TIE:this.$t("TIE"),
                BANKER_WIN_VOICE:this.$t("TIGER_WIN_VOICE"),
                PLAYER_WIN_VOICE:this.$t("DRAGON_WIN_VOICE"),
                BANKER_HAS_VOICE:this.$t("TIGERHAS"),
                PLAYER_HAS_VOICE:this.$t("DRAGONHAS"),
                PLACE_YOUR_BETS_VOICE:this.$t("PLACE_YOUR_BETS_VOICE"),
                NO_YOUR_BETS_VOICE:this.$t("NO_YOUR_BETS_VOICE"),
                baijiale:this.$t("GAME_TYPE_1"),
                dragonandtiger:this.$t("LIVE DRAGON TIGER"),
                dragon:this.$t("DRAGON"),
                tiger:this.$t("TIGER"),
  

                dealer: STORE.roomInfo.dealer_id, /// 荷官名称
                roomID: STORE.roomInfo.room_id, /// 房间id
                round: 0, /// 局数
                bet_time: 0,
                remains: 0, /// 剩余投注时间
                showRemains: false,
                limits: [],
                bet_limit: [],
                game_state: 1,
                cards: {
                    player: [],
                    playerResult: ""
                },
				turnresult:'',
                countdown:0,
                chips: window.STORE.chips[window.STORE[113].currency],
                chipsIndex: 0,
                selectedChip: window.STORE.chips[window.STORE[113].currency][0],
                customChip: 0,
                showCustomChip: false,
				backgroundwin: {
				  backgroundImage: 'url(' + this.$t("BGIMG_WIN_DT") + ')',
				},
                betters: [],
                totalAmount: 0, /// 总下注金额
                tip: "",
                userInfo: {
                    name: window.STORE["113"].user.login_id,
                    currency: window.STORE["113"].currency,
                    credit: window.STORE["113"].user.credit
                },
                showSideMenu: false,
                showLimitsModal: false, /// 显示限额
                betSuccess: false,
                odds: {
                    PLAYER: [1, 1],
                    BANKER: [1, 1],
                    TIE: [8, 1],
                    PLAYER_PAIR: [11, 1],
                    BANKER_PAIR: [11, 1]
                },
                winSwing: {
                    banker: false,
                    banker_pair: false,
                    player: false,
                    player_pair: false,
                    tie: false
                },
                winTotalAmount: 0,
                
                /// 路单相关
                road: {
                    big: "",
                    bead: "",
                    eye: "",
                    small: "",
                    roach: "",
                    knowblank: "",
					knowplayer: "",
                },
                showRoad: 0,
                cannotBet: false, /// 进入房间时当局是否允许下注
				voicestate: false,
				recordsstate:false,
				cardsTotal:"",
				numberDealer:"",
				numberPlayer:"",
				numberTie:"",
				supersixstate:false,
				isA:false,
				supertitle:this.$t("SuperSix"),
				screenstatus:false,
				d_knowload:this.$t("DRAGON")+' '+this.$t("KNOW_LOAD"),
				t_knowload:this.$t("TIGER")+' '+this.$t("KNOW_LOAD"),
				gameID:'8',
				client:'',
				betstatus:false,
				unbetstatus:false,
				allbetters:[
					{
						name: this.$t("TIER"),
						amount: 0,
						chips: [],
						hasBetted: [],
						history: 0,
						chipstatus:false,
						className2: "bleft"
					},
					{
						name: this.$t("ORPHELINS"),
						amount: 0,
						chips: [],
						hasBetted: [],
						history: 0,
						chipstatus:false,
						className2: "bcenter"
					},
					{
						name: this.$t("VOISINS"),
						amount: 0,
						chips: [],
						hasBetted: [],
						history: 0,
						chipstatus:false,
						className2: "bright"
					}
				],
				turnresulttype:'',
				turnresultnum:'',
				turnresultrank:'',
				turnresultprize:'',
				turnresultcolor:'',
				resultstatus:false,
				hotdata:[],
				nohotdata:[],
				Allamount:0,
				resbetinfo:[],
				oldbetinfo:[],
				bet_limitbox:''
            };
        },
        components: {
            Loading,
            SideMenu,
            Notice,
            RuleProtocol,
			RouleRoomProtocol,
            GameHistory,
			NoticeControl,
        },
        created () {
            this.$on("emit-voicebgstate", (status) => {
                this.togglebgAudio = status;
                    let bgaudio = document.getElementById('audiobg');
                if(this.togglebgAudio){

                   this.togglebgAudio=this.$utils.getCookie('voicebgstate');
                    bgaudio.play();
                }else{
                    bgaudio.pause();
                }
            });
            console.log("获取房间信息中...，房间key：", this.$route.query.key);
            this.createRoad();
            sessionStorage.removeItem("resbetinfo");
			this.socket(202, {header: {key: this.$route.query.key}}, { 
                "212": this.roomInfo.bind(this),
                "122": this.setBetTime.bind(this),
                "224": this.gameState.bind(this),
                "225": this.gameResult.bind(this),
                "228": this.gameAllamount.bind(this),
                "125": this.gameCredit.bind(this)
            });

			const langname = {
				'zh-CHS' : 'cn',
				'en-US' : 'en',
				'ko-KR' : 'ko',
			};
			this.language = langname[this.language]
			this.chips = window.STORE.chips[window.STORE[113].currency];
           
        },
        mounted(){
			if(navigator.platform.indexOf("Win")!=0){
				this.$utils.fullScreen(document.getElementsByTagName('body')[0]);
				document.getElementsByTagName('body')[0].style.width="100%";
				document.getElementsByTagName('body')[0].style.height=document.documentElement.clientHeight+'px';
				$('.full-height').height(document.documentElement.clientHeight);
				$('.lobby-box').height(document.documentElement.clientHeight);
			}
			for(let i=0;i<=156;i++){
				let obj = {};
				obj = {
					name: i,
					amount: 0,
					chips: [],
					hasBetted: [],
					history: 0,
					chipstatus:false,
					className2: "bet_"+i
				}
				this.betters.push(obj);
			}
			 let voice=document.getElementById('menu-right'); 
			 let src="";
			 let id="";
			for(let i=0;i<38;i++){
				id='result'+i;
				src=this.$t('RESULT_'+i);
				voice.innerHTML=voice.innerHTML+"<audio id="+id+" src="+src+"></audio>"
			}
			
			let self=this;
			let isTouch = 'ontouchstart' in window;
			let mouseEvents = (isTouch) ?
			{
			  down: 'touchstart',
			  move: 'touchmove',
			  up: 'touchend',
			  over: 'touchstart',
			  out: 'touchend'
			}
			:
			{
			  down: 'onmousedown',
			  move: 'onmousemove',
			  up: 'onmouseup',
			  over: 'onmouseover',
			  out: 'onmouseout'
			}
			let betarr=[
				[5,8,10,11,13,16,23,24,27,30,33,36],//代表区域数字
				[1,6,9,14,17,20,31,34],
				[2,3,4,7,12,15,18,19,21,22,25,26,28,29,32,35,37],
			];
			let obj ={};
			$.fn.longPress = function(fn,clearfn) {
				var timeout = undefined;
				var $this = this;
				for(var i = 0;i<$this.length;i++){
					$this[i].addEventListener(mouseEvents['down'], function(event) {
						fn()
					}, false);
					$this[i].addEventListener(mouseEvents['out'], function(event) {
						clearfn()
					}, false);
				}
			};
			let cla='';
			betarr.forEach((data,i)=>{
				if(i===0){
					cla='bleft';
				}else if(i===1){
					cla='bcenter';
				}else if(i===2){
					cla='bright';
				}
				$('.'+cla).longPress(function(){
					betarr[i].forEach((el,index)=>{
						for(let j in $('.r_bgh3w3').text()){
							if(el==j){
								$('#a'+j).addClass("zznumber");
							}
						}
					})
				},function(){
					betarr[i].forEach((el,index)=>{
						for(let j in $('.r_bgh3w3').text()){
							if(el==j){
								$('#a'+j).removeClass("zznumber");
							}
						}
					})
					if (self.game_state !== 0) return;
					betarr[i].forEach((el,index)=>{
						obj = {
							name: el-1,
							amount: 0,
							chips: [],
							hasBetted: [],
							history: 0,
							chipstatus:true,
							className2: "bet_"+(el-1)
						}
						self.betters[el-1].chips.push(self.selectedChip);
						self.betters[el-1].amount += self.selectedChip;
						self.addAmount(obj);
					})
				});
			})
        },
        watch: {
            "userInfo.credit": function (val) {
                window.STORE["113"].user.credit = val;

            },
            "countdown":function (countdown){
                var countsec=document.getElementById('countsec');
                if(countdown>0&&countdown<=10){
                 this.$utils.playVoice(this.$t("COUNTDOWN"));  

                this.$utils.playVoice1(countsec);                    
                }



            }


        },
        methods: {
			gameCredit(data){
				this.userInfo.credit = (data.credit / 100).toFixed(9) - 0;
			},
			// 刷新视频
			controlfreshen(){
				this.client = new WebSocket(this.$t("Roule_room"+this.roomID));
				let player = new jsmpeg(this.client, {canvas: document.getElementById("VIDEO"), seekable: true});
				player.play();
				clearTimeout(load)
				let load = document.getElementById('load');
				load.style.display="block";
				let loadtime = setTimeout(function(){
						load.style.display="none";
					}, 2000);
			},
			/// 控制声音播放
			changeVoice(){
                let date=new Date()

				date.setTime(date.getTime()+10*24*3600*1000)
				if(this.$utils.getCookie('voicestate')=='true'){
					document.cookie='voicestate='+encodeURIComponent(false)+'; path=/;expires='+date.toGMTString()

				}else{
					document.cookie='voicestate='+encodeURIComponent(true)+'; path=/;expires='+date.toGMTString()
				} 
              // this.$utils.playVoice(this.$t("BG1_VOICE"),'bgvoice')
				
            },
			controlVoice(){
				if(this.voicestate==true){
					this.voicestate=false;
				}else{
					this.voicestate=true
				}
				
            },
			// 控制局数弹出框
			controlRecords(){
				if(this.recordsstate==true){
					this.recordsstate=false;
				}else{
					this.recordsstate=true
				}
				
            },
			controlSupersix(){
				if(this.supersixstate==true){
					this.supersixstate=false;
				}else{
					this.supersixstate=true
				}
				
            },
			toggleState(){
				if(this.isA){
					this.isA = !this.isA;
				}else{
					this.isA = !this.isA;
				}
            },
            /// 获取房间信息
            roomInfo(data){
				let maxdata={}; 
				
				 
				data.win_count.forEach((el, index) => { 
					maxdata[index]=el;
				})
				var alldata=[];
				var dic=maxdata;
				 var sdic=Object.keys(dic).sort(function(a,b){return dic[a]-dic[b]});
				 for(let ki in sdic){                     
					//console.log(sdic[ki]+":"+dic[sdic[ki]]+",");
					alldata.push(sdic[ki]);
				 }
				if(alldata.length<16){
					this.hotdata = [alldata[alldata.length-1],alldata[alldata.length-2],alldata[alldata.length-3],alldata[alldata.length-4]];
					this.nohotdata = [alldata[0],alldata[1],alldata[2],alldata[3]];
				}else{
					this.hotdata = [alldata[alldata.length-1],alldata[alldata.length-2],alldata[alldata.length-3],alldata[alldata.length-4],alldata[alldata.length-5],alldata[alldata.length-6],alldata[alldata.length-7],alldata[alldata.length-8]];
					this.nohotdata = [alldata[0],alldata[1],alldata[2],alldata[3],alldata[4],alldata[5],alldata[6],alldata[7]];
				}
				
                let bgaudio = document.getElementById('audiobg');
				window.STORE.gameName="ROULETTE";

                if(this.togglebgAudio==='true'){
                    bgaudio.play();
                }else{
                    bgaudio.pause();
                }

                this.loading = false;
				this.bet_limitbox=data.bet_limit;
                let bet_limit = data.bet_limit;
                this.bet_limit = bet_limit;
                this.limits = [
                    {title: this.$t("DRAGON"), odds: this.odds.PLAYER, min: bet_limit.bet_min / 100, max: bet_limit.bet_max / 100}
                ];


                this.round = data.round;
                this.remains = [data.remaining_bet_time, Date.now()].join("-");
                if (data.remaining_bet_time > 0) {
                    this.alert(this.$t("PLEASE_WAIT_FOR_THE_NEXT_ROUND"), 0); /// 提示等待下一局

                    this.cannotBet = true;
                    this.showRemains = true;
					this.client = new WebSocket(this.$t("Roule_room"+this.roomID));
					let player = new jsmpeg(this.client, {canvas: document.getElementById("VIDEO"), seekable: true});
					this.play = player;
					if(document.getElementById("VIDEO")){
						document.getElementById("VIDEO").style.width="25rem";
						document.getElementById("VIDEO").style.height="12rem";
						document.getElementById("VIDEO").style.display="none";
						document.getElementById("VIDEO").style.top="3.1rem";
						document.getElementById("VIDEO").style.left="47%";
						document.getElementById("VIDEO").style.marginLeft="-10rem";
					}
                }else{
					this.client = new WebSocket(this.$t("Roule_room"+this.roomID));
					let player = new jsmpeg(this.client, {canvas: document.getElementById("VIDEO"), seekable: true});
					this.play = player;
					if(document.getElementById("VIDEO")){
						document.getElementById("VIDEO").style.width="25rem";
						document.getElementById("VIDEO").style.height="12rem";
						document.getElementById("VIDEO").style.display="none";
						document.getElementById("VIDEO").style.top="3.1rem";
						document.getElementById("VIDEO").style.left="47%";
						document.getElementById("VIDEO").style.marginLeft="-10rem";
					}
				}
            },
            setBetTime(data){
                if (data.room_id - this.roomID === 0 && data.game_id === 8) {
                    this.remains = [data.bet_timer, Date.now()].join("-");
                }
            },
            changechips(chip,selectedChip){

                var chipsup=document.getElementById('chipsup');
                this.$utils.playVoice1(chipsup);
                this.selectedChip=chip-0;

                },
            /// 游戏状态
            gameState(data){
                this.round = data.round;
                this.game_state = data.game_state;
                /// 倒计时下注时间
                if (data.game_state === 0) {
					this.oldbetinfo = JSON.parse(sessionStorage.getItem("resbetinfo"))?JSON.parse(sessionStorage.getItem("resbetinfo")):[];
                    this.alert(this.$t("PLACE_YOUR_BETS_PLEASE"));
                    var placeBet=document.getElementById('placeBet');
                        this.$utils.playVoice1(placeBet);
                    this.showRemains = true;
					if(this.client){
						this.client.close();
						document.getElementById("VIDEO").style.display="none";
					}
                } else {
					if(data.game_state === 2){
                        var noBet=document.getElementById('noBet');
                        this.$utils.playVoice1(noBet);
						// this.$utils.playVoice(this.$t("NO_YOUR_BETS_VOICE"),'tipvoice')
						this.client.close();
						document.getElementById("VIDEO").style.display="none";
					}
                    if (data.game_state === 2 && !this.cannotBet) 
					{	
						this.betstatus = false;
						this.unbetstatus = false;
						this.alert(this.$t("NO_MORE_BETS_PLEASE"));
						document.getElementById("VIDEO").style.display="block";
						this.client.close();
						this.client = new WebSocket(this.$t("Roule_room"+this.roomID));
						let player = new jsmpeg(this.client, {canvas: document.getElementById("VIDEO"), seekable: true});
						if(document.getElementById("VIDEO")){
							document.getElementById("VIDEO").style.width="25rem";
							document.getElementById("VIDEO").style.height="12rem";
						}
						clearTimeout(load)
						let load = document.getElementById('load');
						load.style.display="block";
						let loadtime = setTimeout(function(){
								load.style.display="none";
							}, 2000);
					}
                    if (this.cannotBet) {/*tipvoice*/
                        this.tip = "";
                        this.cannotBet = false;
                    }
                    this.showRemains = false;//遍历游戏情况数组
                    this.betters.forEach((el, index) => {
                        el.amount = 0;
                        el.chips.length = 0;
                        this.$set(this.betters, index, el);
                    });

                }
            },
			gameAllamount(data){
				data.total_bets.forEach((el, index) => {
					this.Allamount=this.Allamount+(el.amount/100);
				});
			},
            /// 获取游戏结果
            gameResult(data){
				this.betstatus = false;
				this.unbetstatus = false;
                let that = this;
                let winner = data.winner;
                let info = [
                   this.$t("WINS")
                ];
                let resultInfo = [];
                resultInfo.push(info[winner]);
                let allamount1 = [
					[1,3,5,7,9,11,13,15,17,19,21,23,25,27,29,31,33,35],
					[2,4,6,8,10,12,14,16,18,20,22,24,26,28,30,32,34,36]
				]
				let allamount2 = [
					[1,2,3,4,5,6,7,8,9,10,11,12],
					[13,14,15,16,17,18,19,20,21,22,23,24],
					[25,26,27,28,29,30,31,32,33,34,35,36]
				]
				let allamount3 = [
					[1,3,5,7,9,12,14,16,18,19,21,23,25,27,30,32,34,36],
					[2,4,6,8,10,11,13,15,17,20,22,24,26,28,29,31,33,35]
				]
				if($.inArray(winner, allamount1[0])<0){
					this.turnresulttype = this.$t("EVEN");
				}else{
					this.turnresulttype = this.$t("ODD");
				}
				if($.inArray(winner, allamount2[0])>=0){
					this.turnresultrank='1-12,'+this.$t("FRIST_R")
				}else if($.inArray(winner, allamount2[1])>=0){
					this.turnresultrank='13-24,'+this.$t("SECOND_R")
				}else if($.inArray(winner, allamount2[2])>=0){
					this.turnresultrank='25-36,'+this.$t("THREE_R")
				}
				if($.inArray(winner, allamount3[0])>=0){
					this.turnresultcolor='red'
				}else if($.inArray(winner, allamount3[1])>=0){
					this.turnresultcolor='black'
				}else{
					this.turnresultcolor='blue'
				}
				this.turnresultnum=winner;
				this.resultstatus=true;
                let winTotalAmount = 0; 
                data.results.forEach(el => {
                    if (el.player_id - this.$route.query.key === 0) {
						that.turnresultprize=(el.prize/ 100).toFixed(9) - 0;
                        for (let key in el.prize) {
                            let winAmount = el.prize[key];
                            if (winAmount) {
                                winTotalAmount += winAmount;
                                that.winSwing[key] = true;
                            }
                        }
                    }
                });
				var playerResult=document.getElementById('result'+winner);
				this.$utils.playVoice1(playerResult);
					                                   // 播报完成
                //this.alert(resultInfo.join("  "));

               
                setTimeout(() => {
					this.resultstatus=false;
                    if (winTotalAmount > 0) {
                        that.winTotalAmount = (winTotalAmount / 100).toFixed(9) - 0;
                        setTimeout(() => that.winTotalAmount = 0, 2000);
                    }
                }, 4000);
                /// 开牌后 清空筹码
				let self=this;
                this.betters.forEach((el, index) => {
                    el.chips.length = 0;
                    el.hasBetted.length = 0;
                    el.history = 0;
                    el.amount = 0;
                    this.$set(this.betters, index, el);
                });
                this.Allamount=0;
                this.totalAmount=0;
                /// 3s后关闭 中奖 闪烁效果
                setTimeout(() => {
                    for (let key in this.winSwing) {
                        that.winSwing[key] = false;
                    }
                }, 3000);
                
                /// 更新路单
                window.STORE.roomInfo.histories.push(data.winner);
                this.createRoad();
            },
            /// 获取牌的信息
            getCard(data){
                // this.$utils.playVoice(this.$t("FLIPCARD"));
               
                 var flipcard=document.getElementById('flipcard');
                this.$utils.playVoice1(flipcard);  
                let owner = ["player"][data.card.owner];
                
                
            },
			moreAmount($data,i){
				let betarr=[
					[5,8,10,11,13,16,23,24,27,30,33,36],
					[1,6,9,14,17,20,31,34],
					[0,2,3,4,7,12,15,18,19,21,22,25,26,28,29,32,35],
				];
					
			},
            addAmount($data,i){
				let amount = 0;
				$data.chipstatus=true;
				$data.hasBetted.concat($data.chips);
				if(i==="resbet"){
					this.betters.forEach((el,index) => {
						if(index == $data.name){
							el.chips = $data.chips;
							el.chipstatus =true;
							el.amount = $data.history;
							setTimeout(() => {
								el.chipstatus=false;
							}, 1500);
						}
					});
				}
				var chipsdown=document.getElementById('chipsdown');
				this.$utils.playVoice1(chipsdown);
                if (this.game_state === 0) {
                    $data.amount += this.selectedChip;
                    $data.chips.push(this.selectedChip);
                }
				
                
				let limittip = [
                    {title: this.$t("DRAGON"), odds: this.odds.PLAYER, min: this.bet_limit.bet_min / 100, max: this.bet_limit.bet_max / 100}
                ];
				let stat = [];
				
				
                this.betters.forEach((el,index) => {
                    amount += el.amount;
					
					
					if(this.betters[index].amount>limittip[0].max){
						this.alert(this.$t('RESULT_FAILED_CANNOT_BET_MORETHANMAXIMUM'));
						this.betters[index].amount = limittip[0].max;
					}
					if(index>150 && index<157){
						if(this.betters[index].amount>=this.bet_limitbox.bet_evenodd_min / 100 && this.betters[index].amount>0){
							stat.push(true)
							this.unbetstatus = false;
							this.betstatus=true;
						}else if(this.betters[index].amount<this.bet_limitbox.bet_evenodd_max / 100 && this.betters[index].amount>0){
							stat.push(false)
							this.unbetstatus=false;
							this.betstatus=true;
						}
					}else if(index>144 && index<151){
						if(this.betters[index].amount>=this.bet_limitbox.bet_dozen_min / 100 && this.betters[index].amount>0){
							stat.push(true)
							this.unbetstatus = false;
							this.betstatus=true;
						}else if(this.betters[index].amount<this.bet_limitbox.bet_dozen_max / 100 && this.betters[index].amount>0){
							stat.push(false)
							this.unbetstatus=false;
							this.betstatus=true;
						}
					}else{
						if(this.betters[index].amount>=limittip[0].min && this.betters[index].amount>0){
							stat.push(true)
							this.unbetstatus = false;
							this.betstatus=true;
						}else if(this.betters[index].amount<limittip[0].min && this.betters[index].amount>0){
							stat.push(false)
							this.unbetstatus=false;
							this.betstatus=true;
						}
					}
					
                });
				stat.forEach((el, index) => {
                    if(el===false){
						this.unbetstatus = true;
						this.betstatus=false;
					}
                });
                this.totalAmount = amount;
				setTimeout(() => {
                    $data.chipstatus=false;
                }, 1500);
            },
            /// 确认下注
            bet(){
                //if (this.game_state !== 0)return;
                let params = [], totalAmount = 0;
				this.betters.forEach(el => {
					if(el.amount==0){
						//delete params[el.name];
					}else{
						params.push({"index":el.name,"amount":el.amount*100});
					}
                    totalAmount += el.amount;
                });
                if (totalAmount <= 0)return;
                let sendData = {
                    bets: params,
                    header: {key: this.$route.query.key}
                };
                this.betstatus = false;
				this.unbetstatus = false;
                this.socket(203, sendData, {
                    "213": (data) => { 
                        if (data.result === 0 && data.player_id - this.$route.query.key === 0) {
                            this.betters.forEach((el, index) => {
                                Array.prototype.push.apply(el.hasBetted, el.chips);
                                el.chips.length = 0;
                                el.history += el.amount;
                                el.amount = 0;
                                this.$set(this.betters, index, el);
                            });
							sessionStorage.setItem("resbetinfo", JSON.stringify(this.betters));
							
                            this.alert(this.$t("YOUR_BET_IS_SUCCESSFUL") + " " + window.STORE[113].currency + " " + totalAmount);
                            this.userInfo.credit -= totalAmount;
                            //this.totalAmount = 0;
                            this.betSuccess = true;
                        } else {
                            this.alert(this.$t(this.ERRORCODE[data.result]));
                        }
                    }
                });
            },
            /// 取消下注
            cancelBet(){
				this.betstatus = false;
				this.unbetstatus = false;
                this.betters.forEach((el, index) => {
                    el.amount = 0;
                    el.chips.length = 0;
                    this.$set(this.betters, index, el);
                });
                this.totalAmount = 0;
            },
			 /// 重新下注
			resbet(){
				this.betstatus = false;
				this.unbetstatus = false;
                this.betters.forEach((el, index) => {
                    el.amount = 0;
                    el.chips.length = 0;
                    this.$set(this.betters, index, el);
                });
				let resbetinfo=this.oldbetinfo.length>0?this.oldbetinfo:JSON.parse(sessionStorage.getItem("resbetinfo"));
				let self=this;
				resbetinfo.forEach((el, index) => {
					if(el.hasBetted.length>0){
						self.addAmount(el,"resbet")
					}
				});
            },
            /// 离开房间
            leaveRoom(){
                this.socket(201, {header: {key: this.$route.query.key}}, {
                    "211": (data) => {
                        if (data.result === 0) {
                            console.log("离开房间成功");
                            this.$router.replace({name: "lobby"});
                        } else {
                            console.log("离开房间失败");
                        }
                    }
                });
            },
			videoclick(){
				let video = document.getElementById("VIDEO");
				video.style.width="100%";
				video.style.zIndex="10000000000000";
				video.style.height=document.documentElement.clientHeight+'px';
				video.style.top="0";
				video.style.left="0rem";
				video.style.marginLeft="0rem";
			},
			videoreturn(){
				let video = document.getElementById("VIDEO");
				video.style.width="25rem";
				video.style.zIndex="-1";
				video.style.height="12rem";
				video.style.top="3.1rem";
				video.style.left="47%";
				video.style.marginLeft="-10rem";
			},
            /// 切换筹码列表
            slideChips($data){
                let index = this.chipsIndex + $data;
                if (index > this.chips.length - 5) {
                    this.chipsIndex = this.chips.length - 5;
                } else if (index < 0) {
                    this.chipsIndex = 0;
                } else {
                    this.chipsIndex = index;
                }
            },
            showMenu(val){
                this.showSideMenu = val;
            },
			showProtocol(val){
                this.showSideMenu = val;
            },
            reverse(arr){
                let _arr = [].concat(arr);
                return _arr.reverse();
            },
            alert(tip, t){
                clearTimeout(TEMP.interval);
                this.tip = tip;
                if (t !== 0 && t !== false) TEMP.interval = setTimeout(() => this.tip = "", t || 2000);
				
            },
            /// 编辑自定义筹码
            editCustomChip(){
                this.showCustomChip = true;
                setTimeout(() => {
                    document.getElementById("CustomChip").focus();
                }, 200);
            },
            /// 保存自定义筹码
            saveCustomChip(){
                if (this.customChip === "" || this.customChip - 0 < 0) return this.customChip = "";
                this.selectedChip = this.customChip;
                this.showCustomChip = false;
            },
            /// 生成路单
            createRoad(histories){
                 histories = histories || window.STORE.roomInfo.histories || [];
				 let w = new Waybill(histories);
				 this.road.bead = w.TurnRoad();
            },
			/// 问路路单
            createknowRoad(histories,val1,val2){
				
            },
			fullScreen(){
				this.$utils.fullScreen(document.getElementsByTagName('body')[0]);
				document.getElementsByTagName('body')[0].style.width="100%";
			},
			closebetinfo(){
				$(".dialogbetinfo").css("display",'none');
			},
			openbetinfo(){
				$(".dialogbetinfo").css("display",'block');
			}
        },
        beforeRouteLeave(to, from, next){
            /// 离开页面时先退出房间
            this.loading = true;
            this.socket(201, {header: {key: this.$route.query.key}}, {
                "211": (data) => {
                    if (data.result === 0) {
                        next();
                    } else {
                        this.loading = false;
                        this.alertInfo = this.$t(this.ERRORCODE[data.result]) || this.ERRORCODE[data.result];
                        console.log("退出房间失败，错误代码：", data.result);
                        next(false);
                    }
                }
            });
        },
    }
</script>