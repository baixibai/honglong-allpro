<template>
    <div class="lobby-box">
        <!--<div style="position:fixed;top:0;left:0;z-index:99999" v-show="playVideo" @click="playVideo=false">
            <video src="/res/video/intro.mp4" width="100%" autoplay @ended="playVideo=false" @error="playVideo=false"></video>
        </div>-->
        <Loading :show="loading"></Loading>
		<div id="tip" v-show="landscapestatus==true">
			<div class="landscapebg"></div>
			<div class="landscapetip">
				<div class="landcontent">
					<p>请使用横屏体验</p>
					<img src="../res/images/fullScreen.png" width="60"/>
				</div>
				<a class="confirm" @click="fullScreen">知道了</a>
			</div>
		</div>
        <div class="full-height">
            <header class="header clear-fix">
                <div class="function-box">
                    <a class="btn btn-menu" v-on:click="show=true"></a>
                </div>
                <Notice></Notice>
                <div class="player-box">
                    <div class="player-info">
                        <span class="id">{{username}}</span>
                        <span class="money-box" style="transform:scale(0.9)">
                           {{currency}}&nbsp;{{credit}}
                        </span>
                    </div>
                </div>
            </header>
            <div class="game-box">
                <router-link to="/baccarat" class="btn btn-game1">
                    <div class="bg-box"></div>
                    <div :class="{ 'bgon-box':!bgonbox1,'bgon-boxc':bgonbox1}"  @mouseover='bgonbox1=true' @mouseleave='bgonbox1=false'></div>
                    <div class="info-box" @mouseover='bgonbox1=true' @mouseleave='bgonbox1=false'>
                        <div class="game-name">
                            <span> {{game_type1}} </span>
                        </div>
                    </div>
                </router-link>
                <router-link to="/baccaratvip"  class="btn btn-game2">
                    <div class="bg-box"></div>
                    <div :class="{ 'bgon-box':!bgonbox2,'bgon-boxc':bgonbox2}"  @mouseover='bgonbox2=true' @mouseleave='bgonbox2=false'></div>
                    <div class="info-box" @mouseover='bgonbox2=true' @mouseleave='bgonbox2=false'>
                        <div class="game-name">
                            <span>{{game_type2}}</span>
                        </div>
                    </div>
                </router-link>
                <router-link to="/roulette" class="btn btn-game4">
                    <div class="bg-box"></div>
                    <div :class="{ 'bgon-box':!bgonbox3,'bgon-boxc':bgonbox3}"  @mouseover='bgonbox3=true' @mouseleave='bgonbox3=false'></div>
                    <div class="info-box" @mouseover='bgonbox3=true' @mouseleave='bgonbox3=false'>
                        <div class="game-name">
                            <span>{{game_type3}}</span>
                        </div>
                    </div>
                </router-link>
                <!--<a @click="tip=true"  class="btn btn-game3">-->
				<a @click="tip=true"  class="btn btn-game3">
                    <div class="bg-box"></div>
                    <div :class="{ 'bgon-box':!bgonbox4,'bgon-boxc':bgonbox4}"  @mouseover='bgonbox4=true' @mouseleave='bgonbox4=false'></div>
                    <div class="info-box" @mouseover='bgonbox4=true' @mouseleave='bgonbox4=false'>
                        <div class="game-name" >
                            <span>{{game_type4}}</span>
                        </div>
                    </div>
                </a>
            </div>
            <div class="logo-box"></div>
			<div class="ui-dialog" v-show="tip">
                <a href="javascript:;" class="close-btn" @click="tip=false">x</a>
                <div class="d-body succeed-con">{{unonline}}</div>
            </div>
            
            <SideMenu :show="show" v-on:showMenu="showMenu" :protocolMenu="true"></SideMenu>
            
            <RuleProtocol></RuleProtocol>
        </div>
		<div class="loadImgWrap">
			<div class="cons">
				<div><em></em></div>
				<p><span>0%</span>
			</div>
		</div>
    </div>
</template>


<script>
    import SideMenu from "./SideMenu.vue"
    import Notice from "./Notice.vue"
    import Loading from "./Loading.vue"
    import RuleProtocol from "./RuleProtocol.vue"
	import Login from "./Login.vue"
    export default{
		
        data(){
            return {
                show: false,
                currency: window.STORE["113"].currency,
                username: window.STORE["113"].user.login_id,
                credit: window.STORE["113"].user.credit,
                playVideo: true,
                loading: true,
                show2: false,
				game_type1:this.$t("GAME_TYPE_1"),
				game_type2:this.$t("GAME_TYPE_2"),
				game_type3:this.$t("GAME_TYPE_3"),
				game_type4:this.$t("GAME_TYPE_4"),
                bgonbox1:"",
                bgonbox2:"",
                bgonbox3:"",
                bgonbox4:"",
				unonline:this.$t("UNONLINE_TIP"),
				tip:false,
				landscapestatus:false
            }
        },
        components: {
            SideMenu,
            Notice,    
            RuleProtocol,
			Login,
            Loading
        },
        methods: {
            showMenu(val){
                this.show = val;
            },
            animateC(event){
                bgonbox1="bgon-boxc";
                // let gamebgc=document.getElementById(id)//标记 大厅1
                // if( this.bgonbox="bgon-box"){
                    this.bgonbox="none";
                // }else{
                //     this.bgonbox="bgon-box"
                // }
                
            },
			fullScreen(){
				this.landscapestatus=false;
				document.getElementById('tip').style.display="none"
			}
        },

        created(){
			if(document.documentElement.clientWidth < document.documentElement.clientHeight){
				this.landscapestatus=true
			 }else{
				this.landscapestatus=false
			 }
            let urls = [];
            ["C", "H", "D", "S"].forEach(el => {
                for (let j = 1; j < 14; j++) {
                    urls.push("/res/images/origin/" + el + j + ".png");
                }
            });
            this.$utils.prevLoad(urls, () => this.loading = false);
			
        },
		mounted(){
			if(navigator.platform.indexOf("Win")!=0){
				this.$utils.fullScreen(document.getElementsByTagName('body')[0]);
				document.getElementsByTagName('body')[0].style.width="100%";
				document.getElementsByTagName('body')[0].style.height=document.documentElement.clientHeight+'px';
				$('.full-height').height(document.documentElement.clientHeight);
				$('.lobby-box').height(document.documentElement.clientHeight);
			}
		}
    }

</script>
