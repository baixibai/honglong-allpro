<template>
    <div>
        <!--用户协议-->
        <div class="code-dialog" style="display:none;" v-show="showProtocol">
            <a class="btn btn-close" @click="showProtocol=false"></a>
            <div class="title">{{titlerule}}</div>
            <div class="code-box cn" v-show="lang==='zh-CHS'">
				</br>
                条款</br>
				所有在XXX进行的投注都需要按照以下规则和条款：</br>
				所有游戏中的最高和最低投注额将由公司决定，如有更改不需要提前通知。</br>
				会员登记帐号是需提供正确的信息，对于提供错误信息的帐户我们将不负任何责任。</br>
				在本公司的投注，会员需要自行负责帐户交易，会员投注后需仔细检查注单，一旦投注接受，见无法更改会取消。</br>
				本公司对会员自身原因造成的遗漏不负任何责任。</br>
				对于任何投诉，如果没有记录或储存在公司的数据库中，公司将不接受或认可任何会员提供的复印件或数据。</br>
				公司保留任何时候关闭或冻结会员帐户的权利。</br>
				由以下事件造成的任何损失，公司不负任何责任：</br>
				o伺服器、网站或网络中断</br>
				o伺服器丢失信息或信息遭受破坏</br>
				o不法分子攻击网站，伺服器或网络供应商</br>
				o进入网站时由网络供应商原因造成的网络缓慢</br>
				警告声明</br>
				以下是本公司列出的规则和条款：</br>
				当阁下开户成为我们会员后就表示您接受了我们的条款，一旦我们收到您的提交申请，阁下与我们之间便产生了协议，阁下可以使用帐号登录我们的网站，并享受我们提供的服务。</br>
				客户在享受我们提供的服务时，点击【我同意】就表示您已阅读并接受此协议，并且承诺一旦违背此协议将会刀子剥夺会员资格，帐户冻结或其他法律行为，相关信息已在此协议详细列明。</br>
				如此规则和条款有任何争议，请以公司的解释为准。</br>
				提醒您，要先行审阅本契约三日以上，再按下【我愿意】键。</br>
				修改</br>
				客户完全理解并接受此协议所进行的任何修改，本公司可能在任何时候对此协议进行修改并会公布在相关的网页上。如果本公司对此协议进行较大的修改，我们会通过合适的方式通知您（比如在网站显眼位置发布修改信息）。阁下有责任经常检查相关条款与政策以确认您接受其内容，如果阁下继续使用本网站将被视为您接受相关条款与政策的修改。</br>
				所有在协议条款修改前的投注将适用於修改前的协议条款。所有在协议修改后的投注将适用於新的协议条款。如果阁下不能接受相关修改，您只可通过终止协议来解决。</br>
				信息与知识产权</br>
				本公司是网站所有知识产权的合法拥有者。关于版式、界面、程序、为其他客户提供服务，前述的任何应用、修改、完善、发展与加强方面，本公司拥有所有版权、专利权、注册权、商标权、原始编码权、解释说明权、图标设计权等权力。</br>
				一般条款的应用</br>
				关于条款的应用是指您承诺不会因非法目的进入或使用我们网站的服务，软件和信息， 您也需确保您的行为不会违反您当地的法律或不会违反您与本公司之间的协议。</br>
				您需确保您将履行以下协议:</br>

				•阁下不是法律限制行为能力的个体。</br> 
				•阁下的法定行为只能代表您个人，而不能代表其他人或其他公司。 </br>
				•阁下并非嗜赌成性的人 </br>
				•阁下已年满18岁，您的行为在您当地法律上是属合法的。</br> 
				•阁下获知并能承担因使用此服务而导致的亏损风险。 </br>
				•阁下的存款不是来自非法或犯罪的活动。 </br>
				•阁下不得通过使用本公司账户从事非法活动， 或允许他人使用您的帐户从事任何违背您当地和我们法律的活动。 </br>
				•阁下承诺妥善保管好您的帐户和密码不允许其他人使用。 如果您丢失或忘记您的帐户或密码，您需及时联系我们客服部门。 我们将发送给您新的安全资料。</br> 
				•阁下有责任确保自己的帐户及登入资料的保密性， 以使用者名称及密码进行的任何网上博彩将被视为有效。 </br>
				•在使用我们的服务，网站，设备，软件或相关信息时， 阁下不得以任何方式妨碍其他会员享用我们提供的服务。</br> 
				•阁下不可以使用任何方式企图获得其它用户的信息。 </br>
				•阁下不得上载或发布任何带有病毒的程序、文件或数据， 影响我们网站设备、软件、服务等运作性能 </br>
				•阁下不得使用任何设备、自动设备、软件、程序或其它方法（ 类似于前述的）妨碍或试图干预我们网站提供的服务、设备、软件、 网址、信息或任何交易的正常运作。 </br>
				•阁下不得在我们网站或设备上发布任何关于骚扰、侮辱、诽谤、 威胁、淫秽、及煽动种族不满的相关非法信息， 或者任何构成或怂恿犯罪行为， 或引起民事责任事件等等相关违法信息。</br> 
				•阁下不得主动或参与展开调查行动， 并针对本公司散布具有争议性或兜售信息的相关邮件。</br> 
				•协议标题仅供参考，并不影响任何条款的解释说明。 </br>
				•阁下有责任确保遵守一般条款里所有的法律条款。 </br>
				•阁下不可以同时拥有多个帐号，如发现客户拥有多个户口， 公司有权取消其户口以及投注 ,本公司保留权利取消或关闭您的账户。 本公司有权限制客户只保留其中一个户口。</br>
				投注接受条件</br>
				所有在网站的投注都要符合相关游戏规则以及本协议: </br>

				•本公司有权拒绝任何投注而不给予解释说明。 </br>
				•只有通过网站或设备的注单，符合条款与协议的被视为有效。 无论结果如何，任何以其它形式的投注（通过信函、邮件、 传真或其它方式）将不被接受或视为无效。</br> 客户的用户名和密码一致，账户余额足够，投注确认的注单才是有效的投注，而且投注后收到确认信息的注单才被视为有效。注单从屏幕出现确认信息时即开始生效。</br> 
				•所有账户名和密码输入正确的投注都被视为有效。 </br>
				•阁下须对所有经由其账户所产生的交易和行为承担责任，无论该交易是否经由您本人同意. </br>
				•阁下有责任确保投注资料正确无误。阁下一经投注成功就不能取消、撒回或更改,将会视作最终投注。并将视为您成功下注的证据。 </br>
				•所有投注都将记录在交易数据库，并作为所有交易的有效依据。 </br>
				•客户的注单明细记录将会显示在您的下注状况,下注状况的注单本公司都视为有效注单。 </br>
				•如因人为操作错误或系统故障导致错误, 所有发生在这种情况下的注单本公司将保留取消的权力, 相关的过关选项亦视为无效选项。 </br>
				•本公司对于任何个人或团体以不正常的方法所进行的投注保留无效的权力。</br>
				•本公司拥有任何相关投注和交易的最终决定权。 </br>
				•阁下完全理解并接受投注系统并非绝对稳定, 投注后请仔细检查您的下注记录是否成功否则将以本公司系统的 投注记录为准。如果阁下对您的注单有疑问, 请查询您的投注记录。</br>
				免责具体条款</br>
				•享用本公司提供的游戏或服务是客户本人的意愿， 参与我们的游戏或服务就承认您不认为此游戏或服务厌恶， 不公平及反对。</br>
				•某些法律规则并未明文规定在线和非在线博彩是否合法， 而有些法律规则已有明确规定。 如果按照客户当地法律博彩属不合法行为， 本公司不提倡阁下参与我们的服务。</br> 在博彩被视为不合法行为的任何国家本公司不提倡其国民加入。客户有责任确保任何时候您的博彩行为在您所属地是属合法行为。</br>
				•本公司不承担任何声称是本网站造成的损失，包括延迟或操作受阻， 传送通讯失败，或个人使用网站服务时的失误，疏忽。</br>
				•由于第三方关于公司网站和信息提供的供应商（ 比如无线通讯的提供者等）而导致的拖延、违约、 或不提供服务的情况，本公司不提供担保也不承担责任。</br>
				•阁下需承认本协议部分或全部内容是临时性的， 网站部分信息可能还需修改和更正。所以这些信息仅供参考， 在客户与本司之间并不构成协议，合同，和担保的依据。</br>
				•所有免责条款都是在公平公正， 风险及利益分布合理的情况下成立的， 它既反映了本公司对客户的关顾， 也体现了客户对本公司的理解与支持。 客户对此条款的进一步认同将决定法律适用本条款的程度。</br>
				•本公司服务器所显示的结果将为最终结果。 对于客户参与我们服务的游戏规则， 投注状况本公司拥有最终解释权。</br>
				•这些"规则和条款"及网站上其他的附加条款， 是一起构成具有约束力的协议， 同时这个协议只按照现有的执照运作。 本公司也保留权利将任何事务的操作切换到另一管辖区。</br>
				账户的终止，关闭或没收</br>
				在以下情况本公司有权取消任何彩金，没收任何投注账户余额， 终止协议或因违反条款而冻结账户：</br>

				•我们核实阁下拥有不止一个账户。</br> 
				•阁下违反本协议的任何条款规则。</br> 
				•我们获悉阁下曾在其他网上博彩网站被怀疑过有欺诈、合谋( 包括退款),或非法或不当行为的不良纪录。 </br>
				•阁下注册信息不真实或蓄意误导。 </br>
				•阁下未达到合法年龄。</br> 
				•阁下否认任何经由其账户产生的注单或存款。 </br>
				•阁下允许（有意或无意）其他人使用其账户。 </br>
				•阁下账户存款来源于犯罪活动或不法行为。 </br>
				•如果阁下因违反服务条款而导致账户冻结， 客户账户只有在採取必要的修正措施， 并且通过本司的审核后恢复其账户功能。 </br>
				服务及游戏的修改</br>
				•本公司有权未经通知在任何时候修改或废止（临时性或长期性） 游戏规则。关于游戏规则的修改、拖延、或废止， 本公司对任何人或第三方不承担责任。</br>
				违反协议</br>
				•如有客户违反协议规则，本公司将全力寻求公正的方式解决， 包括在任何时候， 本公司限制或阻止特定客户进入或使用网站服务而不给予任何解释说明。</br>
				优先权</br>
				•游戏规则和其他任何关于进入和使用本司网站服务的协议条款， 将组成协议一个完整的部分。除非有明文规定，</br> 如果游戏规则和任何关于进入和使用本司网站服务的协议条款或协议其它部分相衝突的情况发生，请以游戏规则为准。 </br>
				不可抗拒力量</br>
				•如果本公司因不可抗力事件而不能履行协议规定， 此种情况不构成违反协议。不可抗力事件包括（但是不仅限于）：</br> 自然灾害、政府限制、战争、或暴乱事件、系统故障、无线通讯、或网络服务故障或中断、供应设备的短缺、 或其他不可抗力事件等等。</br>
				法律管理</br>
				•如果客户对此协议有关实施方面的任何争议事件将提交到菲律宾最高法院依法判决处理。如果协议任何部分被裁定为非法或不可实施， 它将不会影响到协议其他部分条款的实施和有效性。
            </div>
			<div class="code-box" v-show="lang==='en-US' || lang!=='zh-CHS'">
				</br>
				Terms and Conditions</br>
				All bets made in XXX are subject to the following rules and conditions:</br>
				• The company will determine the maximum and minimum betting amount in all games. No change is required without prior notice.</br>
				• The member is required to give true and accurate information details. The company is not responsible for accounts that provide fake or misleading information. </br>
				• Members are responsible for their account transactions. They need to check if the bets that they place have been already accepted. If the bet is already accepted, the member cannot cancel his or her bet. </br>
				• The company is not responsible for accounts that are deleted because of the member’s inability to follow the terms and conditions. </br>
				• In the event where complaints are made, the company will not provide, accept or endorse copies of sensitive and important data if the member’s information is not stored or recorded in the company’s database. </br>
				• The company reserves the exclusive right to close or freeze a member's account at any given time</br>
				• The company is not liable for any loss or damages caused by events that are outside our reasonable control. These include but are not limited to the following:</br>

				O The server, website, or network is interrupted</br>
				O The server lost information or the information is corrupted</br>
				O Criminals attack the web sites, servers or network providers </br>
				O Slow transmission of information or any related delays</br></br>
				 
				Opening an Account</br></br>

				The following are the rules and terms listed by the Company:</br>
				• When you open an account to be our member, this means that you fully accepted our terms and conditions. Once you register, you agree to all the rules that we have set when using our website. You agree to use your own account to enjoy our products and services.</br></br>

				• Clicking on “I agree” means that you have read, accepted and fully understood the terms stated in this agreement. You agree that any activity, which breaches the conditions of agreement gives us the right to terminate or freeze your account. </br></br>

				• For disputes and questions, please always refer to these terms and conditions.</br>
				• We remind you to review this contract for days before pressing the “I agree” button. </br></br>

				Agreement Changes and Modification</br>
				• By agreeing to the terms and conditions, the member accepts any changes or modification made in the agreement. The company has the right to modify or change this agreement at any given time and publish it on relevant web pages. It is the company’s duty to inform you for any changes made in this agreement. This is performed via sending messages or announcements in the website. It is the member’s full responsibility to review the changes made. By continuing to use this website means that you agree and accept all the changes made in the terms and conditions</br>
				• The previous terms and conditions will apply to bets that are made or placed BEFORE the agreement change. The NEW and changed terms and conditions will apply to bets that are made or placed AFTER the agreement change. The member can terminate this agreement if he or she does not accept the changes that were made in the terms and conditions
				Information and Intellectual Property</br>
				• The Company is the legal owner of all the contents shown in the website. It is protected by international copyright laws, intellectual property rights, trademark right, original coding right, explanatory right, explanatory right and right to use all its contents. No material such as text, graphic, video, code or software can be modified without obtaining prior written consent. </br>
				Applicability of Terms and Conditions</br>
				By agreeing to the terms and conditions, you commit to not enter into the illegal use of the website’s services, software and information. This also means that all your actions will not violate domestic laws and policies that could breach the company’s protocol. In this agreement, you warrant that:</br>
				• You are not restricted by laws which prohibits gaming activities</br>
				• Your activities represent ONLY YOU and not other individuals or other companies</br>
				• Your jurisdiction permits or allows gaming activities</br>
				• You are (a) at least 18 years old or (b) your age complies with what is permitted by your domestic law or jurisdiction</br>
				• You are informed, aware and is able to take the risk of losing when using this service</br>
				• Your deposit should not come from any criminal or illegal activity</br>
				• You are strictly prohibited from using your company’s account or allow another entity to use your account. Likewise, you are prohibited from engaging into any gaming activities that violate your domestic laws or the terms and conditions stated in this agreement</br>
				• You agree to keep your account and password strictly confidential. You are prohibited from sharing it to other entities. In the event where you forgot your information details, you need to contact our customer service department and we will provide you your new information details. </br>
				• You are solely responsible in keeping the confidentiality of your account.</br>
				• You should not obstruct or prevent other members from using our website, service, equipment, software or any other related information </br>
				• You should not attempt or engage in activities that aim to obtain the private information from other users. </br>
				• You are prohibited from uploading or publishing programs, documents or data that contain viruses and may affect the performance of our website equipment, software, services, etc.</br>
				• You are prohibited from using any equipment, automated equipment, software, programs, or other similar means that will prevent or attempt to interfere with the proper operation of the services, equipment, software, websites, information or any transaction provided by our website.</br>
				• You are prohibited from publishing any information that encourages harassment, insult, defamation, threat, obscene information, racial abuse and other related acts that cause civil liabilities. </br>
				• You should not participate in activities that solicit, publish and disseminate controversies regarding the company </br>
				• The terms and conditions are for informational purposes only and does not affect the interpretation of any of the terms used in the agreement. </br>
				• You are obliged to comply with all the legal provisions that cover the general terms and conditions</br>
				• You are prohibited from using multiple accounts at the same time. The company reserves all the right to cancel any bet made from multiple accounts. Likewise, the company has the right to close your account. In addition, the company has the right to restrict customers to a single account</br>

				Bet Acceptance and Use of Service</br>
				All bets placed on this site should comply with the rules of this agreement</br>
				• The Company reserves the right to refuse any bet without explanation.</br>
				• Only the best placed in this website is considered valid. Bets that are placed via mail, fax or other related means are considered invalid. A bet has been successfully made if there is sufficient account balance and the customer’s username and password match. An electronic acknowledgement or notification will also appear on the screen to inform the customer that he or she has successfully placed a bet. </br>
				• All bets made by verifiable accounts and passwords are considered valid</br>
				• You are responsible in monitoring all activities, whether you approved or not, which are happening in your account. </br>
				• You are responsible in ensuring that your betting information is correct. Once you placed your bet, you will not be able to cancel, withdraw or change since it is treated as your final bet. </br>
				• All bets made are recorded in the transaction database and will serve as the basis for all transactions</br>
				• All of your betting records will be displayed in your betting status.  </br>
				• If an error occurs due to human error or system failure, all transactions that were successfully made before the incident is retained by the company. However, bets that are interrupted or were not transmitted in full is considered invalid. </br>
				• The company reserves the right to invalidate any bets placed by an individual or group if we have reasonable belief that the continuous use of the account violates the terms and conditions. </br>
				• The company has the final decision on any bets or transactions made. </br>
				• You have the responsibility to check your betting record. If you have any questions, please check your bet history. </br>

				Limitation of Liability</br>
				• As our customer, you agree that it is your own discretion to participate in the game and services that we provide. You agree that you do not consider the game or service that we offer as rigged, unfair and biased</br>
				• The company does not encourage customers to use our products and services in areas where laws or jurisdiction prohibits gambling. The customer has the full responsibility in determining if his area or region is covered or not covered by laws or jurisdictions where gambling is deemed illegal</br>
				• The company does not assume any liability for any loss caused by this website, including delays or operational disruption, failure to transmit communications, or personal use of web services</br>
				• The company is not liable for any delays or non-delivery of services caused by third parties such as information providers and wireless communications, which connect the users to the website</br>
				• You acknowledge that a part or all of the contents stated in the terms and conditions are provisional and that all or part of the information can be changed, modified and corrected. All information provided is merely for reference only and does not constitute as an agreement or a contract. </br>
				• All disclaimers are established in a fair and just manner. This reflects the customer’s full understanding, support and concern for the company. Likewise, the customer’s approval is determined by all the governing laws that apply. </br>
				• All results shown in our server is considered final. The company also has the final interpretation of the game rules. </br> 
				• The terms and conditions and other added terms in the website operate in accordance with the existing license provided by a governing body or jurisdiction. The company reserves all the rights to transfer or switch all of its operations to another jurisdiction at any given time.</br></br>

				Account closure and termination</br>
				The following circumstances give the company the right to cancel any prize, confiscate the account balance, terminate the agreement or freeze the account due to the breach of terms: </br>

				• We verify that you have more than one account.</br>
				• You violated any of the terms and conditions of this agreement.</br>
				• We are informed that you have been suspected of fraudulent activities, misconduct, conspiracy, illegal refund in other online gaming sites.</br>
				• Your registration details are untrue or deliberately misleading. </br>
				• You are not of legal age.</br>
				• You deny any deposits generated by your account.</br>
				• You allow (intentionally or unintentionally) others to use your account.</br>
				• Your account deposit came from criminal activity or wrongful act.</br>
				• If your account is frozen because of breaching the terms of service, the customer’s account is subject to investigation and will be only reinstated upon the division’s recommendation</br></br>

				Services and games</br>
				• The company reserves the right to modify or revoke (temporarily or permanently) the rules of the game at any time without any given notice. The company shall not be liable to any person or third party for any modification, delay or changes of the rules of the game.</br></br>

				Breach of agreement</br>
				• If a customer violates the terms and condition, the company will apply a fair solution. The company has the right to restrict or prevent a particular customer from entering and using the website’s services without providing any explanation. </br></br>

				• The terms of the game and any other terms of the agreement regarding the access and use of the services of the company will form a complete part of this agreement. Unless expressly provided that the rules of the game and any other terms regarding the terms of the agreement or any other part of the agreement regarding the access to and use of the Company's website services are subject to the rules of the game.</br></br>

				Force Majeure</br>
				• If the company is unable to perform the terms of the agreement due to conditions or circumstances that are beyond its control such as natural disasters, government restrictions, war, riots, system failures, disruptions of wireless communications or network services, supply shortage et., this does not constitute a breach of agreement  
				Law and Jurisdiction</br>
				• Any dispute with respect to the implementation of this agreement by the client will be submitted to the Philippine Supreme Court for adjudication. If any part of the agreement is found to be unlawful or unenforceable, it will not affect the implementation and validity of the other parts of the agreement.
			</div>
        </div>

        <!--游戏说明-->
        <div class="rule-dialog code-dialog" style="display:none" v-show="showRule">
            <a class="btn btn-close" @click="showRule=false;ruleIndex=0"></a>
            <div class="title">{{gamerule}}</div>
            <div class="code-box" v-show="lang==='zh-CHS' && gameID==='7'">
				</br>
                百家乐游戏条规
				</br>
				百家乐的输赢判定方式为牌点大者为赢。</br>

				牌点从小到大顺序为：0，1，2，3，4，5，6，7，8，9。Ace被视为1点，“10“、“J”、”Q”、”K“为0点。若首2张牌合计点数为8或9点则为“例牌”</br>

				百家乐只计算各位数，10点或10点以上的只计算个位数。</br>

				点数计算方式:</br>
				5 + 7 = 12 (只计算个位数值，点数为2) </br>
				8 + 2 = 10 (只计算个位数值，点数为0)</br></br>
					
				百家乐有三种基本投注选择，即“庄”、“闲”、“和”</br></br>

				发牌规则为第一张牌发给闲家, 第二张牌发给庄家, 第三张牌发给闲家然后第四张牌发给庄家以点数多寡决定庄、闲获胜或和局（包含若有第三张牌发牌的情况）；玩家下注的一方另如所得点数是8或9点（即例牌），此时即可决定庄闲之胜负。</br>

				若双方按照博牌规则出现同样点数的话则为和局。 </br></br>


				补牌规则</br>
				百家乐发第三张牌的规则如下：</br>

				闲家</br>
				<table class="tab-boder" border='1' borderColor="#fff" cellpadding="0" cellspacing="0">
					<tr>
						<td>两张牌点数合计</td>
						<td></td>
					</tr>
					<tr>
						<td>0 – 1 – 2 - 3 – 4 – 5</td>
						<td>补一张牌</td>
					</tr>
					<tr>
						<td>6 – 7</td>
						<td>停牌</td>
					</tr>
					<tr>
						<td>8 – 9</td>
						<td>“例牌”-停牌</td>
					</tr>
				</table>

				当闲家三张牌点数合计为5或以下时，庄家进行补牌</br>

				庄家</br>
				<table class="tab-boder" border='1' borderColor="#fff" cellpadding="0" cellspacing="0">
					<tr>
						<td>两张牌点数合计</td>
						<td>当闲家第三张牌是以下情况，庄家补一张牌</td>
						<td>当闲家第三张牌是以下情况，庄家停牌</td>
					</tr>
					<tr>
						<td>0 – 1 – 2</td>
						<td>补一张牌</td>
						<td></td>
					</tr>
					<tr>
						<td>3</td>
						<td>0 – 1 – 2 – 3 – 4 – 5 – 6 – 7 – 9</td>
						<td>8</td>
					</tr>
					<tr>
						<td>3</td>
						<td>2 – 3 – 4 – 5 – 6 – 7</td>
						<td>0 – 1 – 8 – 9</td>
					</tr>
					<tr>
						<td>5</td>
						<td>4 – 5 – 6 – 7</td>
						<td>0 – 1 – 2 – 3 – 8 – 9</td>
					</tr>
					<tr>
						<td>5</td>
						<td>6 – 7</td>
						<td>0 – 1 – 2 – 3 – 4 – 5 – 8 – 9</td>
					</tr>
					<tr>
						<td>7</td>
						<td>不需补牌</td>
						<td></td>
					</tr>
					<tr>
						<td>8 – 9</td>
						<td>“例牌”-停牌</td>
						<td>“例牌’”-停牌</td>
					</tr>
				</table></br>

				旁注</br>
				除了庄、闲、和三门外玩家还可以下注旁注在“对子”和“超级六”</br>

				下注对子（即庄或闲首两张牌为同数字或英文字母者），赢1赔11。</br>
            </div>
			<div class="code-box" v-show="(lang==='en-US' || lang!=='zh-CHS') && gameID==='7'">
				</br>
				Baccarat Game Rules</br>

				The goal in baccarat is to obtain a hand, which has a total value of nine (9) or close to it. To do that, one needs to add the value of the cards dealt to them. </br></br>

				Cards from 2-9 take their face value, while the Ace counts as one (1). Face cards such as King, Jack and Queen count as zero (0). When the first two cards give a total value of nine, it is called a natural hand. </br></br>

				If the hand’s total value is 10 or more, subtract 10 and the remainder will be the hand’s value. </br></br>

				Kindly look at the following examples for reference:</br>
				5 + 7 = 12 (the hand’s value is 2) </br>
				8 + 2 = 10 (the hand’s value is 0)</br></br>
					
				There are three types of bets that can be placed in baccarat. These are player, banker and tie. </br></br>

				The cards are dealt in this order: first card to the player, second card to the banker, third card to player and fourth card to banker. The hand, which has a total value of nine (9) or close to it, wins. </br></br>

				If the result shows that the player and banker gets the same value, tie wins. </br></br>


				The third card rule</br>
				There are instances wherein a third card is dealt to the player or banker. Please see the guide below for reference:</br></br>

				Player</br></br>
				<table class="tab-boder" border='1' borderColor="#fff" cellpadding="0" cellspacing="0">
					<tr>
						<td>Value of first two cards</td>
						<td></td>
					</tr>
					<tr>
						<td>0 – 1 – 2 - 3 – 4 – 5</td>
						<td>Draws a card.</td>
					</tr>
					<tr>
						<td>6 – 7</td>
						<td>Stands.</td>
					</tr>
					<tr>
						<td>8 – 9</td>
						<td>"Natural hand", no further draw.</td>
					</tr>
				</table>

				When the player decides to stand, the banker makes a hit when the total value is 5 or less. To know if the banker will hit or stand, please see the table below:</br></br>

				Banker</br></br>
				
				<table class="tab-boder" border='1' borderColor="#fff" cellpadding="0" cellspacing="0">
					<tr>
						<td>Value of two cards:</td>
						<td>Draws when the Player’s third card is:</td>
						<td>Does not draw when the Player’s third card is:</td>
					</tr>
					<tr>
						<td>0 – 1 – 2</td>
						<td>Always draws a card.</td>
						<td></td>
					</tr>
					<tr>
						<td>3</td>
						<td>0 – 1 – 2 – 3 – 4 – 5 – 6 – 7 – 9</td>
						<td>8</td>
					</tr>
					<tr>
						<td>3</td>
						<td>2 – 3 – 4 – 5 – 6 – 7</td>
						<td>0 – 1 – 8 – 9</td>
					</tr>
					<tr>
						<td>5</td>
						<td>4 – 5 – 6 – 7</td>
						<td>0 – 1 – 2 – 3 – 8 – 9</td>
					</tr>
					<tr>
						<td>5</td>
						<td>6 – 7</td>
						<td>0 – 1 – 2 – 3 – 4 – 5 – 8 – 9</td>
					</tr>
					<tr>
						<td>7</td>
						<td>Always stands.</td>
						<td></td>
					</tr>
					<tr>
						<td>8 – 9</td>
						<td>Player cannot draw.</td>
						<td>Player cannot draw.</td>
					</tr>
				</table>

				Side bets</br>
				Aside from the player, banker and tie bets, there are also side bets where one can wager on.  These are the player pair and banker pair. </br></br>

				There is a pair when the first two cards dealt have the same value. For example, there is a player pair if the player’s first two cards is a pair of King and vice versa. 
			</div>
			<div class="code-box" v-show="lang==='zh-CHS' && gameID==='11'">
				</br>
				龙虎游戏玩法</br>

				规则：</br>
				玩家可投注龙、虎、和 三门。</br>
				荷官只派两门牌，即龙及虎。每门各派一只牌，双方斗大，最大为K，最小为A。玩家可投注龙、虎和三门，如买中龙或虎，1赔1，两门的牌相同即和，买和赔率为1赔8。</br></br>
				 


				发牌:</br>
				龙派第一张牌，虎派第二张牌，无须补牌。</br>

				牌型大小：</br>
				<table class="tab-boder" border='1' borderColor="#fff" cellpadding="0" cellspacing="0">
					<tr>
						<td>牌面</td>
						<td>点数</td>
					</tr>
					<tr>
						<td>Ace</td>
						<td>1</td>
					</tr>
					<tr>
						<td>2</td>
						<td>2</td>
					</tr>
					<tr>
						<td>3</td>
						<td>3</td>
					</tr>
					<tr>
						<td>4</td>
						<td>4</td>
					</tr>
					<tr>
						<td>5</td>
						<td>5</td>
					</tr>
					<tr>
						<td>6</td>
						<td>6</td>
					</tr>
					<tr>
						<td>7</td>
						<td>7</td>
					</tr>
					<tr>
						<td>8</td>
						<td>8</td>
					</tr>
					<tr>
						<td>9</td>
						<td>9</td>
					</tr>
					<tr>
						<td>10</td>
						<td>10</td>
					</tr>
					<tr>
						<td>Jack</td>
						<td>11</td>
					</tr>
					<tr>
						<td>Queen</td>
						<td>12</td>
					</tr>
					<tr>
						<td>King</td>
						<td>13</td>
					</tr>
				</table>
			</div>
			<div class="code-box" v-show="lang!=='zh-CHS' && gameID==='11'">
				</br>
				Dragon Tiger Game Rules</br>

				Dragon Tiger is one of the simplest and easiest casino games to play. This is perfect for new and veteran punters, who are looking for fun and excitement. </br>

				Game objective</br>
				The goal of this game is to choose the hand that has a higher value and unlike baccarat, the dealer will only draw one card in Dragon Tiger. </br>

				To determine the value of each card, please look at the table below:</br>
				<table class="tab-boder" border='1' borderColor="#fff" cellpadding="0" cellspacing="0">
					<tr>
						<td>Card</td>
						<td>Value</td>
					</tr>
					<tr>
						<td>Ace</td>
						<td>1</td>
					</tr>
					<tr>
						<td>2</td>
						<td>2</td>
					</tr>
					<tr>
						<td>3</td>
						<td>3</td>
					</tr>
					<tr>
						<td>4</td>
						<td>4</td>
					</tr>
					<tr>
						<td>5</td>
						<td>5</td>
					</tr>
					<tr>
						<td>6</td>
						<td>6</td>
					</tr>
					<tr>
						<td>7</td>
						<td>7</td>
					</tr>
					<tr>
						<td>8</td>
						<td>8</td>
					</tr>
					<tr>
						<td>9</td>
						<td>9</td>
					</tr>
					<tr>
						<td>10</td>
						<td>10</td>
					</tr>
					<tr>
						<td>Jack</td>
						<td>11</td>
					</tr>
					<tr>
						<td>Queen</td>
						<td>12</td>
					</tr>
					<tr>
						<td>King</td>
						<td>13</td>
					</tr>
				</table>

				Types of bets</br>
				There are three types of bets that can be placed in this game. </br>

				These are the dragon, tiger and tie. The dragon hand wins if it gets the card that has a higher value and vice versa. </br>

				On the other hand, the name suggests, the tie bet wins if the dragon and tiger have the same value. </br>
			</div>
			<div class="code-box" v-show="gameID==='8'">
				轮盘（Roulette）是一种赌场常见的博彩游戏， Roulette一词在法语的意思解作小圆轮。轮盘一般会 有37或38个数字，由庄荷负责在转动的轮盘边打珠， 然后珠子落在该格的数字就是得奖号码。</br>
				轮盘上的数字会以红、黑两色间隔，但数字的排列并 非顺序而至。常见的轮盘有两种，分别是美式轮盘及 欧洲式轮盘。美式轮盘共有38个数字，包括1至36号、 0号以及00号，欧式轮盘则共有37个数字，包括1至36号以及0号。除红黑两色外，0及00号在轮上则是绿色的。这里我们为玩家提供的是欧式轮盘 . 玩家需要在45秒的等待时间内完成下注。</br>
				· 热门号码– 经常摇出的点数总和</br>
				· 冷门号码- 较少要出的点数总和</br>
				· 轮盘的开彩纪录，顶端为最新纪录</br>
				· 大小路字母代表： S- 小 ; B- 大; Z- 零</br>

				轮盘下注方式</br>
				· 单个数字（Straight Bet）：投注于一个数字的格上， 赔率1:35。</br>
				· 两个数字组合（Split Bet）：投注于两个数字之间的线上，赔率1:17。</br>
				· 三个数字组合（Street Bet）：投注于横行三个数字与外围投注区的线上，0,1,2/0，2，3也属此列 赔率1:11。</br>
				· 四个数字组合（Corner Bet）：投注于四个数字交接之间的点上，赔率1:8。</br>
				· 六个数字组合（Sixline Bet或Alley Bet）：投注于两行横行数字与外围投注区的交接点上，赔率1:5。</br>
				· 横行（Outside Bet）：可投注开出号码属于第一、二或三横行，赔率1:2。</br>
				· 组（Dozen）第一，第二，第三组12个号码，赔率1：2</br>
				· 颜色：可投注开出红或黑色号码，赔率1:1。</br>
				· 单双：可投注开出单或双数号码，赔率1:1。</br>
				· 1-18、19-36：可投注开出号码属上半（小）或下半段（大），赔率1:1。</br>
				· 为了将赌注押在杜的Voisins零，放在杜的Voisins零鼠标光标， 它会自动放置筹码轮盘桌上，然后单击"确定"按钮。</br>
				· 为了将赌注押在Orphelins，放在Orphelins鼠标光标，它会自动将筹码放在轮盘桌上，然后单击"确定"按钮。(Orphelins（孤儿）：赌注覆盖车轮的两个部分不包含 'Voisins du zero' 或'Tiers'.)</br>
				· 要投注在Tier的赌注，移动鼠标光标到此，它会自动放置在轮盘桌上筹码，然 后点击"确定"按钮.</br>
				· Neighbors是另一个变量的赌注。与邻居下注，您选择单号，并在数两侧的三个数字也将包括在内（总共7个）。例如，如果选择1，则也将是覆盖左侧的33，16和24以及右侧的20，14和31</br>
				· Complete Bet 或者称为"最大赌注" 它覆盖了单个号码的最大赌注. 要使用Complete下注，只需在下方"COMPLETE"打勾。选择所需 下注的号码，它会自动下满。 Complete 下注需要12个筹码或它的倍数</br>
				o1 个在单个数字 (straight)</br>
				o4 个在 两个数字组合 （split）</br>
				o4 个在 四个数字组合 （corner）</br>
				o2 个在 line</br>
				o1 个在 三个数字组合 （Street）</br>
				Half Complete Bet- 覆盖最大下注一个号码的一半. 要使用Half Complete下注，只需在下方"HALF COMPLETE"打勾。 选择所需下注的号码，它会自动下满。Half Complete 下注需要个9筹码或它的倍数</br>
				o1 个下注在1 (straight)</br>
				o4个下注在split</br>
				o4个下注在corner
			</div>
			<div class="code-box" v-show="gameID==='10'">
				</br>
				· 骰宝，起源于中国。顾名思义"骰宝"意味着以一对骰子，这个解释有些误导。"骰宝" 这游戏使用的是三个骰子。根据玩法它还有其他别名，包括掷骰子，小大或大细等。</br>
				· 开局后玩家有45秒的时间下注。</br>
				· 热门号码– 经常摇出的点数总和</br>
				· 冷门号码- 较少要出的点数总和</br>
				· 出现"大""小"和"围骰"的百分比</br>
				· 在过去的50轮的结果，顶端为最新结果</br></br>

				骰宝投注和赔率</br>
				· 三颗骰子的综合为大(11 到 17) 总和为小(4 到 10). 若开出围骰则通杀。这个玩法的赔率为1赔1</br>
				· 单/双是下注骰子的总和是奇数或偶数。类似"大/小"的玩法，如果开出围骰则通杀。这个 玩法的赔率为1赔1.这个玩法只适于部分桌台。</br>
				· 号码. 下注3颗骰子的总和点数（14个组合），6种赔率分别从1赔6到1赔60.</br>
				o总和 : 4 (1赔60)</br>
				o总和 : 5 (1赔30)</br>
				o总和 : 6 (1赔17)</br>
				o总和 : 7 (1赔12)</br>
				o总和 : 8 (1赔8)</br>
				o总和 : 9 (1赔6)</br>
				o总和 : 10 ( 1赔6)</br>
				o总和: 11 (1赔6)</br>
				o总和: 12 (1赔6)</br>
				o总和: 13 (1赔8)</br>
				o总和: 14 (1赔12)</br>
				o总和: 15 (1赔17)</br>
				o总和: 16 (1赔30)</br>
				o总和: 17 (1赔60)</br>
				· 围骰. 下注三个骰子都是相同的号码。分别有六种围骰（111，222，333，444，555和666）。赔 率为1赔180</br>
				· 全围骰. 不管出现任何一种围骰皆胜出。赔率为1赔30.</br>
				· 对子. 下投注有两个骰子有相同的值。只要两个骰子都是相同的即赢。赔率为1赔10。</br>
				· 短牌. 下注任意2个不同值的骰子。例：1和2，1和5,3和6等。有15个6组合。赔率为1赔5。</br>
				· 长牌. 下注任意2个同值的骰子。例：1和1，5和等。有6个6组合。赔率为1赔5。</br>
				· 赌数字. 下注数字，希望那个数字能在骰子上显示出来的次数越多越好，从1到6中选择一个数字并 在相应的位置下注，如果你选中的数字出现一次赔率为1：1，如果出现两次赔率为1：2， 如果出现三次赔率为1：3</br>


				提示:Cannot Bet More than Maximum</br>
				表示您无法下注超过最大下注总和</br>
			</div>
        </div>
    </div>
</template>

<script>
    export default {
		props:{
			gameID: '',
		},
        data(){
            return {
                showProtocol: false,
                showRule: false,
                ruleIndex: 0,
				lang :STORE.nation.KRW,
				titlerule:this.$t("MENU_NAME_3"),
				gamerule:this.$t("MENU_NAME_7"),
            };
        },
        created(){
            this.$parent.$on("show-protocol", (status) => {
                this.showProtocol = status;
            });

            this.$parent.$on("show-rule", (status) => {
                this.showRule = status;
            })
        }
    }
</script>