<template>
    <div class="marquee-box">
        <div class="marquee">
            <marquee behavior='scroll'>
                <span class='white'>{{message}}</span>
            </marquee>
        </div>
    </div>
</template>

<script>
    export default {
        data(){
            return {
                message: ""
            }
        },
        created(){
            this.$http.get("http://api.be1888.com/main/systemmessage", {
                params: {
                    currency: STORE.nation['KRW']
                }
            }).then(res => {
                if (res.ok) {
                    this.message = res.body.replace(/^<meta[^>]+>/, "");
                }
            });
        }
    }
</script>