<template>
    <div class="full-height">
        <div class="content">
            <!--loading -->
            <div class="mask" style="display:none;"></div>
            <div id="load" class="loading" style="display:none;">
                <div class="circle01">
                    <div class="circle02"></div>
                </div>
            </div>
            <!--loading  end -->
            <!--玩家介面-->
            <div class="menu-close" style="display: none"></div>
            <header class="header clear-fix">
                <!--视讯-->
                <canvas id="VIDEO" class="streaming-box" style="z-index:101" @click="videoclick()"></canvas>
                <!--<video class="streaming-box">
                    <source />
                </video>
                <img src="images/bg/video-bg.jpg" alt="" class="streaming-box" />-->
                <!--上-->
                <div><a class="btn btn-menu" @click="showSideMenu=true"></a></div>
                <Notice></Notice>
                <div class="playerinfo-box">
                    <div class="userid">{{userInfo.name}}</div>
                    <div class="usermoney">
                        {{userInfo.currency}}<span style="margin-left:0.5rem">{{userInfo.credit}}</span>
                    </div>
                </div>
                <!--<div class="signal-box type2"></div>-->
            </header>
            <!--左
            <div class="menu-left">
                <a class="btn" @click="showRoad=showRoad===1?0:1" v-bind:class="[showRoad===1?'active':'','btn-big-'+language]"></a>
                <a class="btn" @click="showRoad=showRoad===2?0:2" v-bind:class="[showRoad===2?'active':'','btn-path-'+language]"></a>
                <a class="btn" @click="showRoad=showRoad===3?0:3" v-bind:class="[showRoad===3?'active':'','btn-eye-'+language]"></a>
                <a class="btn" @click="showRoad=showRoad===4?0:4" v-bind:class="[showRoad===4?'active':'','btn-small-'+language]"></a>
                <a class="btn" @click="showRoad=showRoad===5?0:5" v-bind:class="[showRoad===5?'active':'','btn-road-'+language]"></a>
            </div>-->
            <!--右-->
            <div class="menu-right" id="menu-right">
                <!--按钮列表-->
                <audio id='audiobg' preload="auto" loop="loop" src="../res/audio/bgm/BeatriceBlossom.mp3"></audio>
                <audio id='countsec' src="../res/audio/effect/countdown.mp3"></audio>
                <audio id='flipcard'   src="../res/audio/effect/flipcard.mp3"></audio>
                <audio id='chipsup' src="../res/audio/effect/chips.mp3"></audio>
                <audio id='chipsdown' src="../res/audio/game/click_chip.mp3"></audio>
                <audio id='resultturn'  v-bind:src="resultturn"></audio>
                <audio id='playervoic' :src="PLAYER_HAS_VOICE"></audio>
                <audio id='bankervoic' :src="BANKER_HAS_VOICE"></audio>
                <audio id='BankerWins' :src="BANKER_WIN_VOICE"></audio>
                <audio id='PlayerWins' :src="PLAYER_WIN_VOICE"></audio>
                <audio id='placeBet' :src="PLACE_YOUR_BETS_VOICE"></audio>
                <audio id='noBet' :src="NO_YOUR_BETS_VOICE"></audio>
                <audio id='Tiewins' :src="tie_win"></audio>
                </a>
            </div>
            <!--对话内容-->
            <div class="message-box">
            </div>
            <!--打赏排行榜-->
            <div></div>
            <!--旁观玩家-->
            <div></div>
            <!--筹码选择-->
            <div class="bottomfunction-box">
               <!-- <a class="btn btn-pataward" @click="showLimitsModal=!showLimitsModal"></a>-->
                <div class="chips-box">
                    <a class="btn" v-for="chip in chips.slice(chipsIndex,chipsIndex+3)" v-bind:class="[chip.toString().split('.').length>1?'btn-chip'+chip.toString().split('.').join('_'):'btn-chip'+chip,selectedChip-chip===0?'select':'']"
                       @click="changechips(chip,selectedChip)"></a>
                    <div class="chipcustom-box" v-bind:class="{select:customChip-0>0}">
                        <a class="btn btn-chipCustom">
                            <span><input id="CustomChip" type='number' v-model="customChip" v-bind:disabled="!showCustomChip" @blur="saveCustomChip"></span>
							<!--<span>{{customChip}}</span>-->
                        </a>
                        <a class="btn btn-edit" @click="editCustomChip"></a>
                    </div>
                    <a class="slick-arrow slick-prev" @click="slideChips(-1)"></a>
                    <a class="slick-arrow slick-next" @click="slideChips(1)"></a>
                </div>
				<a class="resbet"  v-show="showRemains" @click="resbet()">{{$t("RE_BET")}}</a>
            </div>
			<!--骰宝下注区-->
			<div class="sicbobet">
				<div class="alldata" @click="leftdata('.alldatabox')">{{$t("STATISTICS")}}</div>
				<div class="hisrecord" @click="rightdata('.hisrecordbox')">{{$t("HISTORY_RECORD")}}</div>
				<div class="alldatabox"  @click="closealldata()">
					<p class="h3title">{{$t("SicBoLive")}} {{roomID}}</P>
					<div class="hotnumbox">
						<p class="num_p">
							<span class="title">{{$t("HOT")}}</span>
							<span class="num" v-for="item in hotdata">{{item}}</span>
						</p>
						<p class="num_p">
							<span class="title" style="background:rgb(42, 109, 173);">{{$t("COLD")}}</span>
							<span class="num" style="background:rgb(42, 109, 173);" v-for="item in nohotdata">{{item}}</span>
						</p>
					</div>
					<div v-html="hotRoad()"></div>
				</div>
				<div class="hisrecordbox"  @click="closealldata()">
					<p class="h3title">{{$t("DEALER")}}: {{dealer}}<span style="padding-left:10px;display: inline-block;"></span> {{$t("GAME_ROUND")}}:{{round}}</P>
					<ul class="historbox">
						<li v-for="(item,index) in hisinfoimg" :class="ctrolssxg && index=='0'?'ssxg':''">
							<img  :src="item.img1=='1' || item.img1=='4'?'../res/images/sicbo/r'+item.img1+'.png':'../res/images/sicbo/b'+item.img1+'.png'" />
							<img  :src="item.img2=='1' || item.img2=='4'?'../res/images/sicbo/r'+item.img2+'.png':'../res/images/sicbo/b'+item.img2+'.png'" />
							<img  :src="item.img3=='1' || item.img3=='4'?'../res/images/sicbo/r'+item.img3+'.png':'../res/images/sicbo/b'+item.img3+'.png'" />
							<span :class="item.num>10?'red':'blue'">{{item.num}}</span>
							<span :class="item.num>10?'red':'blue'">{{item.name1}}</span>
							<span :class="item.num%2==0?'dual':'odd'">{{item.name2}}</span>
						</li>
					</ul>
				</div>
				<div class="sicbobox">
					<div class="sicbotop">
						<!--下注倒数-->
						<div class="countdown-box" v-show="showRemains" style="left:50%;top:25px;">
							<div class="wrapper">
								<div class="back"></div>
								<div class="pie spinner"></div>
								<div class="pie filler"></div>
								<div class="mask"></div>
								<div class="time-text">
									<span class="time" id='countDown' v-countdown="remains">2</span>
									<span class="text">{{betting_please}}</span>
								</div>
							</div>
						</div>
					</div>
					<div class="sicbocenter">
						<div class="bigsmall">
							<p class="bsp_1">{{$t("SMALL")}}</p>
							<p class="bsp_2">4-10</p>
							<p class="bsp_3">{{$t("EVEN")}}</p>
						</div>
						<div class="s_c_center">
							<div class="s_1x10">
								<div class="toptitle">1×10</div>
								<div class="botcontent">
									<span>
										<img src="../res/images/sicbo/b1.png" />
										<img src="../res/images/sicbo/b1.png" />
									</span>
									<span>
										<img src="../res/images/sicbo/b2.png" />
										<img src="../res/images/sicbo/b2.png" />
									</span>
									<span>
										<img src="../res/images/sicbo/b3.png" />
										<img src="../res/images/sicbo/b3.png" />
									</span>
								</div>
							</div>
							<div class="s_1x180">
								<div class="toptitle">1×180</div>
								<div class="botcontent">
									<span>
										<img src="../res/images/sicbo/b1.png" />
										<img src="../res/images/sicbo/b1.png" />
										<img src="../res/images/sicbo/b1.png" />
									</span>
									<span>
										<img src="../res/images/sicbo/b2.png" />
										<img src="../res/images/sicbo/b2.png" />
										<img src="../res/images/sicbo/b2.png" />
									</span>
									<span>
										<img src="../res/images/sicbo/b3.png" />
										<img src="../res/images/sicbo/b3.png" />
										<img src="../res/images/sicbo/b3.png" />
									</span>
								</div>
							</div>
							<div class="s_1x30">
								<div class="toptitle">1×30</div>
								<div class="botcontent">
									<span>
										<img src="../res/images/sicbo/b1.png" />
										<img src="../res/images/sicbo/b1.png" />
										<img src="../res/images/sicbo/b1.png" />
									</span>
									<span>
										<img src="../res/images/sicbo/b2.png" />
										<img src="../res/images/sicbo/b2.png" />
										<img src="../res/images/sicbo/b2.png" />
									</span>
									<span>
										<img src="../res/images/sicbo/b3.png" />
										<img src="../res/images/sicbo/b3.png" />
										<img src="../res/images/sicbo/b3.png" />
									</span>
									<span>
										<img src="../res/images/sicbo/b4.png" />
										<img src="../res/images/sicbo/b4.png" />
										<img src="../res/images/sicbo/b4.png" />
									</span>
									<span>
										<img src="../res/images/sicbo/b5.png" />
										<img src="../res/images/sicbo/b5.png" />
										<img src="../res/images/sicbo/b5.png" />
									</span>
									<span>
										<img src="../res/images/sicbo/b6.png" />
										<img src="../res/images/sicbo/b6.png" />
										<img src="../res/images/sicbo/b6.png" />
									</span>
								</div>
							</div>
							<div class="s_1x180">
								<div class="toptitle">1×180</div>
								<div class="botcontent">
									<span>
										<img src="../res/images/sicbo/b4.png" />
										<img src="../res/images/sicbo/b4.png" />
										<img src="../res/images/sicbo/b4.png" />
									</span>
									<span>
										<img src="../res/images/sicbo/b5.png" />
										<img src="../res/images/sicbo/b5.png" />
										<img src="../res/images/sicbo/b5.png" />
									</span>
									<span>
										<img src="../res/images/sicbo/b6.png" />
										<img src="../res/images/sicbo/b6.png" />
										<img src="../res/images/sicbo/b6.png" />
									</span>
								</div>
							</div>
							<div class="s_1x10">
								<div class="toptitle">1×10</div>
								<div class="botcontent">
									<span>
										<img src="../res/images/sicbo/b4.png" />
										<img src="../res/images/sicbo/b4.png" />
									</span>
									<span>
										<img src="../res/images/sicbo/b5.png" />
										<img src="../res/images/sicbo/b5.png" />
									</span>
									<span>
										<img src="../res/images/sicbo/b6.png" />
										<img src="../res/images/sicbo/b6.png" />
									</span>
								</div>
							</div>
						</div>
						<div class="bigsmall">
							<p class="bsp_1">{{$t("BIG")}}</p>
							<p class="bsp_2">11-17</p>
							<p class="bsp_3">{{$t("ODD")}}</p>
						</div>
					</div>
					<div class="sicbobottom">
						<div class="top4-17">
							<span>
								<p class="p1">4</p>
								<p class="p2">1×60</p>
							</span>
							<span>
								<p class="p1">5</p>
								<p class="p2">1×30</p>
							</span>
							<span>
								<p class="p1">6</p>
								<p class="p2">1×17</p>
							</span>
							<span>
								<p class="p1">7</p>
								<p class="p2">1×12</p>
							</span>
							<span>
								<p class="p1">8</p>
								<p class="p2">1×8</p>
							</span>
							<span>
								<p class="p1">9</p>
								<p class="p2">1×6</p>
							</span>
							<span>
								<p class="p1">10</p>
								<p class="p2">1×6</p>
							</span>
							<span>
								<p class="p1">11</p>
								<p class="p2">1×6</p>
							</span>
							<span>
								<p class="p1">12</p>
								<p class="p2">1×6</p>
							</span>
							<span>
								<p class="p1">13</p>
								<p class="p2">1×8</p>
							</span>
							<span>
								<p class="p1">14</p>
								<p class="p2">1×12</p>
							</span>
							<span>
								<p class="p1">15</p>
								<p class="p2">1×17</p>
							</span><span>
								<p class="p1">16</p>
								<p class="p2">1×30</p>
							</span>
							<span>
								<p class="p1">17</p>
								<p class="p2">1×60</p>
							</span>
						</div>
						<div class="s-b-center">
							<span>
								<img src="../res/images/sicbo/b1.png" />
								<img src="../res/images/sicbo/b2.png" />
							</span>
							<span>
								<img src="../res/images/sicbo/b1.png" />
								<img src="../res/images/sicbo/b3.png" />
							</span>
							<span>
								<img src="../res/images/sicbo/b1.png" />
								<img src="../res/images/sicbo/b4.png" />
							</span>
							<span>
								<img src="../res/images/sicbo/b1.png" />
								<img src="../res/images/sicbo/b5.png" />
							</span>
							<span>
								<img src="../res/images/sicbo/b1.png" />
								<img src="../res/images/sicbo/b6.png" />
							</span>
							<span>
								<img src="../res/images/sicbo/b2.png" />
								<img src="../res/images/sicbo/b3.png" />
							</span>
							<span>
								<img src="../res/images/sicbo/b2.png" />
								<img src="../res/images/sicbo/b4.png" />
							</span><span>
								<img src="../res/images/sicbo/b2.png" />
								<img src="../res/images/sicbo/b5.png" />
							</span><span>
								<img src="../res/images/sicbo/b2.png" />
								<img src="../res/images/sicbo/b6.png" />
							</span><span>
								<img src="../res/images/sicbo/b3.png" />
								<img src="../res/images/sicbo/b4.png" />
							</span>
							<span>
								<img src="../res/images/sicbo/b3.png" />
								<img src="../res/images/sicbo/b5.png" />
							</span>
							<span>
								<img src="../res/images/sicbo/b3.png" />
								<img src="../res/images/sicbo/b6.png" />
							</span><span>
								<img src="../res/images/sicbo/b4.png" />
								<img src="../res/images/sicbo/b5.png" />
							</span>
							<span>
								<img src="../res/images/sicbo/b4.png" />
								<img src="../res/images/sicbo/b6.png" />
							</span>
							<span>
								<img src="../res/images/sicbo/b5.png" />
								<img src="../res/images/sicbo/b6.png" />
							</span>
						</div>
						<div class="s-b-bottom">
							<span>
								<i>{{$t("ONE")}}</i>
								<img src="../res/images/sicbo/b1.png" />
							</span>
							<span>
								<i>{{$t("TWO")}}</i>
								<img src="../res/images/sicbo/b2.png" />
							</span>
							<span>
								<i>{{$t("THREE")}}</i>
								<img src="../res/images/sicbo/b3.png" />
							</span>
							<span>
								<i>{{$t("FOUR")}}</i>
								<img src="../res/images/sicbo/b4.png" />
							</span>
							<span>
								<i>{{$t("FIVE")}}</i>
								<img src="../res/images/sicbo/b5.png" />
							</span>
							<span>
								<i>{{$t("SIX")}}</i>
								<img src="../res/images/sicbo/b6.png" />
							</span>
						</div>
					</div>
					<div class="sicareabet">
						<a v-bind:class="el.cssstatus?el.className2+' ssxg':el.className2"  v-for="el in betters"  @click="addAmount(el)">
							<i class="chips-item" v-for="(chip,index) in el.hasBetted.concat(el.chips).slice(-4)" v-bind:style="{top:-(5*index)+'px'}" v-bind:class="chip.toString().split('.').length>1?'chip'+chip.toString().split('.').join('_'):'chip'+chip">
							&nbsp;</i>
							<span class="selfbet type1" v-show="el.hasBetted.concat(el.chips).length>0 && el.chipstatus">{{el.amount+el.history}}<i class="unchecked"></i></span>
						</a>
						<div class="betleft" @click="openbetinfo()">
							<span>{{$t("MIN")}}:{{this.bet_limit.bet_min / 100}}</span>
							<span>{{$t("MAX")}}:{{(this.bet_limit.bet_max / 100)/1000}}K</span>
						</div>
						<div class="betright">
							<span>{{$t("MY_BET")}}:{{totalAmount>10000?(totalAmount/1000)+'K':totalAmount}}</span>
							<span>{{$t("TOTAL_BET")}}:{{Allamount>10000?(Allamount/1000)+'K':Allamount}}</span>
						</div>
					</div>
					
				</div>
			</div>
            <!--<div class="desktop-bg"></div>-->
           

            <!--荷官
            <div class="dealer-box">
                <div class="dealer-pic">
                    <img v-bind:src="'http://dealerpix.belcsc201602.com/east/'+$utils.toLowerCase(dealer)+'.jpg'"/>
                </div>
                <div class="dealer-info">
                    <div class="name">{{dealer}}</div>
                    <div class="gametype">{{''}}</div>
                    <div class="id">{{number_of_games}}: {{round}}</div>
                </div>
            </div>-->

            <!--右下角下注确认-->
            <div class="betcheck-box" style="z-index:102;">
                <!--<a class="btn btn-repeat show"></a>-->
                <a :class="'btn '+language +' '+'btn-confirm show'" v-show="betstatus" @click="bet"></a>
                <a :class="'btn '+language +' '+'btn-cancel show'" v-show="betstatus" @click="cancelBet"></a>
				<a :class="'btn '+language +' '+'btn-confirm show'" v-show="unbetstatus"  style="-webkit-filter: grayscale(100%);-moz-filter: grayscale(100%);-ms-filter: grayscale(100%);-o-filter: grayscale(100%);filter: grayscale(100%);filter: gray;"></a>
                <a :class="'btn '+language +' '+'btn-cancel show'" v-show="unbetstatus" @click="cancelBet"></a>
                <!--<a class="btn btn-delete"></a>-->
                <!--<a class="btn btn-end"></a>-->
            </div>
            
			
            

            <div class="pataward-box">
                <div class="item">
                    <i></i>
                </div>
                <div class="item">
                    <i></i>
                </div>
                <div class="item">
                    <i></i>
                </div>
            </div>

            <!--提示框-->
            <div class="ui-dialog" v-show="tip">
                <a href="javascript:;" class="close-btn" @click="tip=null">x</a>
                <div class="d-body succeed-con">{{tip}}</div>
            </div>

            <!--房间限额-->
            <div class="xiane-dialog" v-show="showLimitsModal">
                <a class="btn btn-close" @click="showLimitsModal=false"></a>
                <div class="title">{{room_limit}}</div>
                <table>
                    <thead>
                    <tr>
                        <th>{{designation}}</th>
                        <th>{{odds1}}</th>
                        <th>{{Minimum_bet}}</th>
                        <th>{{Maximum_bet}}</th>
                    </tr>
                    </thead>
                    <tbody>
                    <tr v-for="item in limits">
                        <td>{{item.title}}</td>
                        <td>{{item.odds.join(" : ")}}</td>
                        <td>{{item.min}}</td>
                        <td>{{item.max}}</td>
                    </tr>
                    </tbody>
                </table>
            </div>

            <!--派奖效果-->
            <div class="paicaiinfo-box" style="display:none;" v-show="winTotalAmount>0">
                <div class="paicai-box">
                    <div class="paicai-pic"></div>
                    <div :class="'getno-box'+' '+language">
                        <span>{{winTotalAmount}}</span>
                    </div>
                </div>
            </div>

            
	
		<div class="record-dialog" style="background: rgba(0,0,0,0.8);" v-show="resultstatus">
			<a href="javascript:;" class="close-btn" @click=""></a>
			<div class="recordscontent">
				<div class="recordsmode" id="resulttu">
					<span class="titlename" style="width:100%;text-align:center;"><img v-for="item in winnerimg" style="width:30px;margin-left:10px;" :src="'../res/images/sicbo/b'+item+'.png'" /></span>
					<span class="titlename" style="width:100%;text-align:center;">{{$t("WIN")}}：{{turnresultprize}}</span>
				</div>
			</div>
		</div>
		<div class="voice-dialog" v-show="supersixstate==true">
			<div class="voicecontent">
				<div class="voicemode">
					<span class="titlename">{{supertitle}}：</span>
					<div id="applebtn" class="open1" v-bind:class="{ 'open1' : isA, 'close1': !isA}">
						<div id="applecon" v-bind:class="{ 'open2' : isA, 'close2': !isA}" class="open2" @click="toggleState"></div>
					</div>
				</div>
			</div>
		</div>
		<div class="dialogbetinfosic" style="display:none;">
			<p class="title" @click="closebetinfo()">{{$t("BET_INFO")}}<span>X</span></p>
			<ul class="limitbox">
				<li>
					<p><span class="left">{{$t("Even or Odd")}}</span><span class="right">1 to 1</span></p>
					<p><span class="left">{{$t("MIN_LIMIT")}}</span><span class="right">{{bet_limitbox.bet_evenodd_min / 100}}</span></p>
					<p><span class="left">{{$t("MAX_LIMIT")}}</span><span class="right">{{(bet_limitbox.bet_evenodd_max / 100)/1000}}K</span></p>
				</li>
				<li>
					<p><span class="left">{{$t("Small/Big Bet")}}</span><span class="right">1 to 1</span></p>
					<p><span class="left">{{$t("MIN_LIMIT")}}</span><span class="right">{{bet_limitbox.bet_smallbig_min / 100}}</span></p>
					<p><span class="left">{{$t("MAX_LIMIT")}}</span><span class="right">{{(bet_limitbox.bet_smallbig_max / 100)/1000}}K</span></p>
				</li>
				<li>
					<p><span class="left">{{$t("Straight")}}</span><span class="right">11 to 1</span></p>
					<p><span class="left">{{$t("MIN_LIMIT")}}</span><span class="right">{{bet_limitbox.bet_single_min / 100}}</span></p>
					<p><span class="left">{{$t("MAX_LIMIT")}}</span><span class="right">{{(bet_limitbox.bet_single_max / 100)/1000}}K</span></p>
				</li>
				<li>
					<p><span class="left">{{$t("Double Bet")}}</span><span class="right">2 to 1</span></p>
					<p><span class="left">{{$t("MIN_LIMIT")}}</span><span class="right">{{bet_limitbox.bet_double_min / 100}}</span></p>
					<p><span class="left">{{$t("MAX_LIMIT")}}</span><span class="right">{{(bet_limitbox.bet_double_max / 100)/1000}}K</span></p>
				</li>
				<li>
					<p><span class="left">{{$t("Triple Bet")}}</span><span class="right">3 to 1</span></p>
					<p><span class="left">{{$t("MIN_LIMIT")}}</span><span class="right">{{bet_limitbox.bet_anytripple_min / 100}}</span></p>
					<p><span class="left">{{$t("MAX_LIMIT")}}</span><span class="right">{{(bet_limitbox.bet_anytripple_max / 100)/1000}}K</span></p>
				</li>
				<li>
					<p><span class="left">{{$t("Double_COMMON")}}</span><span class="right">10 to 1</span></p>
					<p><span class="left">{{$t("MIN_LIMIT")}}</span><span class="right">{{bet_limitbox.bet_double_min / 100}}</span></p>
					<p><span class="left">{{$t("MAX_LIMIT")}}</span><span class="right">{{(bet_limitbox.bet_double_max / 100)/1000}}K</span></p>
				</li>
				<li>
					<p><span class="left">{{$t("Double_GROUP")}}</span><span class="right">5 to 1</span></p>
					<p><span class="left">{{$t("MIN_LIMIT")}}</span><span class="right">{{bet_limitbox.bet_domino_min / 100}}</span></p>
					<p><span class="left">{{$t("MAX_LIMIT")}}</span><span class="right">{{(bet_limitbox.bet_domino_max / 100)/1000}}K</span></p>
				</li>
				<li>
					<p><span class="left">{{$t("Triple_SICBO")}}</span><span class="right">180 to 1</span></p>
					<p><span class="left">{{$t("MIN_LIMIT")}}</span><span class="right">{{bet_limitbox.bet_tripple_min / 100}}</span></p>
					<p><span class="left">{{$t("MAX_LIMIT")}}</span><span class="right">{{(bet_limitbox.bet_tripple_max / 100)/1000}}K</span></p>
				</li>
				<li>
					<p><span class="left">{{$t("Triple_ANY")}}</span><span class="right">30 to 1</span></p>
					<p><span class="left">{{$t("MIN_LIMIT")}}</span><span class="right">{{bet_limitbox.bet_anytripple_min / 100}}</span></p>
					<p><span class="left">{{$t("MAX_LIMIT")}}</span><span class="right">{{(bet_limitbox.bet_anytripple_max / 100)/1000}}K</span></p>
				</li>
				<li>
					<p><span class="left">{{$t("total of 4")}}</span><span class="right">60 to 1</span></p>
					<p><span class="left">{{$t("MIN_LIMIT")}}</span><span class="right">{{bet_limitbox.bet_total4_min / 100}}</span></p>
					<p><span class="left">{{$t("MAX_LIMIT")}}</span><span class="right">{{(bet_limitbox.bet_total4_max / 100)/1000}}K</span></p>
				</li>
				<li>
					<p><span class="left">{{$t("total of 5")}}</span><span class="right">60 to 1</span></p>
					<p><span class="left">{{$t("MIN_LIMIT")}}</span><span class="right">{{bet_limitbox.bet_total5_min / 100}}</span></p>
					<p><span class="left">{{$t("MAX_LIMIT")}}</span><span class="right">{{(bet_limitbox.bet_total5_max / 100)/1000}}K</span></p>
				</li>
				<li>
					<p><span class="left">{{$t("total of 6")}}</span><span class="right">60 to 1</span></p>
					<p><span class="left">{{$t("MIN_LIMIT")}}</span><span class="right">{{bet_limitbox.bet_total6_min / 100}}</span></p>
					<p><span class="left">{{$t("MAX_LIMIT")}}</span><span class="right">{{(bet_limitbox.bet_total6_max / 100)/1000}}K</span></p>
				</li>
				<li>
					<p><span class="left">{{$t("total of 7")}}</span><span class="right">60 to 1</span></p>
					<p><span class="left">{{$t("MIN_LIMIT")}}</span><span class="right">{{bet_limitbox.bet_total7_min / 100}}</span></p>
					<p><span class="left">{{$t("MAX_LIMIT")}}</span><span class="right">{{(bet_limitbox.bet_total7_max / 100)/1000}}K</span></p>
				</li>
				<li>
					<p><span class="left">{{$t("total of 8")}}</span><span class="right">60 to 1</span></p>
					<p><span class="left">{{$t("MIN_LIMIT")}}</span><span class="right">{{bet_limitbox.bet_total8_min / 100}}</span></p>
					<p><span class="left">{{$t("MAX_LIMIT")}}</span><span class="right">{{(bet_limitbox.bet_total8_max / 100)/1000}}K</span></p>
				</li>
				<li>
					<p><span class="left">{{$t("total of 9")}}</span><span class="right">60 to 1</span></p>
					<p><span class="left">{{$t("MIN_LIMIT")}}</span><span class="right">{{bet_limitbox.bet_total9_min / 100}}</span></p>
					<p><span class="left">{{$t("MAX_LIMIT")}}</span><span class="right">{{(bet_limitbox.bet_total9_max / 100)/1000}}K</span></p>
				</li>
				<li>
					<p><span class="left">{{$t("total of 10")}}</span><span class="right">60 to 1</span></p>
					<p><span class="left">{{$t("MIN_LIMIT")}}</span><span class="right">{{bet_limitbox.bet_total10_min / 100}}</span></p>
					<p><span class="left">{{$t("MAX_LIMIT")}}</span><span class="right">{{(bet_limitbox.bet_total10_max / 100)/1000}}K</span></p>
				</li>
				<li>
					<p><span class="left">{{$t("total of 11")}}</span><span class="right">60 to 1</span></p>
					<p><span class="left">{{$t("MIN_LIMIT")}}</span><span class="right">{{bet_limitbox.bet_total11_min / 100}}</span></p>
					<p><span class="left">{{$t("MAX_LIMIT")}}</span><span class="right">{{(bet_limitbox.bet_total11_max / 100)/1000}}K</span></p>
				</li>
				<li>
					<p><span class="left">{{$t("total of 12")}}</span><span class="right">60 to 1</span></p>
					<p><span class="left">{{$t("MIN_LIMIT")}}</span><span class="right">{{bet_limitbox.bet_total12_min / 100}}</span></p>
					<p><span class="left">{{$t("MAX_LIMIT")}}</span><span class="right">{{(bet_limitbox.bet_total12_max / 100)/1000}}K</span></p>
				</li>
				<li>
					<p><span class="left">{{$t("total of 13")}}</span><span class="right">60 to 1</span></p>
					<p><span class="left">{{$t("MIN_LIMIT")}}</span><span class="right">{{bet_limitbox.bet_total13_min / 100}}</span></p>
					<p><span class="left">{{$t("MAX_LIMIT")}}</span><span class="right">{{(bet_limitbox.bet_total13_max / 100)/1000}}K</span></p>
				</li>
				<li>
					<p><span class="left">{{$t("total of 14")}}</span><span class="right">60 to 1</span></p>
					<p><span class="left">{{$t("MIN_LIMIT")}}</span><span class="right">{{bet_limitbox.bet_total14_min / 100}}</span></p>
					<p><span class="left">{{$t("MAX_LIMIT")}}</span><span class="right">{{(bet_limitbox.bet_total14_max / 100)/1000}}K</span></p>
				</li>
				<li>
					<p><span class="left">{{$t("total of 15")}}</span><span class="right">60 to 1</span></p>
					<p><span class="left">{{$t("MIN_LIMIT")}}</span><span class="right">{{bet_limitbox.bet_total5_min / 100}}</span></p>
					<p><span class="left">{{$t("MAX_LIMIT")}}</span><span class="right">{{(bet_limitbox.bet_total15_max / 100)/1000}}K</span></p>
				</li>
				<li>
					<p><span class="left">{{$t("total of 16")}}</span><span class="right">60 to 1</span></p>
					<p><span class="left">{{$t("MIN_LIMIT")}}</span><span class="right">{{bet_limitbox.bet_total16_min / 100}}</span></p>
					<p><span class="left">{{$t("MAX_LIMIT")}}</span><span class="right">{{(bet_limitbox.bet_total16_max / 100)/1000}}K</span></p>
				</li>
				<li>
					<p><span class="left">{{$t("total of 17")}}</span><span class="right">60 to 1</span></p>
					<p><span class="left">{{$t("MIN_LIMIT")}}</span><span class="right">{{bet_limitbox.bet_total17_min / 100}}</span></p>
					<p><span class="left">{{$t("MAX_LIMIT")}}</span><span class="right">{{(bet_limitbox.bet_total17_max / 100)/1000}}K</span></p>
				</li>
				<li>
					<p><span class="left"></span><span class="right"></span></p>
					<p><span class="left"></span><span class="right"></span></p>
					<p><span class="left"></span><span class="right"></span></p>
				</li>
			</ul>
		</div>
        <SideMenu :show="showSideMenu" :backToLobby="true" :ruleMenu="true" v-on:showMenu="showMenu"  :roomMenu="true"></SideMenu>
        <RuleProtocol :gameID="gameID">  </RuleProtocol>
        <SicboRoomProtocol :roomID="roomID">  </RouleRoomProtocol>
        <GameHistory></GameHistory>
		<NoticeControl :voiceProtocol="voicestate"></NoticeControl>
		<div class="loadImgWrap">
			<div class="cons">
				<div><em></em></div>
				<p><span>0%</span>
			</div>
		</div>
    </div>
</template>

<script>
    import GameHistory from "./GameHistory.vue"
    import Loading from "./Loading.vue"
    import SideMenu from "./SideMenu.vue"
    import Notice from "./Notice.vue"
    import Waybill from "./waybill"
    import RuleProtocol from "./RuleProtocol.vue"
    import RouleRoomProtocol from "./RouleRoomProtocol.vue"
	import NoticeControl from "./NoticeControl.vue"
    let TEMP = {};
    export default {
        data(){
            return {
                togglebgAudio:this.$utils.getCookie('voicebgstate'),
				language:this.$t("LANGUAGE_TYPE"),
                loading: true,
                room_limit:this.$t("ROOM_LIMIT"),
                number_of_games:this.$t("NUMBER_OF_GAMES"),
                designation:this.$t("DESIGNATION"),
                odds1:this.$t("ODDS"),
                Maximum_bet:this.$t("MAXIMUM_BET"),
                Minimum_bet:this.$t("MINIMUM_BET"),
                betting_please:this.$t("BETTING_PLEASE"),
                betting_please:this.$t("BETTING_PLEASE"),
                Select_the_text_you_want_to_send:this.$t("SELECT_THE_TEXT_YOU_WANT_TO_SEND"),
                Select_the_expression_you_want_to_send:this.$t("SELECT_THE_EXPRESSION_YOU_WANT_TO_SEND"),
                ranking_list:this.$t("RANKING_LIST"),
                Asset_details:this.$t("ASSET_DETAILS"),
                today:this.$t("TODAY"),
                Last_3_days:this.$t("LAST_3_DAYS"),
                Last_2_weeks:this.$t("LAST_2_WEEKS"),
                date:this.$t("DATE"),
                game:this.$t("GAME"),
                stake:this.$t("STAKE"),
                announce_of_lottery:this.$t("ANNOUNCE_OF_LOTTERY"),
                Payout:this.$t("PAYOUT"),
                review:this.$t("REVIEW"),
                Whether_to_give_tips:this.$t("WHETHER_TO_GIVE_TIPS"),
                no:this.$t("NO"),
                yes:this.$t("YES"),
                highroad:this.$t("HIGHROAD"),
                Dish_Road:this.$t("DISH_ROAD"),
                Big_Eye_Road:this.$t("BIG_EYE_ROAD"),
                trail:this.$t("TRAIL"),
                Cockroach_Road:this.$t("COCKROACH_ROAD"),
                Total_Games:this.$t("TOTAL_GAMES"),
                banker:this.$t("BANKER"),
                tie_win:this.$t("TIE_VOICE"),
                players:this.$t("PLAYER"),
                RESULT_0:this.$t("RESULT_0"),
				resultturn:'',
                TIE:this.$t("TIE"),
                BANKER_WIN_VOICE:this.$t("TIGER_WIN_VOICE"),
                PLAYER_WIN_VOICE:this.$t("DRAGON_WIN_VOICE"),
                BANKER_HAS_VOICE:this.$t("TIGERHAS"),
                PLAYER_HAS_VOICE:this.$t("DRAGONHAS"),
                PLACE_YOUR_BETS_VOICE:this.$t("PLACE_YOUR_BETS_VOICE"),
                NO_YOUR_BETS_VOICE:this.$t("NO_YOUR_BETS_VOICE"),
                baijiale:this.$t("GAME_TYPE_1"),
                dragonandtiger:this.$t("LIVE DRAGON TIGER"),
                dragon:this.$t("DRAGON"),
                tiger:this.$t("TIGER"),
  

                dealer: STORE.roomInfo.dealer_id, /// 荷官名称
                roomID: STORE.roomInfo.room_id, /// 房间id
                round: 0, /// 局数
                bet_time: 0,
                remains: 0, /// 剩余投注时间
                showRemains: false,
                limits: [],
                bet_limit: [],
                game_state: 1,
                cards: {
                    player: [],
                    playerResult: ""
                },
				turnresult:'',
                countdown:0,
                chips: window.STORE.chips[window.STORE[113].currency],
                chipsIndex: 0,
                selectedChip: window.STORE.chips[window.STORE[113].currency][0],
                customChip: 0,
                showCustomChip: false,
				backgroundwin: {
				  backgroundImage: 'url(' + this.$t("BGIMG_WIN_DT") + ')',
				},
                betters: [],
                totalAmount: 0, /// 总下注金额
                tip: "",
                userInfo: {
                    name: window.STORE["113"].user.login_id,
                    currency: window.STORE["113"].currency,
                    credit: window.STORE["113"].user.credit
                },
                showSideMenu: false,
                showLimitsModal: false, /// 显示限额
                betSuccess: false,
                odds: {
                    PLAYER: [1, 1],
                    BANKER: [1, 1],
                    TIE: [8, 1],
                    PLAYER_PAIR: [11, 1],
                    BANKER_PAIR: [11, 1]
                },
                winSwing: {
                    banker: false,
                    banker_pair: false,
                    player: false,
                    player_pair: false,
                    tie: false
                },
                winTotalAmount: 0,
                
                /// 路单相关
                road: {
                    big: "",
                    bead: "",
                    eye: "",
                    small: "",
                    roach: "",
                    knowblank: "",
					knowplayer: "",
                },
                showRoad: 0,
                cannotBet: false, /// 进入房间时当局是否允许下注
				voicestate: false,
				recordsstate:false,
				cardsTotal:"",
				numberDealer:"",
				numberPlayer:"",
				numberTie:"",
				supersixstate:false,
				isA:false,
				supertitle:this.$t("SuperSix"),
				screenstatus:false,
				d_knowload:this.$t("DRAGON")+' '+this.$t("KNOW_LOAD"),
				t_knowload:this.$t("TIGER")+' '+this.$t("KNOW_LOAD"),
				gameID:'10',
				client:'',
				betstatus:false,
				unbetstatus:false,
				turnresulttype:'',
				turnresultnum:'',
				turnresultrank:'',
				turnresultprize:'',
				turnresultcolor:'',
				resultstatus:false,
				hotdata:[],
				nohotdata:[],
				Allamount:0,
				resbetinfo:[],
				oldbetinfo:[],
				bet_limitbox:'',
				hotcount:[],
				winnerimg:[],
				hisinfoimg:[],
				ctrolssxg:false,
				video:false
            };
        },
        components: {
            Loading,
            SideMenu,
            Notice,
            RuleProtocol,
			RouleRoomProtocol,
            GameHistory,
			NoticeControl,
        },
        created () {
            this.$on("emit-voicebgstate", (status) => {
                this.togglebgAudio = status;
                    let bgaudio = document.getElementById('audiobg');
                if(this.togglebgAudio){

                   this.togglebgAudio=this.$utils.getCookie('voicebgstate');
                    bgaudio.play();
                }else{
                    bgaudio.pause();
                }
            });
            console.log("获取房间信息中...，房间key：", this.$route.query.key);
            this.createRoad();
            this.hotRoad();
            sessionStorage.removeItem("resbetinfo");
			this.socket(202, {header: {key: this.$route.query.key}}, { 
                "212": this.roomInfo.bind(this),
                "122": this.setBetTime.bind(this),
                "224": this.gameState.bind(this),
                "225": this.gameResult.bind(this),
                "228": this.gameAllamount.bind(this),
				"125": this.gameCredit.bind(this)
            });

			const langname = {
				'zh-CHS' : 'cn',
				'en-US' : 'en',
				'ko-KR' : 'ko',
			};
			this.language = langname[this.language]
			this.chips = window.STORE.chips[window.STORE[113].currency];
           
        },
        mounted(){
			if(navigator.platform.indexOf("Win")!=0){
				this.$utils.fullScreen(document.getElementsByTagName('body')[0]);
				document.getElementsByTagName('body')[0].style.width="100%";
				document.getElementsByTagName('body')[0].style.height=document.documentElement.clientHeight+'px';
				$('.full-height').height(document.documentElement.clientHeight);
				$('.lobby-box').height(document.documentElement.clientHeight);
			}
			let hisinfo = window.STORE.roomInfo.histories;
			let arrsic=[111,112,113,122,114,123,222,115,124,133,223,116,125,134,224,233,126,135,144,234,225,333,136,145,226,235,244,334,146,155,236,245,335,344,156,246,255,336,345,444,166,256,346,355,445,266,356,446,455,366,456,555,466,556,566,666];	
			let num=0;
			hisinfo.forEach((data,i)=>{ 
				num=parseInt(arrsic[data].toString().split('')[0])+parseInt(arrsic[data].toString().split('')[1])+parseInt(arrsic[data].toString().split('')[2]);
				let d1=num>10?this.$t("BIG"):this.$t("SMALL");
				let d2=num%2==0?this.$t("EVEN"):this.$t("ODD");
				this.hisinfoimg.push({img1:arrsic[data].toString().split('')[0],img2:arrsic[data].toString().split('')[1],img3:arrsic[data].toString().split('')[2],num:num,name1:d1,name2:d2})
			})
			this.hisinfoimg = this.hisinfoimg.reverse();
			for(let i=0;i<=51;i++){
				let obj = {};
				obj = {
					name: i,
					amount: 0,
					chips: [],
					hasBetted: [],
					history: 0,
					chipstatus:false,
					className2: "bet_"+i,
					cssstatus:false
				}
				this.betters.push(obj);
			}
			 let voice=document.getElementById('menu-right'); 
			 let src="";
			 let id="";
			for(let i=0;i<38;i++){
				id='result'+i;
				src=this.$t('RESULT_'+i);
				voice.innerHTML=voice.innerHTML+"<audio id="+id+" src="+src+"></audio>"
			}
			
			let self=this;
			let isTouch = 'ontouchstart' in window;
			let mouseEvents = (isTouch) ?
			{
			  down: 'touchstart',
			  move: 'touchmove',
			  up: 'touchend',
			  over: 'touchstart',
			  out: 'touchend'
			}
			:
			{
			  down: 'onmousedown',
			  move: 'onmousemove',
			  up: 'onmouseup',
			  over: 'onmouseover',
			  out: 'onmouseout'
			}
			let obj ={};
			$.fn.longPress = function(fn,clearfn) {
				var timeout = undefined;
				var $this = this;
				for(var i = 0;i<$this.length;i++){
					$this[i].addEventListener(mouseEvents['down'], function(event) {
						fn()
					}, false);
					$this[i].addEventListener(mouseEvents['out'], function(event) {
						clearfn()
					}, false);
				}
			};
			let cla='';
        },
        watch: {
            "userInfo.credit": function (val) {
                window.STORE["113"].user.credit = val;

            },
            "countdown":function (countdown){
                var countsec=document.getElementById('countsec');
                if(countdown>0&&countdown<=10){
                 this.$utils.playVoice(this.$t("COUNTDOWN"));  

                this.$utils.playVoice1(countsec);                    
                }



            }


        },
        methods: {
			gameCredit(data){
				this.userInfo.credit = (data.credit / 100).toFixed(9) - 0;
			},
			// 刷新视频
			controlfreshen(){
				this.client = new WebSocket(this.$t("Sicbo_room"+this.roomID));
				let player = new jsmpeg(this.client, {canvas: document.getElementById("VIDEO"), seekable: true});
				player.play();
				clearTimeout(load)
				let load = document.getElementById('load');
				load.style.display="block";
				let loadtime = setTimeout(function(){
						load.style.display="none";
					}, 2000);
			},
			/// 控制声音播放
			changeVoice(){
                let date=new Date()

				date.setTime(date.getTime()+10*24*3600*1000)
				if(this.$utils.getCookie('voicestate')=='true'){
					document.cookie='voicestate='+encodeURIComponent(false)+'; path=/;expires='+date.toGMTString()

				}else{
					document.cookie='voicestate='+encodeURIComponent(true)+'; path=/;expires='+date.toGMTString()
				} 
              // this.$utils.playVoice(this.$t("BG1_VOICE"),'bgvoice')
				
            },
			controlVoice(){
				if(this.voicestate==true){
					this.voicestate=false;
				}else{
					this.voicestate=true
				}
				
            },
			// 控制局数弹出框
			controlRecords(){
				if(this.recordsstate==true){
					this.recordsstate=false;
				}else{
					this.recordsstate=true
				}
				
            },
			controlSupersix(){
				if(this.supersixstate==true){
					this.supersixstate=false;
				}else{
					this.supersixstate=true
				}
				
            },
			toggleState(){
				if(this.isA){
					this.isA = !this.isA;
				}else{
					this.isA = !this.isA;
				}
            },
            /// 获取房间信息
            roomInfo(data){ 
				console.log(data);
				this.hotcount = data.win_count;
				var alldata=[];
				let arr=[],result=JSON.parse(sessionStorage.getItem("histories"));
				let arrsic=[111,112,113,122,114,123,222,115,124,133,223,116,125,134,224,233,126,135,144,234,225,333,136,145,226,235,244,334,146,155,236,245,335,344,156,246,255,336,345,444,166,256,346,355,445,266,356,446,455,366,456,555,466,556,566,666];
				
				let maxdata={}; 
				
				 
				result.forEach((el, index) => { 
					maxdata[index]=parseInt(arrsic[el].toString().split('')[0])+parseInt(arrsic[el].toString().split('')[1])+parseInt(arrsic[el].toString().split('')[2]);
				})
				var alldata=[];
				var dic=maxdata;
				 var sdic=Object.keys(dic).sort(function(a,b){return dic[a]-dic[b]});
				 for(let ki in sdic){                     
					//console.log(sdic[ki]+":"+dic[sdic[ki]]+",");
					alldata.push(dic[sdic[ki]]);
				 }
				 var res = [];  
				alldata.sort();  
				for(var i = 0;i<alldata.length;)  
				{  
				   
				 var count = 0;  
				 for(var j=i;j<alldata.length;j++)  
				 {  
					   
				  if(alldata[i] == alldata[j])  
				  {  
				   count++;  
				  }  
					
				 }  
				 res.push([alldata[i],count]);  
				 i+=count;  
				   
				} 
				let newdata={};
				for(var  i = 0 ;i<res.length;i++)  
				{  
					newdata[res[i][0]]= res[i][1];
				}
				newdata=Object.keys(newdata).sort(function(a,b){return newdata[a]-newdata[b]});
				console.log(newdata);
				alldata = newdata;
				if(alldata.length<9){
					this.hotdata = [alldata[alldata.length-1],alldata[alldata.length-2],alldata[alldata.length-3],alldata[alldata.length-4]];
					this.nohotdata = [alldata[0],alldata[1],alldata[2],alldata[3]];
				}else{
					this.hotdata = [alldata[alldata.length-1],alldata[alldata.length-2],alldata[alldata.length-3],alldata[alldata.length-4],alldata[alldata.length-5],alldata[alldata.length-6],alldata[alldata.length-7],alldata[alldata.length-8]];
					this.nohotdata = [alldata[0],alldata[1],alldata[2],alldata[3],'3',alldata[4],'18',alldata[5]];
				}
				
				
                let bgaudio = document.getElementById('audiobg');
				window.STORE.gameName="SICBO";

                if(this.togglebgAudio==='true'){
                    bgaudio.play();
                }else{
                    bgaudio.pause();
                }

                this.loading = false;
				console.log(data.bet_limit);
				this.bet_limitbox=data.bet_limit;
                let bet_limit = data.bet_limit;
                this.bet_limit = bet_limit;
                this.limits = [
                    {title: this.$t("DRAGON"), odds: this.odds.PLAYER, min: bet_limit.bet_min / 100, max: bet_limit.bet_max / 100}
                ];


                this.round = data.round;
                this.remains = [data.remaining_bet_time, Date.now()].join("-");
                if (data.remaining_bet_time > 0) {
                    this.alert(this.$t("PLEASE_WAIT_FOR_THE_NEXT_ROUND"), 0); /// 提示等待下一局

                    this.cannotBet = true;
                    this.showRemains = true;
					this.client = new WebSocket(this.$t("Sicbo_room"+this.roomID));
					let player = new jsmpeg(this.client, {canvas: document.getElementById("VIDEO"), seekable: true});
					this.play = player;
					if(document.getElementById("VIDEO")){
						document.getElementById("VIDEO").style.width="25rem";
						document.getElementById("VIDEO").style.height="12rem";
						document.getElementById("VIDEO").style.display="none";
						document.getElementById("VIDEO").style.top="3.1rem";
						document.getElementById("VIDEO").style.left="47%";
						document.getElementById("VIDEO").style.marginLeft="-10rem";
					}
                }else{
					this.client = new WebSocket(this.$t("Sicbo_room"+this.roomID));
					let player = new jsmpeg(this.client, {canvas: document.getElementById("VIDEO"), seekable: true});
					this.play = player;
					if(document.getElementById("VIDEO")){
						document.getElementById("VIDEO").style.width="25rem";
						document.getElementById("VIDEO").style.height="12rem";
						document.getElementById("VIDEO").style.display="none";
						document.getElementById("VIDEO").style.top="3.1rem";
						document.getElementById("VIDEO").style.left="47%";
						document.getElementById("VIDEO").style.marginLeft="-10rem";
					}
				}
            },
            setBetTime(data){
                if (data.room_id - this.roomID === 0 && data.game_id === 10) {
                    this.remains = [data.bet_timer, Date.now()].join("-");
                }
            },
            changechips(chip,selectedChip){

                var chipsup=document.getElementById('chipsup');
                this.$utils.playVoice1(chipsup);
                this.selectedChip=chip-0;

                },
            /// 游戏状态
            gameState(data){
                this.round = data.round;
                this.game_state = data.game_state;
                /// 倒计时下注时间
                if (data.game_state === 0) {
					
					///this.resultstatus=false;
					this.oldbetinfo = JSON.parse(sessionStorage.getItem("resbetinfo"))?JSON.parse(sessionStorage.getItem("resbetinfo")):[];
                    this.alert(this.$t("PLACE_YOUR_BETS_PLEASE"));
                    var placeBet=document.getElementById('placeBet');
                        this.$utils.playVoice1(placeBet);
                    this.showRemains = true;
					if(this.client){
						this.client.close();
						document.getElementById("VIDEO").style.display="none";
					}
                } else {
					if(data.game_state === 2){
                        var noBet=document.getElementById('noBet');
                        this.$utils.playVoice1(noBet);
						// this.$utils.playVoice(this.$t("NO_YOUR_BETS_VOICE"),'tipvoice')
						this.client.close();
						document.getElementById("VIDEO").style.display="none";
					}
                    if (data.game_state === 2 && !this.cannotBet) 
					{	
						this.betstatus = false;
						this.unbetstatus = false;
						this.alert(this.$t("NO_MORE_BETS_PLEASE"));
						document.getElementById("VIDEO").style.display="block";
						this.client.close();
						this.client = new WebSocket(this.$t("Sicbo_room"+this.roomID));
						let player = new jsmpeg(this.client, {canvas: document.getElementById("VIDEO"), seekable: true});
						if(document.getElementById("VIDEO")){
							document.getElementById("VIDEO").style.width="25rem";
							document.getElementById("VIDEO").style.height="12rem";
						}
						$(".alldatabox").animate({'left':'-25px'}, 800);
						$(".hisrecordbox").animate({'right':'-25px'}, 800);
						$(".sicbobox").css({'transform':'scale(0.8)'});
						$(".sicbobox").animate({'margin-top':'30px'}, 800);
						$(".sicbobet").css({'bottom':'0rem'});
						clearTimeout(load)
						let load = document.getElementById('load');
						load.style.display="block";
						let loadtime = setTimeout(function(){
								load.style.display="none";
							}, 2000);
					}
                    if (this.cannotBet) {/*tipvoice*/
                        this.tip = "";
                        this.cannotBet = false;
                    }
					this.cannotBet = false;
                    this.showRemains = false;//遍历游戏情况数组
                    this.betters.forEach((el, index) => {
                        el.amount = 0;
                        el.chips.length = 0;
                        this.$set(this.betters, index, el);
                    });

                }
            },
			gameAllamount(data){
				data.total_bets.forEach((el, index) => {
					this.Allamount=this.Allamount+(el.amount/100);
				});
			},
            /// 获取游戏结果
            gameResult(data){
				this.betstatus = false;
				this.unbetstatus = false;
                let that = this;
                let winner = data.winner;
                let info = [
                   this.$t("WINS")
                ];
				let resultdata=[];
                let resultInfo = [];
                resultInfo.push(info[winner]);
				let arrsic=[111,112,113,122,114,123,222,115,124,133,223,116,125,134,224,233,126,135,144,234,225,333,136,145,226,235,244,334,146,155,236,245,335,344,156,246,255,336,345,444,166,256,346,355,445,266,356,446,455,366,456,555,466,556,566,666];
				this.winnerimg = arrsic[winner].toString().split('');
				this.turnresultnum=parseInt(arrsic[winner].toString().split('')[0])+parseInt(arrsic[winner].toString().split('')[1])+parseInt(arrsic[winner].toString().split('')[2]);;
				this.resultstatus=true;
				this.ctrolssxg = true;
				let d1=this.turnresultnum>10?this.$t("BIG"):this.$t("SMALL");
				let d2=this.turnresultnum%2==0?this.$t("EVEN"):this.$t("ODD");
				this.hisinfoimg.reverse().push({img1:arrsic[winner].toString().split('')[0],img2:arrsic[winner].toString().split('')[1],img3:arrsic[winner].toString().split('')[2],num:this.turnresultnum,name1:d1,name2:d2});
                this.hisinfoimg = this.hisinfoimg.reverse();
				resultdata.push([arrsic[winner].toString().split('')[0]]);
				resultdata.push([arrsic[winner].toString().split('')[1]]);
				resultdata.push([arrsic[winner].toString().split('')[2]]);
				resultdata.push([arrsic[winner].toString().split('')[0],arrsic[winner].toString().split('')[1]]);
				resultdata.push([arrsic[winner].toString().split('')[0],arrsic[winner].toString().split('')[2]]);
				resultdata.push([arrsic[winner].toString().split('')[1],arrsic[winner].toString().split('')[2]]);
				resultdata.push([arrsic[winner].toString().split('')[0],arrsic[winner].toString().split('')[1],arrsic[winner].toString().split('')[2]]);
				let alldata=[this.$t("ODD"),this.$t("EVEN"),this.$t("SMALL"),this.$t("BIG"),'1x30',['1','1'],['2','2'],['3','3'],['4','4'],['5','5'],['6','6'],['1','1','1'],['2','2','2'],['3','3','3'],['4','4','4'],['5','5','5'],['6','6','6'],'4','5','6','7','8','9','10','11','12','13','14','15','16','17',['1'],['2'],['3'],['4'],['5'],['6'],['1','2'],['1','3'],['1','4'],['1','5'],['1','6'],['2','3'],['2','4'],['2','5'],['2','6'],['3','4'],['3','5'],['3','6'],['4','5'],['4','6'],['5','6']];
				if(d1==this.$t("BIG")){
					this.betters[3].cssstatus=true;
				}
				if(d1==this.$t("SMALL")){
					this.betters[2].cssstatus=true;
				}
				if(d2==this.$t("ODD")){
					this.betters[1].cssstatus=true;
				}
				if(d2==this.$t("EVEN")){
					this.betters[0].cssstatus=true;
				}
				if(arrsic[winner].toString().split('')[0]==arrsic[winner].toString().split('')[1]==arrsic[winner].toString().split('')[2]){
					this.betters[4].cssstatus=true;
				}
				if(this.turnresultnum>4 )
				alldata.forEach((el,index)=>{
					if((index>4 && index<17) || index>30){
						resultdata.forEach((res,i)=>{
							if(res.sort().toString()==el.sort().toString()){
								this.betters[index].cssstatus=true;
							}
						})
					}else{
						if(el==this.turnresultnum){
							this.betters[index].cssstatus=true;
						}
					}
				});
				
				let winTotalAmount = 0; 
                data.results.forEach(el => {
                    if (el.player_id - this.$route.query.key === 0) {
						that.turnresultprize=(el.prize/ 100).toFixed(9) - 0;
                        for (let key in el.prize) {
                            let winAmount = el.prize[key];
                            if (winAmount) {
                                winTotalAmount += winAmount;
                                that.winSwing[key] = true;
                            }
                        }
                    }
                });
				var playerResult=document.getElementById('result'+this.turnresultnum);
				this.$utils.playVoice1(playerResult);
					                                   // 播报完成
                //this.alert(resultInfo.join("  "));

				let self=this;
                setTimeout(() => {
					$(".alldatabox").animate({'left':'-225px'}, 800);
					$(".hisrecordbox").animate({'right':'-225px'}, 800);
					$(".sicbobox").animate({'margin-top':'0px'}, 800);
					$(".sicbobox").css({'transform':'scale(1)'});
					if(document.documentElement.clientWidth>=900){
						$(".sicbobet").css({'bottom':'8rem'});
					}else{
						$(".sicbobet").css({'bottom':'4rem'});
					}
					
					self.resultstatus=false;
					self.ctrolssxg=false;
					this.betters.forEach((el, index) => {
						el.cssstatus = false;
						this.$set(this.betters, index, el);
					});
                    if (winTotalAmount > 0) {
                        that.winTotalAmount = (winTotalAmount / 100).toFixed(9) - 0;
                        setTimeout(() => that.winTotalAmount = 0, 2000);
                    }
                }, 4000);
                /// 开牌后 清空筹码
				
                this.betters.forEach((el, index) => {
                    el.chips.length = 0;
                    el.hasBetted.length = 0;
                    el.history = 0;
                    el.amount = 0;
                    this.$set(this.betters, index, el);
                });
                this.Allamount=0;
                this.totalAmount=0;
                /// 3s后关闭 中奖 闪烁效果
                setTimeout(() => {
                    for (let key in this.winSwing) {
                        that.winSwing[key] = false;
                    }
                }, 3000);
                
                /// 更新路单
                window.STORE.roomInfo.histories.push(data.winner);
				this.hotcount.push(data.winner);
                this.createRoad();
                this.hotRoad();
            },
            /// 获取牌的信息
            getCard(data){
                // this.$utils.playVoice(this.$t("FLIPCARD"));
               
                 var flipcard=document.getElementById('flipcard');
                this.$utils.playVoice1(flipcard);  
                let owner = ["player"][data.card.owner];
                
                
            },
            addAmount($data,i){
				console.log($data,i);
				let amount = 0;
				$data.chipstatus=true;
				$data.hasBetted.concat($data.chips);
				if(i==="resbet"){
					this.betters.forEach((el,index) => {
						if(index == $data.name){
							el.chips = $data.chips;
							el.chipstatus =true;
							el.amount = $data.history;
							setTimeout(() => {
								el.chipstatus=false;
							}, 1500);
						}
					});
				}
				var chipsdown=document.getElementById('chipsdown');
				this.$utils.playVoice1(chipsdown);
                if (this.game_state === 0) {
                    $data.amount += this.selectedChip;
                    $data.chips.push(this.selectedChip);
                }
				
                
				let limittip = [
                    {title: this.$t("DRAGON"), odds: this.odds.PLAYER, min: this.bet_limit.bet_min / 100, max: this.bet_limit.bet_max / 100}
                ];
				let stat = [];
				
				
                this.betters.forEach((el,index) => {
                    amount += el.amount;
					
					
					//if(this.betters[index].amount>limittip[0].max){
						//this.alert(this.$t('RESULT_FAILED_CANNOT_BET_MORETHANMAXIMUM'));
						//this.betters[index].amount = limittip[0].max;
					//}
					if(index>4 && index<11){
						if(this.betters[index].amount>this.bet_limitbox.bet_double_max / 100){
							this.betters[index].amount = this.bet_limitbox.bet_double_max / 100;
						}
						if(this.betters[index].amount>=this.bet_limitbox.bet_double_min / 100 && this.betters[index].amount>0){
							stat.push(true)
							this.unbetstatus = false;
							this.betstatus=true;
						}else if(this.betters[index].amount<this.bet_limitbox.bet_double_max / 100 && this.betters[index].amount>0){
							stat.push(false)
							this.unbetstatus=false;
							this.betstatus=true;
						}
					}else if(index>3 && index<5){
						if(this.betters[index].amount>this.bet_limitbox.bet_anytripple_max / 100){
							this.betters[index].amount = this.bet_limitbox.bet_anytripple_max / 100;
						}
						if(this.betters[index].amount>=this.bet_limitbox.bet_anytripple_min / 100 && this.betters[index].amount>0){
							stat.push(true)
							this.unbetstatus = false;
							this.betstatus=true;
						}else if(this.betters[index].amount<this.bet_limitbox.bet_anytripple_max / 100 && this.betters[index].amount>0){
							stat.push(false)
							this.unbetstatus=false;
							this.betstatus=true;
						}
					}else if(index>10 && index<17){
						if(this.betters[index].amount>this.bet_limitbox.bet_tripple_max / 100){
							this.betters[index].amount = this.bet_limitbox.bet_tripple_max / 100;
						}
						if(this.betters[index].amount>=this.bet_limitbox.bet_tripple_min / 100 && this.betters[index].amount>0){
							stat.push(true)
							this.unbetstatus = false;
							this.betstatus=true;
						}else if(this.betters[index].amount<this.bet_limitbox.bet_tripple_max / 100 && this.betters[index].amount>0){
							stat.push(false)
							this.unbetstatus=false;
							this.betstatus=true;
						}
					}else if(index>30 && index<37){
						if(this.betters[index].amount>this.bet_limitbox.bet_single_max / 100){
							this.betters[index].amount = this.bet_limitbox.bet_single_max / 100;
						}
						if(this.betters[index].amount>=this.bet_limitbox.bet_single_min / 100 && this.betters[index].amount>0){
							stat.push(true)
							this.unbetstatus = false;
							this.betstatus=true;
						}else if(this.betters[index].amount<this.bet_limitbox.bet_single_max / 100 && this.betters[index].amount>0){
							stat.push(false)
							this.unbetstatus=false;
							this.betstatus=true;
						}
					}else if(index>36 && index<52){
						if(this.betters[index].amount>this.bet_limitbox.bet_domino_max / 100){
							this.betters[index].amount = this.bet_limitbox.bet_domino_max / 100;
						}
						if(this.betters[index].amount>=this.bet_limitbox.bet_domino_min / 100 && this.betters[index].amount>0){
							stat.push(true)
							this.unbetstatus = false;
							this.betstatus=true;
						}else if(this.betters[index].amount<this.bet_limitbox.bet_domino_max / 100 && this.betters[index].amount>0){
							stat.push(false)
							this.unbetstatus=false;
							this.betstatus=true;
						}
					}else if(index>16 && index<31){
						if(this.betters[index].amount>this.bet_limitbox['bet_total'+(index-13)+'_min'] / 100){
							this.betters[index].amount = this.bet_limitbox['bet_total'+(index-13)+'_min'] / 100;
						}
						if(this.betters[index].amount>=this.bet_limitbox['bet_total'+(index-13)+'_min'] / 100 && this.betters[index].amount>0){
							stat.push(true)
							this.unbetstatus = false;
							this.betstatus=true;
						}else if(this.betters[index].amount<this.bet_limitbox['bet_total'+(index-13)+'_max'] / 100 && this.betters[index].amount>0){
							stat.push(false)
							this.unbetstatus=false;
							this.betstatus=true;
						}
					}else{
						if(this.betters[index].amount>limittip[0].max){
							this.betters[index].amount = limittip[0].max;
						}
						if(this.betters[index].amount>=limittip[0].min && this.betters[index].amount>0){
							stat.push(true)
							this.unbetstatus = false;
							this.betstatus=true;
						}else if(this.betters[index].amount<limittip[0].min && this.betters[index].amount>0){
							stat.push(false)
							this.unbetstatus=false;
							this.betstatus=true;
						}
					}
					
                });
				stat.forEach((el, index) => {
                    if(el===false){
						this.unbetstatus = true;
						this.betstatus=false;
					}
                });
                this.totalAmount = amount;
				setTimeout(() => {
                    $data.chipstatus=false;
                }, 1500);
            },
            /// 确认下注
            bet(){
                //if (this.game_state !== 0)return;
                let params = [], totalAmount = 0;
				this.betters.forEach(el => {
					if(el.amount==0){
						//delete params[el.name];
					}else{
						params.push({"index":el.name,"amount":el.amount*100});
					}
                    totalAmount += el.amount;
                });
                if (totalAmount <= 0)return;
                let sendData = {
                    bets: params,
                    header: {key: this.$route.query.key}
                };
                this.betstatus = false;
				this.unbetstatus = false;
				console.log(sendData);
                this.socket(203, sendData, {
                    "213": (data) => { 
                        if (data.result === 0 && data.player_id - this.$route.query.key === 0) {
                            this.betters.forEach((el, index) => {
                                Array.prototype.push.apply(el.hasBetted, el.chips);
                                el.chips.length = 0;
                                el.history += el.amount;
                                el.amount = 0;
                                this.$set(this.betters, index, el);
                            });
							console.log(this.betters);
							sessionStorage.setItem("resbetinfo", JSON.stringify(this.betters));
							
                            this.alert(this.$t("YOUR_BET_IS_SUCCESSFUL") + " " + window.STORE[113].currency + " " + totalAmount);
                            this.userInfo.credit -= totalAmount;
                            //this.totalAmount = 0;
                            this.betSuccess = true;
                        } else {
							this.cancelBet();
                            this.alert(this.$t(this.ERRORCODE[data.result]));
                        }
                    }
                });
            },
            /// 取消下注
            cancelBet(){
				this.betstatus = false;
				this.unbetstatus = false;
                this.betters.forEach((el, index) => {
                    el.amount = 0;
                    el.chips.length = 0;
                    this.$set(this.betters, index, el);
                });
                this.totalAmount = 0;
            },
			 /// 重新下注
			resbet(){
				this.betstatus = false;
				this.unbetstatus = false;
                this.betters.forEach((el, index) => {
                    el.amount = 0;
                    el.chips.length = 0;
                    this.$set(this.betters, index, el);
                });
				let resbetinfo=this.oldbetinfo.length>0?this.oldbetinfo:JSON.parse(sessionStorage.getItem("resbetinfo"));
				let self=this;
				resbetinfo.forEach((el, index) => {
					if(el.hasBetted.length>0){
						self.addAmount(el,"resbet")
					}
				});
            },
            /// 离开房间
            leaveRoom(){
                this.socket(201, {header: {key: this.$route.query.key}}, {
                    "211": (data) => {
                        if (data.result === 0) {
                            console.log("离开房间成功");
                            this.$router.replace({name: "lobby"});
                        } else {
                            console.log("离开房间失败");
                        }
                    }
                });
            },
			videoclick(){
				if(!this.video){
					let video = document.getElementById("VIDEO");
					video.style.width="100%";
					video.style.zIndex="10000000000000";
					video.style.height=document.documentElement.clientHeight+'px';
					video.style.top="0";
					video.style.left="0rem";
					video.style.marginLeft="0rem";
					this.video=true;
				}else{
					let video = document.getElementById("VIDEO");
					video.style.width="25rem";
					video.style.zIndex="1000";
					video.style.height="12rem";
					video.style.top="3.1rem";
					video.style.left="47%";
					video.style.marginLeft="-10rem";
					this.video=false;
				}
				
			},
			videoreturn(){
				let video = document.getElementById("VIDEO");
				video.style.width="25rem";
				video.style.zIndex="1000";
				video.style.height="12rem";
				video.style.top="3.1rem";
				video.style.left="47%";
				video.style.marginLeft="-10rem";
			},
            /// 切换筹码列表
            slideChips($data){
                let index = this.chipsIndex + $data;
                if (index > this.chips.length - 5) {
                    this.chipsIndex = this.chips.length - 5;
                } else if (index < 0) {
                    this.chipsIndex = 0;
                } else {
                    this.chipsIndex = index;
                }
            },
            showMenu(val){
                this.showSideMenu = val;
            },
			showProtocol(val){
                this.showSideMenu = val;
            },
            reverse(arr){
                let _arr = [].concat(arr);
                return _arr.reverse();
            },
            alert(tip, t){
                clearTimeout(TEMP.interval);
                this.tip = tip;
                if (t !== 0 && t !== false) TEMP.interval = setTimeout(() => this.tip = "", t || 2000);
				
            },
            /// 编辑自定义筹码
            editCustomChip(){
                this.showCustomChip = true;
                setTimeout(() => {
                    document.getElementById("CustomChip").focus();
                }, 200);
            },
            /// 保存自定义筹码
            saveCustomChip(){
                if (this.customChip === "" || this.customChip - 0 < 0) return this.customChip = "";
                this.selectedChip = this.customChip;
                this.showCustomChip = false;
            },
            /// 生成路单
            createRoad(histories){
                 ///histories = histories || window.STORE.roomInfo.histories || [];
				 ///let w = new Waybill(histories);
				/// this.road.bead = w.TurnRoad();
            },
			/// 问路路单
            createknowRoad(histories,val1,val2){
				
            },
			fullScreen(){
				this.$utils.fullScreen(document.getElementsByTagName('body')[0]);
				document.getElementsByTagName('body')[0].style.width="100%";
			},
			closebetinfo(){
				$(".dialogbetinfosic").css("display",'none');
			},
			openbetinfo(){
				$(".dialogbetinfosic").css("display",'block');
			},
			leftdata(id){
				$(id).animate({'left':'-25px'}, 800);
			},
			rightdata(id){
				$(id).animate({'right':'-25px'}, 800);
			},
			closealldata(){
				$(".alldatabox").animate({'left':'-225px'}, 800);
				$(".hisrecordbox").animate({'right':'-225px'}, 800);
			},
			hotRoad(histories){
				let allresults = histories || window.STORE.roomInfo.histories || [];
                return new Waybill(allresults,allresults).hotRoad();
			}
        },
        beforeRouteLeave(to, from, next){
            /// 离开页面时先退出房间
            this.loading = true;
            this.socket(201, {header: {key: this.$route.query.key}}, {
                "211": (data) => {
                    if (data.result === 0) {
                        next();
                    } else {
                        this.loading = false;
                        this.alertInfo = this.$t(this.ERRORCODE[data.result]) || this.ERRORCODE[data.result];
                        console.log("退出房间失败，错误代码：", data.result);
                        next(false);
                    }
                }
            });
        },
    }
</script>