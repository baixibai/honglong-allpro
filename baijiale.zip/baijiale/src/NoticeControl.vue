<template>
	<div class="voicebg-dialog" v-show="voiceProtocol==true">
		<a href="javascript:;" class="close-btn" @click="closethis">X</a>
		<div class="voicecontent">
			<div class="voicebgmode">
				<span class="titlename">{{bgtitle}}：</span>
				<div id="applebtn" class="open1" v-bind:class="{ 'open1' : isA, 'close1': !isA}">
					<div id="applecon" v-bind:class="{ 'open2' : isA, 'close2': !isA}" class="open2" @click="togglebgState"></div>
				</div>
			</div>
			<div class="voicebgmode">
				<span class="titlename">{{tiptitle}}：</span>
				<div id="applebtn" class="open1" v-bind:class="{ 'open1' : isB, 'close1': !isB}">
					<div id="applecon" v-bind:class="{ 'open2' : isB, 'close2': !isB}" class="open2" @click="toggleState"></div>
				</div>
			</div>
		</div>
	</div>
</template>

<script>
    export default {
		props:{
			voiceProtocol: {},
		},
        data(){
            return {
                isA: this.$utils.getCookie('voicebgstate') && this.$utils.getCookie('voicebgstate')=='false'?false:true,
				isB: this.$utils.getCookie('voicetipstate') && this.$utils.getCookie('voicetipstate')=='false'?false:true,
				bgtitle:this.$t("VOICE_BG_TITLE"),
				tiptitle:this.$t("VOICE_TIP_TITLE"),
            }
        },
		created(){
            
        },
		methods: {
			/// 切换背景音
			togglebgState(){
				let date=new Date()
				date.setTime(date.getTime()+10*24*3600*1000)
				if(this.isA){
					
					// this.bgaudio.pause();
					document.cookie='voicebgstate='+encodeURIComponent(false)+'; path=/;expires='+date.toGMTString();
					this.isA = !this.isA;
					this.$parent.$emit("emit-voicebgstate", false);
				}else{
					document.cookie='voicebgstate='+encodeURIComponent(true)+'; path=/;expires='+date.toGMTString()
					this.isA = !this.isA;
					console.log(document.cookie);
					this.$parent.$emit("emit-voicebgstate", true);
				}
              console.log(this.togglebgAudio);
            },
			/// 切换提示音
			toggleState(){
				let date=new Date()
				date.setTime(date.getTime()+10*24*3600*1000)
				if(this.isB){
					document.cookie='voicetipstate='+encodeURIComponent(false)+'; path=/;expires='+date.toGMTString()
					this.isB = !this.isB;
				}else{
					document.cookie='voicetipstate='+encodeURIComponent(true)+'; path=/;expires='+date.toGMTString()
					this.isB = !this.isB;
				}
            },
			closethis(){
				$('.voicebg-dialog').css("display","none");
            },
		}
    }
</script>