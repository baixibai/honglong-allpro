/**
 * Created by ck on 1/12/2017.
 */

export default class {
	
    constructor(url, router) {
        this.url = url;
        this.$socket = null;
        this.fns = {};
        this.interval = null;
        this.router = router;
        this.queue = {}; /// 存储由于ws断开后而没能成功执行的请求
        this.doQueue();
		// this.reconnectInProgress = false;
    }
    
    connect(next) {
        let that = this;
		// that.reconnectInProgress = false
        clearInterval(this.interval);
        console.time("connect")
        this.$socket = new WebSocket(this.url);
        next = next || function () {
            };
        this.$socket.onopen = function () {
            next(null);
            heartbeat();
            console.timeEnd("connect")
            console.log("连接成功");
			let load = document.getElementById('load');
			if(load){
				load.style.display="none";
			}
        };
        
        this.$socket.onclose = function () {
            next(new Error("onclose"));
            console.log("连接关闭");
            that.router.replace("/");
			// that.attemptReconnect();
        };
        
        this.$socket.onmessage = function (message) {
            let data = JSON.parse(message.data);
            let code = [data.header.cls, data.header.type, data.header.method].join("");
            console.log(code, data);
            that.fns[code] && that.fns[code](data);
        };
        
        this.$socket.onerror = function (err) {
			// if(that.reconnectInProgress = false){
				// that.attemptReconnect();
			// }else{
				// next(err);
				// window.location.href = "/";
			// }
			next(err);
			window.location.href = "/";
            //window.location.reload();
            //that.$socket.close();
            //that.router.replace("/");
        };
        
        function heartbeat() {
            if (!that.$socket)return;
            if (that.$socket.readyState > 1) {
                that.connect();
				// that.attemptReconnect();
            } else if (that.$socket.readyState === 1) {
                that.send("000");
            }
        }
        
        this.interval = setInterval(function () {
            heartbeat();
        }, 5000);
    }
	
    attemptReconnect(event) {
		console.log("Start ReConnecting"+new Date());
		if( this.reconnectInProgress ) { return; }

		setTimeout(this.connect, 500);
		this.reconnectInProgress = true;
	}
	
    send(code, data, callbacks) {
        if (this.$socket.readyState !== 1) return this.queue[String(code)] = [code, data, callbacks];
        
        let codes = String(code).match(/^(\d)(\d)(\d+)$/).map(el => el - 0);
        data = data || {};
        let base = {
            cls: codes[1],
            type: codes[2],
            method: codes[3],
            key: 0
        };
			
        if (data.header !== undefined) {
			base.key=data.header.key;
            // Object.assign(base, data.header);
            data.header = base;
        } else {
            data.header = base;
        }
		// base.key=data.header.key;

        for (let key in callbacks) {
            this.fns[String(key)] = callbacks[key];
        }
        
        let json = JSON.stringify(data);
			
        console.log("send code:", code, json);
        this.$socket.send(json);
    }
    
    /// 执行队列
    doQueue() {
        let that = this;
        setInterval(function () {
            if (that.$socket && that.$socket.readyState === 1) {
                let keys = Object.keys(that.queue);
                keys.forEach(el => {
                    let val = that.queue[el];
                    if (val) {
                        that.send.apply(that, val);
                        delete that.queue[el];
                    }
                });
            }
        }, 500);
    }
    
    install(Vue) {
        Vue.prototype.socket = this.send.bind(this);
    }
}
