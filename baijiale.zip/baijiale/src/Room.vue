<template xmlns:v-bind="http://www.w3.org/1999/xhtml">
    <div class="full-height">
        <Loading :show="loading"></Loading>
        <div class="content">
            <!--loading -->
            <div class="mask" style="display:none;"></div>
            <div id="load" class="loading" style="display:none;">
                <div class="circle01">
                    <div class="circle02"></div>
                </div>
            </div>
            <!--loading  end -->
            <!--玩家介面-->
            <div class="menu-close" style="display: none"></div>
            <header class="header clear-fix">
                <!--视讯-->
                <canvas id="VIDEO" class="streaming-box" style="z-index:-1"></canvas>
                <!--<video class="streaming-box">
                    <source />
                </video>
                <img src="images/bg/video-bg.jpg" alt="" class="streaming-box" />-->
                <!--上-->
                <div><a class="btn btn-menu" @click="showSideMenu=true"></a></div>
                <Notice></Notice>
                <div class="playerinfo-box">
                    <div class="userid">{{userInfo.name}}</div>
                    <div class="usermoney">
                        {{userInfo.currency}}<span style="margin-left:0.5rem">{{userInfo.credit}}</span>
                    </div>
                </div>
                <!--<div class="signal-box type2"></div>-->
            </header>
            <!--左-->
            <div class="menu-left">
                <a class="btn" @click="showRoad=showRoad===1?0:1" v-bind:class="[showRoad===1?'active':'','btn-big-'+language]"></a>
                <a class="btn" @click="showRoad=showRoad===2?0:2" v-bind:class="[showRoad===2?'active':'','btn-path-'+language]"></a>
                <a class="btn" @click="showRoad=showRoad===3?0:3" v-bind:class="[showRoad===3?'active':'','btn-eye-'+language]"></a>
                <a class="btn" @click="showRoad=showRoad===4?0:4" v-bind:class="[showRoad===4?'active':'','btn-small-'+language]"></a>
                <a class="btn" @click="showRoad=showRoad===5?0:5" v-bind:class="[showRoad===5?'active':'','btn-road-'+language]"></a>
            </div>
            <!--右-->
            <div class="menu-right">
                <!--按钮列表-->
                <a class="btn btn-messenger gray"></a>
                <a class="btn btn-patawardtable gray"></a>
                <a class="btn btn-audio on" @click="controlVoice">
                <audio id='audiobg' preload="auto" loop="loop" src="../res/audio/bgm/BeatriceBlossom.mp3"></audio>
                <audio id='countsec' src="../res/audio/effect/countdown.mp3"></audio>
                <audio id='flipcard'   src="../res/audio/effect/flipcard.mp3"></audio>
                <audio id='chipsup' src="../res/audio/effect/chips.mp3"></audio>
                <audio id='chipsdown' src="../res/audio/game/click_chip.mp3"></audio>
                <audio id='result0'  v-bind:src="RESULT_0"></audio>
                <audio id='result1'  :src="RESULT_1"></audio>
                <audio id='result2'  :src="RESULT_2"></audio>
                <audio id='result3'  :src="RESULT_3"></audio>
                <audio id='result4'  :src="RESULT_4"></audio>
                <audio id='result5'  :src="RESULT_5"></audio>
                <audio id='result6'  :src="RESULT_6"></audio>
                <audio id='result7'  :src="RESULT_7"></audio>
                <audio id='result8'  :src="RESULT_8"></audio>
                <audio id='result9'  :src="RESULT_9"></audio>
                <audio id='result10' :src="RESULT_10"></audio>
                <!-- <audio id='tievoic' src="../res/audio/languages/zh/baccarat/Tie.mp3"></audio> -->
                <audio id='playervoic' :src="PLAYER_HAS_VOICE"></audio>
                <audio id='bankervoic' :src="BANKER_HAS_VOICE"></audio>
                <audio id='BankerWins' :src="BANKER_WIN_VOICE"></audio>
                <audio id='PlayerWins' :src="PLAYER_WIN_VOICE"></audio>
                <audio id='placeBet' :src="PLACE_YOUR_BETS_VOICE"></audio>
                <audio id='noBet' :src="NO_YOUR_BETS_VOICE"></audio>
                <audio id='Tiewins' :src="tie_win"></audio>
                </a>
                <a class="btn btn-money"  @click="controlRecords"></a>
				<a class="btn btn-supersix gray" style="background:url('../res/images/freshen.png') #1478ea no-repeat;background-size:cover;" @click="controlfreshen()"></a>
				 <!-- @click="controlfreshen"-->
				<a class="btn btn-full" style="background:url('../res/images/fullwindow.png') #1478ea no-repeat;background-size:cover;"  @click="fullScreen()"></a>
            </div>
            <!--对话内容-->
            <div class="message-box">
            </div>
            <!--打赏排行榜-->
            <div></div>
            <!--旁观玩家-->
            <div></div>
            <!--筹码选择-->
            <div class="bottomfunction-box">
                <a class="btn btn-pataward" @click="showLimitsModal=!showLimitsModal"></a>
                <div class="chips-box">
                    <a class="btn" v-for="chip in chips.slice(chipsIndex,chipsIndex+3)" v-bind:class="[chip.toString().split('.').length>1?'btn-chip'+chip.toString().split('.').join('_'):'btn-chip'+chip,selectedChip-chip===0?'select':'']"
                       @click="changechips(chip,selectedChip)"></a>
                    <div class="chipcustom-box" v-bind:class="{select:customChip-0>0}">
                        <a class="btn btn-chipCustom">
                            <span><input id="CustomChip" type='number' v-model="customChip" v-bind:disabled="!showCustomChip" @blur="saveCustomChip"></span>
							<!--<span>{{customChip}}</span>-->
                        </a>
                        <a class="btn btn-edit" @click="editCustomChip"></a>
                    </div>
                    <a class="slick-arrow slick-prev" @click="slideChips(-1)"></a>
                    <a class="slick-arrow slick-next" @click="slideChips(1)"></a>
                </div>
            </div>
            <!--桌面-->
            <!--<div class="desktop-bg"></div>-->
            <div class="desktop-box">
                <div class="percentage-box">
					<!--v-bind:style="{width:percent.player+'%'}"-->
                    <span class="xian-percentage" style="width:40%"><i class="fleft">{{players}}</i><i class="fright">{{percent.player}}%</i></span>
                    <span class="he-percentage" style="width:20%"><i class="fleft">{{TIE}}</i><i class="fright">{{percent.tie}}%</i></span>
                    <span class="zhuang-percentage" style="width:40%"><i class="fright">{{banker}}</i><i class="fleft">{{percent.banker}}%</i></span>
                </div>
                <div class="light-box" :style="ruleid===0 || ruleid===2 || ruleid===4 || ruleid===6?backgroundwin:backgroundbgwin_six">
                    <!--<div class="bet" v-for="el in betters" v-bind:class="el.className1+'-light '+(el.chips.length>0?'':'')+(winSwing[el.name]?' open':'')"
                         @click="addAmount(el)"   :style="backgroundwin"  v-if="ruleid===0 || ruleid===2 || ruleid===4 || ruleid===6"></div>
					<div class="bet" v-for="el in betters" v-bind:class="el.className1+'-light-six '+(el.chips.length>0?'':'')+(winSwing[el.name]?' open':'')"
						@click="addAmount(el)"   :style="el.className1=='chaojiliu' || el.className1=='chaojiliu2' ?backgroundbgwin_six_l:backgroundbgwin_six"  v-if="ruleid===1 || ruleid===3 || ruleid===5 || ruleid===7"></div>-->
                </div>
				
                <!--桌面上下注的籌碼-->
                <div class="playerbet-box"  v-for="el in betters" v-bind:class="el.className2+(ruleid==1 || ruleid==3 || ruleid==5 || ruleid==7?'-six':'')" v-bind:style="(ruleid==0 || ruleid==2 || ruleid==4 || ruleid==6) && (el.className2=='Supersix_l' || el.className2==='Supersix_r')?{display:'none'}:{}" @click="addAmount(el)">
                    <i class="chips-item" v-for="(chip,index) in el.hasBetted.concat(el.chips).slice(-5)" v-bind:style="{top:-(10*index)+'px'}" v-bind:class="chip.toString().split('.').length>1?'chip'+chip.toString().split('.').join('_'):'chip'+chip">
                        &nbsp;</i>
                    <span class="selfbet type1" v-show="el.hasBetted.concat(el.chips).length>0">{{el.amount+el.history}}<i class="unchecked"></i></span>
                </div>
				<span v-show="max_bankerstatus && (ruleid==6 || ruleid==7)" class="maxbanker"></span>
				<span v-show="max_playerstatus && (ruleid==6 || ruleid==7)" class="maxplayer"></span>
            </div>

            <!--荷官-->
            <div class="dealer-box">
                <div class="dealer-pic">
                    <img v-bind:src="'http://dealerpix.belcsc201602.com/east/'+$utils.toLowerCase(dealer)+'.jpg'"/>
                </div>
                <div class="dealer-info">
                    <div class="name">{{dealer}}</div>
                    <div class="gametype">{{baijiale+roomID}}</div>
                    <div class="id">{{number_of_games}}: {{round}}</div>
                </div>
				<div class="maxdown_b" v-show="ruleid==6 || ruleid==7">{{bankermaxbet}}：{{maxamount.banker>max_banker?maxamount.banker/100:max_banker/100}}</div>
				<div class="maxdown_p" v-show="ruleid==6 || ruleid==7">{{playermaxbet}}：{{maxamount.player>max_player?maxamount.player/100:max_player/100}}</div>
            </div>
			<!--<div class="voice-dialog">
				<div class="voicecontent">
					<div class="voicemode">
						<div id="applebtn" class="open1" v-bind:class="{ 'open1' : isA, 'close1': !isA}">
							<div id="applecon" v-bind:class="{ 'open2' : isA, 'close2': !isA}" class="open2" @click="toggleState"></div>
							<span v-bind:class="{ 'titlename' : isA, 'titlename_op': !isA}">{{isA?supertitle:commonname}}</span>
						</div>
					</div>
				</div>
			</div>-->
            <!--右下角下注确认-->
            <div class="betcheck-box">
                <!--<a class="btn btn-repeat show"></a>-->
                <a :class="'btn '+language +' '+'btn-confirm show'" v-show="betstatus" @click="bet"></a>
                <a :class="'btn '+language +' '+'btn-cancel show'" v-show="betstatus" @click="cancelBet"></a>
				<a :class="'btn '+language +' '+'btn-confirm show'" v-show="unbetstatus" style="-webkit-filter: grayscale(100%);-moz-filter: grayscale(100%);-ms-filter: grayscale(100%);-o-filter: grayscale(100%);filter: grayscale(100%);filter: gray;opacity:0.6;-khtml-opacity:0.5;"></a>
                <a :class="'btn '+language +' '+'btn-cancel show'" v-show="unbetstatus" @click="cancelBet"></a>
                <!--<a class="btn btn-delete"></a>-->
                <!--<a class="btn btn-end"></a>-->
            </div>
            <!--下注倒数-->
            <div class="countdown-box" v-show="showRemains">
                <div class="wrapper">
                    <div class="back"></div>
                    <div class="pie spinner"></div>
                    <div class="pie filler"></div>
                    <div class="mask"></div>
                    <div class="time-text">
                        <span class="time" id='countDown' v-countdown="remains">2</span>
                        <span class="text">{{betting_please}}</span>
                    </div>
                </div>
            </div>

            <!--聊天視窗-->
            <div class="messenger-dialog">
                <div class="messenger-list">
                </div>
                <div class="example-box Emoji">
                    <div class="title-box">
                        <span>{{Select_the_text_you_want_to_send}}</span>
                        <a class="btn btn-close"></a>
                    </div>
                    <div class="sentence-box">
                        <div class="setscroll">
                            <div name="example1" class="sentence-item">小美眉，给我的飞吻吧～</div>
                            <div name="example2" class="sentence-item">美女，你叫什么名字？</div>
                            <div name="example3" class="sentence-item">小妞，挥挥手～</div>
                            <div name="example4" class="sentence-item">今天手气不好，美女帮我打打气～</div>
                            <div name="example5" class="sentence-item">赢钱好容易，小妞好给力</div>
                            <div name="example6" class="sentence-item">赢要冲，输要缩～</div>
                            <div name="example7" class="sentence-item">师父说拿AK不赌是棒槌～</div>
                            <div name="example8" class="sentence-item">这么多人买闲家，我买庄家，我是个倔梆子</div>
                            <div name="example9" class="sentence-item">开个六给他，让他赢庄家一百块</div>
                        </div>
                    </div>
                </div>
                <div class="example-box Example">
                    <div class="title-box">
                        <span>{{Select_the_expression_you_want_to_send}}</span>
                        <a class="btn btn-close"></a>
                    </div>
                    <div class="emoji-box">
                        <div class="setscroll">
                            <div name="emoji1" class="emoji-item ei1"></div>
                            <div name="emoji2" class="emoji-item ei2"></div>
                            <div name="emoji3" class="emoji-item ei3"></div>
                            <div name="emoji4" class="emoji-item ei4"></div>
                            <div name="emoji5" class="emoji-item ei5"></div>
                            <div name="emoji6" class="emoji-item ei6"></div>
                            <div name="emoji7" class="emoji-item ei7"></div>
                            <div name="emoji8" class="emoji-item ei8"></div>
                            <div name="emoji9" class="emoji-item ei9"></div>
                            <div name="emoji10" class="emoji-item ei10"></div>
                            <div name="emoji11" class="emoji-item ei11"></div>
                            <div name="emoji12" class="emoji-item ei12"></div>
                            <div name="emoji13" class="emoji-item ei13"></div>
                            <div name="emoji14" class="emoji-item ei14"></div>
                            <div name="emoji15" class="emoji-item ei15"></div>
                            <div name="emoji16" class="emoji-item ei16"></div>
                            <div name="emoji17" class="emoji-item ei17"></div>
                            <div name="emoji18" class="emoji-item ei18"></div>
                            <div name="emoji19" class="emoji-item ei19"></div>
                            <div name="emoji20" class="emoji-item ei20"></div>
                            <div name="emoji21" class="emoji-item ei21"></div>
                            <div name="emoji22" class="emoji-item ei22"></div>
                            <div name="emoji23" class="emoji-item ei23"></div>
                            <div name="emoji24" class="emoji-item ei24"></div>
                            <div name="emoji25" class="emoji-item ei25"></div>
                            <div name="emoji26" class="emoji-item ei26"></div>
                            <div name="emoji27" class="emoji-item ei27"></div>
                            <div name="emoji28" class="emoji-item ei28"></div>
                        </div>
                    </div>
                </div>
                <div class="messenger-function">
                    <a class="btn btn-emoji"></a>
                    <a class="btn btn-write"></a>
                </div>
            </div>
            <!--赢钱排行榜-->
            <div class="patawardtable-dialog" style="display:;">
                <div class="title">{{ranking_list}}</div>
                <div class="patawardtable-item">
                    <img src="/res/images/BlueUser.png" alt="" class="pataward-img"/>
                    <span class="pataward-name green">Abc666</span>
                    <div class="pataward-no">10000</div>
                </div>
                <div class="patawardtable-item">
                    <img src="/res/images/BlueUser.png" alt="" class="pataward-img"/>
                    <span class="pataward-name blue">Abc666</span>
                    <div class="pataward-no">10000</div>
                </div>
                <div class="patawardtable-item">
                    <img src="/res/images/BlueUser.png" alt="" class="pataward-img"/>
                    <span class="pataward-name red">Abc666</span>
                    <div class="pataward-no">10000</div>
                </div>
                <div class="patawardtable-item">
                    <img src="/res/images/BlueUser.png" alt="" class="pataward-img"/>
                    <span class="pataward-name green">Abc666</span>
                    <div class="pataward-no">10000</div>
                </div>
                <div class="patawardtable-item">
                    <img src="/res/images/BlueUser.png" alt="" class="pataward-img"/>
                    <span class="pataward-name blue">Abc666</span>
                    <div class="pataward-no">10000</div>
                </div>
            </div>

            <!--打赏-->
            <div class="pataward-dialog">
                <div class="pataward-item pi1">
                    <div class="item-info">
                        <div class="item-pic">
                            <i></i>
                        </div>
                        <span class="item-price">1800</span>
                    </div>
                </div>
                <div class="pataward-item pi2">
                    <div class="item-info">
                        <div class="item-pic">
                            <i></i>
                        </div>
                        <span class="item-price">1800</span>
                    </div>
                </div>
                <div class="pataward-item pi3">
                    <div class="item-info">
                        <div class="item-pic">
                            <i></i>
                        </div>
                        <span class="item-price">1800</span>
                    </div>
                </div>
                <div class="arrow-box">
                    <a class="btn btn-leftarr"></a>
                    <a class="btn btn-rightarr"></a>
                </div>
                <a class="btn btn-close"></a>
            </div>

            <div class="pataward-box">
                <div class="item">
                    <i></i>
                </div>
                <div class="item">
                    <i></i>
                </div>
                <div class="item">
                    <i></i>
                </div>
            </div>

            <!--小費確認-->
            <div class="alert alert-box">
                <i class="i-alert"></i>
                <div class="info-box">{{Whether_to_give_tips}}</div>
                <div class="function-box">
                    <a class="btn btn-no">{{no}}</a>
                    <a class="btn btn-yes">{{yes}}</a>
                </div>
            </div>
            <!--提示框-->
            <div class="ui-dialog" v-show="tip">
                <a href="javascript:;" class="close-btn" @click="tip=null">x</a>
                <div class="d-body succeed-con">{{tip}}</div>
            </div>

            <!--房间限额-->
            <div class="xiane-dialog" v-show="showLimitsModal">
                <a class="btn btn-close" @click="showLimitsModal=false"></a>
                <div class="title">{{room_limit}}</div>
                <table>
                    <thead>
                    <tr>
                        <th>{{designation}}</th>
                        <th>{{odds1}}</th>
                        <th>{{Minimum_bet}}</th>
                        <th>{{Maximum_bet}}</th>
                    </tr>
                    </thead>
                    <tbody>
                    <tr v-for="item in limits">
                        <td>{{item.title}}</td>
                        <td>{{item.odds.join(" : ")}}</td>
                        <td>{{item.min}}</td>
                        <td>{{item.max}}</td>
                    </tr>
                    </tbody>
                </table>
            </div>

            <!--派奖效果-->
            <div class="paicaiinfo-box" style="display:none;" v-show="winTotalAmount>0">
                <div class="paicai-box">
                    <div class="paicai-pic"></div>
                    <div :class="'getno-box'+' '+language">
                        <span>{{winTotalAmount}}</span>
                    </div>
                </div>
            </div>

            <!--出牌-->
            <div class="chupai-box" v-show="cards.player.length>0||cards.banker.length>0">
                <div class="chupai-side chupai-player"  style="text-align:right;">
					<div style="direction: rtl;margin-right:13px;">
                        <img width="55" v-for="(item,index) in cards.player" v-bind:src="openindex.player[index]==index || (ruleid!=6 && ruleid!=7)?'res/images/origin/'+['S','H','C','D'][item.type]+item.num+'.png':'res/images/paibg.png'"
                             v-bind:class="{'card-h':cards.player.length==3&&index===2}">
                    </div>
                    <b>{{players}}</b>
                    <b class="point" v-if="ruleid!=6 && ruleid!=7">{{cards.playerResult}}</b>
                    <b class="point" v-if="ruleid==6 || ruleid==7">{{cards.turn_playerResult}}</b>
                </div>
                <div class="chupai-side chupai-banker"  style="text-align:left;">
                    <div style="margin-left:13px;">
                        <img width="55" v-for="(item,index) in cards.banker" v-bind:src="openindex.banker[index]==index || (ruleid!=6 && ruleid!=7)?'res/images/origin/'+['S','H','C','D'][item.type]+item.num+'.png':'res/images/paibg.png'"
                             v-bind:class="{'card-h':cards.banker.length==3&&index===2}">
                    </div>
                    <b>{{banker}}</b>
                    <b class="point" v-if="ruleid!=6 && ruleid!=7">{{cards.bankerResult}}</b>
                    <b class="point" v-if="ruleid==6 || ruleid==7">{{cards.turn_bankerResult}}</b>
                </div>
            </div>
			
			 <!--咪牌cards.banker.length>0 && -->
            <div class="turn-box" id="turn"  v-show="cards.banker.length>0 &&(ruleid==6 || ruleid==7)">
                
				<div class="turn-side turn-player"  style="text-align:right;">
					
					<div style="direction: rtl;height:13rem;text-align:center;position:relative;">
						
                        <div class="paibox cardover" style="margin-left:20px;" v-for="(item,index) in cards.player"  v-if="cards.player.length<3">
							<a class="zhutu" :id="'current_player_'+index">
								<img v-if="userInfo.name===playersqueezename" class="paibgts" v-show="openindex.player[index]!=index" src="res/images/paibgts.png" />
								<img class="bgimg" v-bind:src="openindex.player[index]==index?'res/images/origin/'+['S','H','C','D'][item.type]+item.num+'.png':'res/images/paibg.png'"/>
								<div v-if="userInfo.name===playersqueezename">
									<div :id="'area_'+index+'_player1'" class="area1" @click="openturnStyle(index,'player','1','-74','-74','-22','-22')"></div>
									<div :id="'area_'+index+'_player2'" class="area2" @click="openturnStyle(index,'player','2','-84','-99','-1','0')"></div>
									<div :id="'area_'+index+'_player3'" class="area3" @click="openturnStyle(index,'player','3','-74','74','-22','22')"></div>
									<div :id="'area_'+index+'_player4'" class="area4"></div>
									<div :id="'area_'+index+'_player5'" class="area5" @click="openturnStyle(index,'player','5','74','74','20','20')"></div>
									<div :id="'area_'+index+'_player6'" class="area6" @click="openturnStyle(index,'player','6','95','121','0','0')"></div>
									<div :id="'area_'+index+'_player7'" class="area7" @click="openturnStyle(index,'player','7','87','-87','20','-20')"></div>
									<div :id="'area_'+index+'_player8'" class="area8"></div>
								</div>
								<a class="turn-open" v-show="openindex.player[index]!=index && userInfo.name==playersqueezename" @click="openturn('player',item,index)">open</a>
							</a>
							<div class="zzt" :id="'zzimg_player_'+index">
								<img class="cont_player" v-bind:src="'res/images/origin/'+['S','H','C','D'][item.type]+item.num+'.png'">
								<div>
									<img :id="'hand_'+index+'_player1'" class="hand" src="res/images/handcommon.png" />
									<img :id="'hand_'+index+'_player2'" class="hand1" src="res/images/handdown.png" />
									<img :id="'hand_'+index+'_player3'" class="hand" src="res/images/handcommon.png" />
									<img :id="'hand_'+index+'_player4'" class="hand2" src="res/images/handleft.png" />
									<img :id="'hand_'+index+'_player5'" class="hand" src="res/images/handcommon.png" />
									<img :id="'hand_'+index+'_player6'" class="hand1" src="res/images/handdown.png" />
									<img :id="'hand_'+index+'_player7'" class="hand" src="res/images/handcommon.png" />
									<img :id="'hand_'+index+'_player8'" class="hand2" src="res/images/handleft.png" />
								</div>
							</div>
						</div>
						<div class="paibox cardover" style="margin-left:20px;" v-for="(item,index) in cards.player"  v-show="index===2">
							<a class="zhutu" :id="'current_player_'+index">
								<img v-if="userInfo.name===playersqueezename" v-show="openindex.player[index]!=index" class="paibgts" src="res/images/paibgts.png" />
								<img class="bgimg" v-bind:src="openindex.player[index]==index?'res/images/origin/'+['S','H','C','D'][item.type]+item.num+'.png':'res/images/paibg.png'"/>
								<div v-if="userInfo.name===playersqueezename">
									<div :id="'area_'+index+'_player1'" class="area1" @click="openturnStyle(index,'player','1','-74','-74','-22','-22')"></div>
									<div :id="'area_'+index+'_player2'" class="area2" @click="openturnStyle(index,'player','2','-84','-99','-1','0')"></div>
									<div :id="'area_'+index+'_player3'" class="area3" @click="openturnStyle(index,'player','3','-74','74','-22','22')"></div>
									<div :id="'area_'+index+'_player4'" class="area4"></div>
									<div :id="'area_'+index+'_player5'" class="area5" @click="openturnStyle(index,'player','5','74','74','20','20')"></div>
									<div :id="'area_'+index+'_player6'" class="area6" @click="openturnStyle(index,'player','6','95','121','0','0')"></div>
									<div :id="'area_'+index+'_player7'" class="area7" @click="openturnStyle(index,'player','7','87','-87','20','-20')"></div>
									<div :id="'area_'+index+'_player8'" class="area8"></div>
								</div>
								<a class="turn-open" v-show="openindex.player[index]!=index && userInfo.name==playersqueezename" @click="openturn('player',item,index)">open</a>
							</a>
							<div class="zzt" :id="'zzimg_player_'+index">
								<img class="cont_player" v-bind:src="'res/images/origin/'+['S','H','C','D'][item.type]+item.num+'.png'">
								<div>
									<img :id="'hand_'+index+'_player1'" class="hand" src="res/images/handcommon.png" />
									<img :id="'hand_'+index+'_player2'" class="hand1" src="res/images/handdown.png" />
									<img :id="'hand_'+index+'_player3'" class="hand" src="res/images/handcommon.png" />
									<img :id="'hand_'+index+'_player4'" class="hand2" src="res/images/handleft.png" />
									<img :id="'hand_'+index+'_player5'" class="hand" src="res/images/handcommon.png" />
									<img :id="'hand_'+index+'_player6'" class="hand1" src="res/images/handdown.png" />
									<img :id="'hand_'+index+'_player7'" class="hand" src="res/images/handcommon.png" />
									<img :id="'hand_'+index+'_player8'" class="hand2" src="res/images/handleft.png" />
								</div>
							</div>
						</div>
						
                    </div>
                    <b>{{players}}</b>
                    <b class="point"></b>
                </div>
				<!--<div class="turn-side turn-player"  style="text-align:right;">
					
					<div style="direction: rtl;height:13rem;text-align:center;position:relative;">
						
                        <div class="paibox cardover" style="margin-left:20px;">
							<a class="zhutu" :id="'current_player_1'">
								<img class="paibgts" src="res/images/paibgts.png" />
								<img class="bgimg" v-bind:src="'res/images/paibg.png'"/>
								<div>
									<div :id="'area_1_player1'" class="area1" @click="openturnStyle('1','player','1','-74','-74','-22','-22')"></div>
									<div :id="'area_1_player2'" class="area2" @click="openturnStyle('1','player','2','-84','-99','-1','0')"></div>
									<div :id="'area_1_player3'" class="area3" @click="openturnStyle('1','player','3','-74','74','-22','22')"></div>
									<div :id="'area_1_player4'" class="area4"></div>                
									<div :id="'area_1_player5'" class="area5" @click="openturnStyle('1','player','5','74','74','20','20')"></div>
									<div :id="'area_1_player6'" class="area6" @click="openturnStyle('1','player','6','95','121','0','0')"></div>
									<div :id="'area_1_player7'" class="area7" @click="openturnStyle('1','player','7','87','-87','20','-20')"></div>
									<div :id="'area_1_player8'" class="area8"></div>
								</div>
								<a class="turn-open"  @click="openturn('player',item,index)">open</a>
							</a>
							<div class="zzt" :id="'zzimg_player_1'">
								<img class="cont_player" v-bind:src="'res/images/origin/H5.png'">
								<div>
									<img :id="'hand_1_player1'" class="hand" src="res/images/handcommon.png" />
									<img :id="'hand_1_player2'" class="hand1" src="res/images/handdown.png" />
									<img :id="'hand_1_player3'" class="hand" src="res/images/handcommon.png" />
									<img :id="'hand_1_player4'" class="hand2" src="res/images/handleft.png" />
									<img :id="'hand_1_player5'" class="hand" src="res/images/handcommon.png" />
									<img :id="'hand_1_player6'" class="hand1" src="res/images/handdown.png" />
									<img :id="'hand_1_player7'" class="hand" src="res/images/handcommon.png" />
									<img :id="'hand_1_player8'" class="hand2" src="res/images/handleft.png" />
								</div>
							</div>
						</div>
						<div class="paibox cardover" style="margin-left:20px;">
							<a class="zhutu" :id="'current_player_2'">
								<img class="paibgts" src="res/images/paibgts.png" />
								<img class="bgimg" v-bind:src="'res/images/paibg.png'"/>
								<div>
									<div :id="'area_2_player1'" class="area1" @click="openturnStyle('1','player','1','-74','-74','-22','-22')"></div>
									<div :id="'area_2_player2'" class="area2" @click="openturnStyle('1','player','2','-84','-99','-1','0')"></div>
									<div :id="'area_2_player3'" class="area3" @click="openturnStyle('1','player','3','-74','74','-22','22')"></div>
									<div :id="'area_2_player4'" class="area4"></div>                
									<div :id="'area_2_player5'" class="area5" @click="openturnStyle('1','player','5','74','74','20','20')"></div>
									<div :id="'area_2_player6'" class="area6" @click="openturnStyle('1','player','6','95','121','0','0')"></div>
									<div :id="'area_2_player7'" class="area7" @click="openturnStyle('1','player','7','87','-87','20','-20')"></div>
									<div :id="'area_2_player8'" class="area8"></div>
								</div>
								<a class="turn-open" @click="openturn('player',item,index)">open</a>
							</a>
							<div class="zzt" :id="'zzimg_player_2'">
								<img class="cont_player" v-bind:src="'res/images/origin/H5.png'">
								<div>
									<img :id="'hand_2_player1'" class="hand" src="res/images/handcommon.png" />
									<img :id="'hand_2_player2'" class="hand1" src="res/images/handdown.png" />
									<img :id="'hand_2_player3'" class="hand" src="res/images/handcommon.png" />
									<img :id="'hand_2_player4'" class="hand2" src="res/images/handleft.png" />
									<img :id="'hand_2_player5'" class="hand" src="res/images/handcommon.png" />
									<img :id="'hand_2_player6'" class="hand1" src="res/images/handdown.png" />
									<img :id="'hand_2_player7'" class="hand" src="res/images/handcommon.png" />
									<img :id="'hand_2_player8'" class="hand2" src="res/images/handleft.png" />
								</div>
							</div>
						</div>
                    </div>
                    <b>{{players}}</b>
                    <b class="point">{{cards.playerResult}}</b>
                </div>-->
				
                <div class="turn-side turn-banker"  style="text-align:left;">
                    <div style="direction: rtl;height:13rem;text-align:center;position:relative;">
                        <div class="paibox cardover" style="margin-left:20px;" v-for="(item,index) in cards.banker"   v-if="cards.banker.length<3">
							<a class="zhutu"  :id="'current_banker_'+index">
								<img v-if="userInfo.name===bankersqueezename" v-show="openindex.banker[index]!=index" class="paibgts" src="res/images/paibgts.png" />
								<img class="bgimg" v-bind:src="openindex.banker[index]==index?'res/images/origin/'+['S','H','C','D'][item.type]+item.num+'.png':'res/images/paibg.png'">
								<div v-if="userInfo.name===bankersqueezename">
									<div :id="'area_'+index+'_banker1'" class="area1" @click="openturnStyle(index,'banker','1','-74','-74','-22','-22')"></div>
									<div :id="'area_'+index+'_banker2'" class="area2" @click="openturnStyle(index,'banker','2','-84','-99','-1','0')"></div>
									<div :id="'area_'+index+'_banker3'" class="area3" @click="openturnStyle(index,'banker','3','-74','74','-22','22')"></div>
									<div :id="'area_'+index+'_banker4'" class="area4"></div>
									<div :id="'area_'+index+'_banker5'" class="area5" @click="openturnStyle(index,'banker','5','74','74','20','20')"></div>
									<div :id="'area_'+index+'_banker6'" class="area6" @click="openturnStyle(index,'banker','6','95','121','0','0')"></div>
									<div :id="'area_'+index+'_banker7'" class="area7" @click="openturnStyle(index,'banker','7','87','-87','20','-20')"></div>
									<div :id="'area_'+index+'_banker8'" class="area8"></div>
								</div>
								<a class="turn-open" v-show="openindex.banker[index]!=index && userInfo.name==bankersqueezename" @click="openturn('banker',item,index)">open</a>
							</a>
							<div class="zzt" :id="'zzimg_banker_'+index">
								<img class="cont_banker" v-bind:src="'res/images/origin/'+['S','H','C','D'][item.type]+item.num+'.png'">
								<div>
									<img :id="'hand_'+index+'_banker1'" class="hand" src="res/images/handcommon.png" />
									<img :id="'hand_'+index+'_banker2'" class="hand1" src="res/images/handdown.png" />
									<img :id="'hand_'+index+'_banker3'" class="hand" src="res/images/handcommon.png" />
									<img :id="'hand_'+index+'_banker4'" class="hand2" src="res/images/handleft.png" />
									<img :id="'hand_'+index+'_banker5'" class="hand" src="res/images/handcommon.png" />
									<img :id="'hand_'+index+'_banker6'" class="hand1" src="res/images/handdown.png" />
									<img :id="'hand_'+index+'_banker7'" class="hand" src="res/images/handcommon.png" />
									<img :id="'hand_'+index+'_banker8'" class="hand2" src="res/images/handleft.png" />
								</div>
							</div>
						</div>
						<div class="paibox cardover" style="margin-left:20px;" v-for="(item,index) in cards.banker"   v-show="index===2">
							<a class="zhutu"  :id="'current_banker_'+index">
								<img v-if="userInfo.name===bankersqueezename" v-show="openindex.banker[index]!=index" class="paibgts" src="res/images/paibgts.png" />
								<img class="bgimg" v-bind:src="openindex.banker[index]==index?'res/images/origin/'+['S','H','C','D'][item.type]+item.num+'.png':'res/images/paibg.png'">
								<div v-if="userInfo.name===bankersqueezename">
									<div :id="'area_'+index+'_banker1'" class="area1" @click="openturnStyle(index,'banker','1','-74','-74','-22','-22')"></div>
									<div :id="'area_'+index+'_banker2'" class="area2" @click="openturnStyle(index,'banker','2','-84','-99','-1','0')"></div>
									<div :id="'area_'+index+'_banker3'" class="area3" @click="openturnStyle(index,'banker','3','-74','74','-22','22')"></div>
									<div :id="'area_'+index+'_banker4'" class="area4"></div>
									<div :id="'area_'+index+'_banker5'" class="area5" @click="openturnStyle(index,'banker','5','74','74','20','20')"></div>
									<div :id="'area_'+index+'_banker6'" class="area6" @click="openturnStyle(index,'banker','6','95','121','0','0')"></div>
									<div :id="'area_'+index+'_banker7'" class="area7" @click="openturnStyle(index,'banker','7','87','-87','20','-20')"></div>
									<div :id="'area_'+index+'_banker8'" class="area8"></div>
								</div>
								<a class="turn-open" v-show="openindex.banker[index]!=index && userInfo.name==bankersqueezename" @click="openturn('banker',item,index)">open</a>
							</a>
							<div class="zzt" :id="'zzimg_banker_'+index">
								<img class="cont_banker" v-bind:src="'res/images/origin/'+['S','H','C','D'][item.type]+item.num+'.png'">
								<div>
									<img :id="'hand_'+index+'_banker1'" class="hand" src="res/images/handcommon.png" />
									<img :id="'hand_'+index+'_banker2'" class="hand1" src="res/images/handdown.png" />
									<img :id="'hand_'+index+'_banker3'" class="hand" src="res/images/handcommon.png" />
									<img :id="'hand_'+index+'_banker4'" class="hand2" src="res/images/handleft.png" />
									<img :id="'hand_'+index+'_banker5'" class="hand" src="res/images/handcommon.png" />
									<img :id="'hand_'+index+'_banker6'" class="hand1" src="res/images/handdown.png" />
									<img :id="'hand_'+index+'_banker7'" class="hand" src="res/images/handcommon.png" />
									<img :id="'hand_'+index+'_banker8'" class="hand2" src="res/images/handleft.png" />
								</div>
							</div>
						</div>
                    </div>
                    <b>{{banker}}</b>
                    <b class="point"></b>
                </div>
            </div>
			

            <!--路单-->
            <div class="room-waybill" v-show="showRoad>0">
                <div v-show="showRoad===1">
                    <div class="w-title">{{highroad}}</div>
                    <div v-html="road.big"></div>
					<div class="knowroad" @click="createknowRoad('','庄00001','庄')">
						<span>{{b_knowload}}</span>
						<i v-bind:class="road.knowblank[0]=='庄'?'BigEyered':road.knowblank[0]=='闲'?'BigEyeblue':''"></i>
						<i v-bind:class="road.knowblank[1]=='庄'?'Smallred':road.knowblank[0]=='闲'?'Smallblue':''"></i>
						<i v-bind:class="road.knowblank[2]=='庄'?'Roachred':road.knowblank[0]=='闲'?'Roachblue':''"></i>
					</div>
					<div class="knowroad knowroadright" @click="createknowRoad('','闲0001','闲')">
						<span>{{p_knowload}}</span>
						<i v-bind:class="road.knowblank[0]=='庄'?'BigEyeblue':road.knowblank[0]=='闲'?'BigEyered':''"></i>
						<i v-bind:class="road.knowblank[1]=='庄'?'Smallblue':road.knowblank[0]=='闲'?'Smallred':''"></i>
						<i v-bind:class="road.knowblank[2]=='庄'?'Roachblue':road.knowblank[0]=='闲'?'Roachred':''"></i>
					</div>
                </div>
                <div v-show="showRoad===2">
                    <div class="w-title">{{Dish_Road}}</div>
                    <div v-html="road.bead"></div>
					<div class="knowroad" @click="createknowRoad('','庄00001','庄')">
						<span>{{b_knowload}}</span>
						<i v-bind:class="road.knowblank[0]=='庄'?'BigEyered':road.knowblank[0]=='闲'?'BigEyeblue':''"></i>
						<i v-bind:class="road.knowblank[1]=='庄'?'Smallred':road.knowblank[0]=='闲'?'Smallblue':''"></i>
						<i v-bind:class="road.knowblank[2]=='庄'?'Roachred':road.knowblank[0]=='闲'?'Roachblue':''"></i>
					</div>
					<div class="knowroad knowroadright" @click="createknowRoad('','闲0001','闲')">
						<span>{{p_knowload}}</span>
						<i v-bind:class="road.knowblank[0]=='庄'?'BigEyeblue':road.knowblank[0]=='闲'?'BigEyered':''"></i>
						<i v-bind:class="road.knowblank[1]=='庄'?'Smallblue':road.knowblank[0]=='闲'?'Smallred':''"></i>
						<i v-bind:class="road.knowblank[2]=='庄'?'Roachblue':road.knowblank[0]=='闲'?'Roachred':''"></i>
					</div>
                </div>
                <div v-show="showRoad===3">
                    <div class="w-title">{{Big_Eye_Road}}</div>
                    <div v-html="road.eye"></div>
					<div class="knowroad" @click="createknowRoad('','庄00001','庄')">
						<span>{{b_knowload}}</span>
						<i v-bind:class="road.knowblank[0]=='庄'?'BigEyered':road.knowblank[0]=='闲'?'BigEyeblue':''"></i>
						<i v-bind:class="road.knowblank[1]=='庄'?'Smallred':road.knowblank[0]=='闲'?'Smallblue':''"></i>
						<i v-bind:class="road.knowblank[2]=='庄'?'Roachred':road.knowblank[0]=='闲'?'Roachblue':''"></i>
					</div>
					<div class="knowroad knowroadright" @click="createknowRoad('','闲0001','闲')">
						<span>{{p_knowload}}</span>
						<i v-bind:class="road.knowblank[0]=='庄'?'BigEyeblue':road.knowblank[0]=='闲'?'BigEyered':''"></i>
						<i v-bind:class="road.knowblank[1]=='庄'?'Smallblue':road.knowblank[0]=='闲'?'Smallred':''"></i>
						<i v-bind:class="road.knowblank[2]=='庄'?'Roachblue':road.knowblank[0]=='闲'?'Roachred':''"></i>
					</div>
                </div>
                <div v-show="showRoad===4">
                    <div class="w-title">{{trail}}</div>
                    <div v-html="road.small"></div>
					<div class="knowroad" @click="createknowRoad('','庄00001','庄')">
						<span>{{b_knowload}}</span>
						<i v-bind:class="road.knowblank[0]=='庄'?'BigEyered':road.knowblank[0]=='闲'?'BigEyeblue':''"></i>
						<i v-bind:class="road.knowblank[1]=='庄'?'Smallred':road.knowblank[0]=='闲'?'Smallblue':''"></i>
						<i v-bind:class="road.knowblank[2]=='庄'?'Roachred':road.knowblank[0]=='闲'?'Roachblue':''"></i>
					</div>
					<div class="knowroad knowroadright" @click="createknowRoad('','闲0001','闲')">
						<span>{{p_knowload}}</span>
						<i v-bind:class="road.knowblank[0]=='庄'?'BigEyeblue':road.knowblank[0]=='闲'?'BigEyered':''"></i>
						<i v-bind:class="road.knowblank[1]=='庄'?'Smallblue':road.knowblank[0]=='闲'?'Smallred':''"></i>
						<i v-bind:class="road.knowblank[2]=='庄'?'Roachblue':road.knowblank[0]=='闲'?'Roachred':''"></i>
					</div>
                </div>
                <div v-show="showRoad===5">
                    <div class="w-title">{{Cockroach_Road}}</div>
                    <div v-html="road.roach"></div>
					<div class="knowroad" @click="createknowRoad('','庄00001','庄')">
						<span>{{b_knowload}}</span>
						<i v-bind:class="road.knowblank[0]=='庄'?'BigEyered':road.knowblank[0]=='闲'?'BigEyeblue':''"></i>
						<i v-bind:class="road.knowblank[1]=='庄'?'Smallred':road.knowblank[0]=='闲'?'Smallblue':''"></i>
						<i v-bind:class="road.knowblank[2]=='庄'?'Roachred':road.knowblank[0]=='闲'?'Roachblue':''"></i>
					</div>
					<div class="knowroad knowroadright" @click="createknowRoad('','闲0001','闲')">
						<span>{{p_knowload}}</span>
						<i v-bind:class="road.knowblank[0]=='庄'?'BigEyeblue':road.knowblank[0]=='闲'?'BigEyered':''"></i>
						<i v-bind:class="road.knowblank[1]=='庄'?'Smallblue':road.knowblank[0]=='闲'?'Smallred':''"></i>
						<i v-bind:class="road.knowblank[2]=='庄'?'Roachblue':road.knowblank[0]=='闲'?'Roachred':''"></i>
					</div>
                </div>
            </div>
        </div>
		/// 局数弹出层
		<div class="record-dialog" v-show="recordsstate==true">
			<a href="javascript:;" class="close-btn" @click=""></a>
			<div class="recordscontent">
				<div class="recordsmode">
					<span class="titlename">{{Total_Games}}：</span>
					<span class="titlename">{{cardsTotal}}</span>
				</div>
				<div class="recordsmode">
					<span class="titlename" style="color:#178cfe;">{{players}}：</span>
					<span class="titlename" style="color:#178cfe;">{{numberDealer}}</span>
				</div>
				<div class="recordsmode">
					<span class="titlename" style="color:#ee0000;">{{banker}}：</span>
					<span class="titlename" style="color:#ee0000;">{{numberPlayer}}</span>
				</div>
				<div class="recordsmode">
					<span class="titlename" style="color:#268816;">{{TIE}}：</span>
					<span class="titlename" style="color:#268816;">{{numberTie}}</span>
				</div>
			</div>
		</div>
        <SideMenu :show="showSideMenu" :backToLobby="true" :ruleMenu="true" v-on:showMenu="showMenu"  :roomMenu="true"></SideMenu>
        <RuleProtocol :gameID="gameID">  </RuleProtocol>
        <RoomProtocol :roomID="roomID">  </RoomProtocol>
        <GameHistory></GameHistory>
		<NoticeControl :voiceProtocol="voicestate"></NoticeControl>
		<div class="loadImgWrap">
			<div class="cons">
				<div><em></em></div>
				<p><span>0%</span>
			</div>
		</div>
    </div>
</template>

<script>
    import GameHistory from "./GameHistory.vue"
    import Loading from "./Loading.vue"
    import SideMenu from "./SideMenu.vue"
    import Notice from "./Notice.vue"
    import Waybill from "./waybill"
    import RuleProtocol from "./RuleProtocol.vue"
    import RoomProtocol from "./RoomProtocol.vue"
	import NoticeControl from "./NoticeControl.vue"

    let TEMP = {};
    export default {
        data(){
            return {
                togglebgAudio:this.$utils.getCookie('voicebgstate'),
				language:this.$t("LANGUAGE_TYPE"),
                loading: true,
                room_limit:this.$t("ROOM_LIMIT"),
                number_of_games:this.$t("NUMBER_OF_GAMES"),
                designation:this.$t("DESIGNATION"),
                odds1:this.$t("ODDS"),
                Maximum_bet:this.$t("MAXIMUM_BET"),
                Minimum_bet:this.$t("MINIMUM_BET"),
                betting_please:this.$t("BETTING_PLEASE"),
                Select_the_text_you_want_to_send:this.$t("SELECT_THE_TEXT_YOU_WANT_TO_SEND"),
                Select_the_expression_you_want_to_send:this.$t("SELECT_THE_EXPRESSION_YOU_WANT_TO_SEND"),
                ranking_list:this.$t("RANKING_LIST"),
                Asset_details:this.$t("ASSET_DETAILS"),
                today:this.$t("TODAY"),
                Last_3_days:this.$t("LAST_3_DAYS"),
                Last_2_weeks:this.$t("LAST_2_WEEKS"),
                date:this.$t("DATE"),
                game:this.$t("GAME"),
                stake:this.$t("STAKE"),
                announce_of_lottery:this.$t("ANNOUNCE_OF_LOTTERY"),
                Payout:this.$t("PAYOUT"),
                review:this.$t("REVIEW"),
                Whether_to_give_tips:this.$t("WHETHER_TO_GIVE_TIPS"),
                no:this.$t("NO"),
                yes:this.$t("YES"),
                highroad:this.$t("HIGHROAD"),
                Dish_Road:this.$t("DISH_ROAD"),
                Big_Eye_Road:this.$t("BIG_EYE_ROAD"),
                trail:this.$t("TRAIL"),
                Cockroach_Road:this.$t("COCKROACH_ROAD"),
                Total_Games:this.$t("TOTAL_GAMES"),
                banker:this.$t("BANKER"),
                tie_win:this.$t("TIE_VOICE"),
                players:this.$t("PLAYER"),
                RESULT_0:this.$t("RESULT_0"),
                RESULT_1:this.$t("RESULT_1"),
                RESULT_2:this.$t("RESULT_2"),
                RESULT_3:this.$t("RESULT_3"),
                RESULT_4:this.$t("RESULT_4"),
                RESULT_5:this.$t("RESULT_5"),
                RESULT_6:this.$t("RESULT_6"),
                RESULT_7:this.$t("RESULT_7"),
                RESULT_8:this.$t("RESULT_8"),
                RESULT_9:this.$t("RESULT_9"),
                RESULT_10:this.$t("RESULT_10"),
                TIE:this.$t("TIE"),
                BANKER_WIN_VOICE:this.$t("BANKER_WIN_VOICE"),
                PLAYER_WIN_VOICE:this.$t("PLAYER_WIN_VOICE"),
                BANKER_HAS_VOICE:this.$t("BANKER_HAS_VOICE"),
                PLAYER_HAS_VOICE:this.$t("PLAYER_HAS_VOICE"),
                PLACE_YOUR_BETS_VOICE:this.$t("PLACE_YOUR_BETS_VOICE"),
                NO_YOUR_BETS_VOICE:this.$t("NO_YOUR_BETS_VOICE"),
                baijiale:this.$t("GAME_TYPE_1"),
  

                dealer: STORE.roomInfo.dealer_id, /// 荷官名称
                roomID: STORE.roomInfo.room_id, /// 房间id
                round: 0, /// 局数
                bet_time: 0,
                remains: 0, /// 剩余投注时间
                showRemains: false,
                limits: [],
                bet_limit: [],
                game_state: 1,
                cards: {
                    player: [],
                    banker: [],
                    playerResult: "",
                    bankerResult: "",
                    turn_bankerResult: "",
                    turn_playerResult: ""
                },
                countdown:0,
                /// 台面盘数比例
                percent: {
                    player: "",
                    banker: "",
                    tie: ""
                },
                chips: window.STORE.chips[window.STORE[113].currency], 
                chipsIndex: 0,
                selectedChip: window.STORE.chips[window.STORE[113].currency][0],
                customChip: 0,
                showCustomChip: false,
				backgroundwin: {
				  backgroundImage: 'url(' + this.$t("BGIMG_WIN") + ')',
				},
				backgroundbgwin_six: {
				  backgroundImage: 'url(' + this.$t("BGIMG_WIN_SIX") + ')',
				},
				backgroundbgwin_six_l: {
				  backgroundImage: 'url(' + this.$t("BGIMG_WIN_SIX_L") + ')',
				},
				backgroundbgwin_six_r: {
				  backgroundImage: 'url(' + this.$t("BGIMG_WIN_SIX_R") + ')',
				},
                betters: [//可能出现的游戏情况
                    {
                        name: "player_pair",
                        title: this.$t("PLAYER_PAIR"),
                        amount: 0,
                        chips: [],
                        hasBetted: [],
                        history: 0,
                        className1: "xiandui",
                        className2: "Banker",
                    },
                    {
                        name: "player",
                        title: this.$t("PLAYER"),
                        amount: 0, /// 当局投注金额（还没确认下注时）
                        chips: [],
                        hasBetted: [],
                        history: 0, /// 当局已投注金额（已确认下注）
                        className1: "xian",
                        className2: "Player"
                    },
                    {
                        name: "tie",
                        title: this.$t("TIE"),
                        amount: 0,
                        chips: [],
                        hasBetted: [],
                        history: 0,
                        className1: "he",
                        className2: "Tie"
                    },
                    {
                        name: "banker",
                        title: this.$t("BANKER"),
                        amount: 0,
                        chips: [],
                        hasBetted: [],
                        history: 0,
                        className1: "zhuang",
                        className2: "BPair"
                    },
                    {
                        name: "banker_pair",
                        title: this.$t("BANKER_PAIR"),
                        amount: 0,
                        chips: [],
                        hasBetted: [],
                        history: 0,
                        className1: "zhuangdui",
                        className2: "PPair"
                    },
					{
                        name: "super_six",
                        title: this.$t("BANKER_PAIR"),
                        amount: 0,
                        chips: [],
                        hasBetted: [],
                        history: 0,
                        className1: "chaojiliu",
                        className2: "Supersix_l"
                    },
					{
                        name: "super_six2",
                        title: this.$t("BANKER_PAIR"),
                        amount: 0,
                        chips: [],
                        hasBetted: [],
                        history: 0,
                        className1: "chaojiliu2",
                        className2: "Supersix_r"
                    },
					
                ],
                totalAmount: 0, /// 总下注金额
                tip: "",
                userInfo: {
                    name: window.STORE["113"].user.login_id,
                    currency: window.STORE["113"].currency,
                    credit: window.STORE["113"].user.credit
                },
                showSideMenu: false,
                showLimitsModal: false, /// 显示限额
                betSuccess: false,
                odds: {
                    PLAYER: [1, 1],
                    BANKER: [0.95, 1],
                    TIE: [8, 1],
                    PLAYER_PAIR: [11, 1],
                    BANKER_PAIR: [11, 1]
                },
                winSwing: {
                    banker: false,
                    banker_pair: false,
                    player: false,
                    player_pair: false,
                    tie: false,
					super_six:false
                },
                winTotalAmount: 0,
                
                /// 路单相关
                road: {
                    big: "",
                    bead: "",
                    eye: "",
                    small: "",
                    roach: "",
                    knowblank: "",
					knowplayer: "",
                },
                showRoad: 0,
                cannotBet: false, /// 进入房间时当局是否允许下注
				voicestate: false,
				recordsstate:false,
				cardsTotal:"",
				numberDealer:"",
				numberPlayer:"",
				numberTie:"",
				supersixstate:false,
				isA:false,
				supertitle:this.$t("SuperSix"),
				commonname:this.$t("COMMONNAME"),
				screenstatus:false,
				playvideo:'',
				b_knowload:this.$t("B")+' '+this.$t("KNOW_LOAD"),
				p_knowload:this.$t("P")+' '+this.$t("KNOW_LOAD"),
				client:'',
				ruleid:STORE.rule_id,
				gameID:'7',
				player:'',
				betstatus:false,
				unbetstatus:false,
				currentindex:{
					player:0,
					banker:0
				},
				opencardstatus:false,
				playerindex:-1,
				openindex:{
					player:{
						0:'-1',    // -1未打开状态
						1:'-1',
						2:'-1',
					},
					banker:{
						0:'-1',
						1:'-1',
						2:'-1',
					},
				},
				showTurnstatus:false,
				threeStatus:false,
				playersqueezename:'',
				bankersqueezename:'',
				owner:'',
				max_banker:0,
				max_player:0,
				max_bankerstatus:false,
				max_playerstatus:false,
				paramsmount:{banker:{},player:{}},
				maxamount:{banker:0,player:0},
				bankermaxbet:this.$t("BANKER_MAXBET"),
				playermaxbet:this.$t("PLAYER_MAXBET"),
				turncard:this.$t("TURN_CARD")
            };
        },
        components: {
            Loading,
            SideMenu,
            Notice,
            RuleProtocol,
			RoomProtocol,
            GameHistory,
			NoticeControl,
        },
        created () {
            this.$on("emit-voicebgstate", (status) => {
                this.togglebgAudio = status;
                    let bgaudio = document.getElementById('audiobg');
                if(this.togglebgAudio){

                   this.togglebgAudio=this.$utils.getCookie('voicebgstate');
                    bgaudio.play();
                }else{
                    bgaudio.pause();
                }
            });
            console.log("获取房间信息中...，房间key：", this.$route.query.key);
            this.createRoad();
            this.socket(202, {header: {key: this.$route.query.key}}, { 
                "212": this.roomInfo.bind(this),
                "122": this.setBetTime.bind(this),
                "224": this.gameState.bind(this),
                "225": this.gameResult.bind(this),
                "226": this.getCard.bind(this),
                "2214": this.getSqueezename.bind(this),
                
            });
			this.socket(206, {header: {key: this.$route.query.key}}, { 
				"216": this.openCardindex.bind(this),
			});
			let sendData = {
                    bets: {"player_pair":0,"player":0,"tie":0,"banker":0,"banker_pair":0,"super_six":0},
                    header: {key: this.$route.query.key}
                };
			this.socket(203, sendData, {
				"213": this.cardgetbet.bind(this)
			});
			const langname = {
				'zh-CHS' : 'cn',
				'en-US' : 'en',
				'ko-KR' : 'ko',
			};
			this.language = langname[this.language]
			this.chips = window.STORE.chips[window.STORE[113].currency];
        },
        mounted(){
			this.client = new WebSocket(this.$t("Baccarat_room"+this.roomID));
            let player = new jsmpeg(this.client, {canvas: document.getElementById("VIDEO"), seekable: true});
			this.play = player;

			if(this.cards.player.length>2 || this.cards.banker.length>2){
				this.betting_please == this.turncard;
				this.openindex = {
					player:{
						0:0,
						1:1,
						2:this.openindex.player['2'],
					},
					banker:{
						0:0,
						1:1,
						2:this.openindex.banker['2'],
					}
				};
				
			}
			//this.openCard('','player','1');
        },
        watch: {
            "userInfo.credit": function (val) {
                window.STORE["113"].user.credit = val;

            },
            "countdown":function (countdown){
				if(this.betting_please == this.turncard){
					if(this.userInfo.name==this.playersqueezename || this.userInfo.name==this.bankersqueezename){
						this.opencardstatus=true;
					}
					
				}else{
					this.opencardstatus=false;
				}
                var countsec=document.getElementById('countsec');
                if(countdown>0&&countdown<=10){
					this.$utils.playVoice1(countsec);                    
                }
				if((countdown=='' || countdown<1) && this.betting_please == this.turncard){
					this.showRemains = false;
					this.betting_please=this.$t("BETTING_PLEASE");
					if(this.cards.player.length==2){
						this.openindex = {
							player:{
								0:0,
								1:1,
								2:this.openindex.player['2'],
							},
							banker:{
								0:0,
								1:1,
								2:this.openindex.banker['2'],
							}
						};
						this.cards.turn_playerResult = this.$utils.getCardsValue(this.cards.player);
						this.cards.turn_bankerResult = this.$utils.getCardsValue(this.cards.banker);
					}
					
					if(this.cards.player.length==3 && this.openindex.player['2'] != 2){
						let pl = this.cards.player;
						this.openindex.player['2'] = 2;
						this.cards.turn_playerResult = this.$utils.getCardsValue(pl);
					}else{
						this.cards.turn_playerResult = this.$utils.getCardsValue(this.cards.player);
					}
					if(this.cards.banker.length==3 && this.openindex.banker['2'] != 2){
						let pl = this.cards.banker;
						this.openindex.banker['2'] = 2;
						this.cards.turn_bankerResult = this.$utils.getCardsValue(pl);
					}else{
						this.cards.turn_bankerResult = this.$utils.getCardsValue(this.cards.banker);
					}
				
				}
            },
			"cards.player.length":function(val){
				if(val===3){
					this.openCard('','player','2');
					this.openindex = {
						player:{
							0:0,
							1:1,
							2:this.openindex.player['2'],
						},
						banker:{
							0:0,
							1:1,
							2:this.openindex.banker['2'],
						}
					};
				}
				
			},
			"cards.banker.length":function(val){
				if(val===3){
					this.openCard('','banker','2');
					this.openindex = {
						player:{
							0:0,
							1:1,
							2:this.openindex.player['2'],
						},
						banker:{
							0:0,
							1:1,
							2:this.openindex.banker['2'],
						}
					};
				}
				
			},
			//this.$utils.openCard('','player');

        },
        methods: {
			// 刷新视频
			controlfreshen(){
				this.client.close();
				this.client = new WebSocket(this.$t("Baccarat_room"+this.roomID));
				let player = new jsmpeg(this.client, {canvas: document.getElementById("VIDEO"), seekable: true});
				//player.play();
				clearTimeout(load)
				let load = document.getElementById('load');
				load.style.display="block";
				let loadtime = setTimeout(function(){
						load.style.display="none";
					}, 2000);
			},
			/// 控制声音播放
			changeVoice(){
                let date=new Date()

				date.setTime(date.getTime()+10*24*3600*1000)
				if(this.$utils.getCookie('voicestate')=='true'){
					document.cookie='voicestate='+encodeURIComponent(false)+'; path=/;expires='+date.toGMTString()

				}else{
					document.cookie='voicestate='+encodeURIComponent(true)+'; path=/;expires='+date.toGMTString()
				} 
              // this.$utils.playVoice(this.$t("BG1_VOICE"),'bgvoice')
				
            },
			controlVoice(){
				if(this.voicestate==true){
					this.voicestate=false;
				}else{
					this.voicestate=true
				}
				
            },
			// 控制局数弹出框
			controlRecords(){
				if(this.recordsstate==true){
					this.recordsstate=false;
				}else{
					this.recordsstate=true
				}
				
            },
			controlSupersix(){
				if(this.supersixstate==true){
					this.supersixstate=false;
				}else{
					this.supersixstate=true
				}
				
            },
			toggleState(){
				if(this.isA){
					this.isA = !this.isA;
				}else{
					this.isA = !this.isA;
				}
            },
            /// 获取房间信息
            roomInfo(data){
				this.loading = true;
					let bgaudio = document.getElementById('audiobg');
					var countdownfunc =function (){ 
						if(document.getElementById('countDown')){
							this.countdown=parseInt(document.getElementById('countDown').innerHTML) || '';  
						}         
				} 

              window.STORE.gameName="baccarat";
              console.log(window.STORE.gameName)

              setInterval(countdownfunc.bind(this),1000)

                if(this.togglebgAudio==='true'){
                    bgaudio.play();
                }else{
                    bgaudio.pause();
                }

                this.loading = false;
                let bet_limit = JSON.parse(data.bet_limit);
                this.bet_limit = bet_limit;
                this.limits = [
                    {title: this.$t("PLAYER"), odds: this.odds.PLAYER, min: bet_limit.bet_min / 100, max: bet_limit.bet_max / 100},
                    {title: this.$t("BANKER"), odds: this.odds.BANKER, min: bet_limit.bet_min / 100, max: bet_limit.bet_max / 100},
                    {title: this.$t("TIE"), odds: this.odds.TIE, min: bet_limit.bet_tie_min / 100, max: bet_limit.bet_tie_max / 100},
                    {title: this.$t("PLAYER_PAIR"), odds: this.odds.PLAYER_PAIR, min: bet_limit.bet_min / 100, max: bet_limit.bet_max / 100},
                    {title: this.$t("BANKER_PAIR"), odds: this.odds.BANKER_PAIR, min: bet_limit.bet_pair_min / 100, max: bet_limit.bet_pair_max / 100}
                ];


                this.round = data.round;
				console.log(data.remaining_bet_time);
                this.remains = [data.remaining_bet_time, Date.now()].join("-");
                // console.log( this.remains)
                if (data.remaining_bet_time > 0) {
                    this.alert(this.$t("PLEASE_WAIT_FOR_THE_NEXT_ROUND"), 0); /// 提示等待下一局

                    this.cannotBet = true;
                    this.showRemains = true;
                }
                if (data.cards) {
                    if (Array.isArray(data.cards)) {
                        data.cards.forEach(el => {
                            this.$set(this.cards[(["player", "banker"][el.owner])], el.index, el);
                        });
                    } else {
                        this.$set(this.cards[(["player", "banker"][data.owner])], data.index, data);

                    }
                    this.cards.playerResult = this.$utils.getCardsValue(this.cards.player);//获取牌'总'值
                    this.cards.bankerResult = this.$utils.getCardsValue(this.cards.banker);
                }
                // 至此都是获取房间值
            },
            setBetTime(data){
                if (data.room_id - this.roomID === 0 && data.game_id === 7) {
                    this.remains = [data.bet_timer, Date.now()].join("-");
                    this.cards.player.splice(0);
                    this.cards.banker.splice(0);
                }
            },
            changechips(chip,selectedChip){

                var chipsup=document.getElementById('chipsup');
                this.$utils.playVoice1(chipsup);
                // this.$utils.playVoice(this.$t("CHIP_VOICE"));
                this.selectedChip=chip-0;

                },
            /// 游戏状态
            gameState(data){
                console.log(data);
                this.round = data.round;
                this.game_state = data.game_state;
                /// 倒计时下注时间
                if (data.game_state === 0) {
                    this.alert(this.$t("PLACE_YOUR_BETS_PLEASE"));
                    var placeBet=document.getElementById('placeBet');
                        this.$utils.playVoice1(placeBet);
                    this.showRemains = true;
                } else if(data.game_state === 5){
					if(this.userInfo.name===this.playersqueezename){
						this.openCard('','player','0');
						this.openCard('','player','1');
						if(data.squeeze_time === 10000){
							this.openCard('','player','2');
						}
						
					}else if(this.userInfo.name===this.bankersqueezename){
						this.openCard('','banker','0');
						this.openCard('','banker','1');
						if(data.squeeze_time === 10000){
							this.openCard('','banker','2');
						}
						
					}
					this.showRemains = true;
					this.showTurnstatus = true;
					if(data.squeeze_time>10000){
						this.threeStatus = true;
					}
					this.remains = [data.squeeze_time, Date.now()].join("-");
					this.betting_please = this.turncard;
				}else {
					if(data.game_state === 2){
                        var noBet=document.getElementById('noBet');
                        this.$utils.playVoice1(noBet);
					}
                    if (data.game_state === 2 && !this.cannotBet) 
					{	
						this.betstatus = false;
						this.unbetstatus = false;
						this.alert(this.$t("NO_MORE_BETS_PLEASE"));
					}
                    if (this.cannotBet) {/*tipvoice*/
                        this.tip = "";
                        this.cannotBet = false;
                    }
					
                    this.showRemains = false;//遍历游戏情况数组
                    this.betters.forEach((el, index) => {
                        el.amount = 0;
                        el.chips.length = 0;
                        this.$set(this.betters, index, el);
                    });
                    this.totalAmount = 0;

                }
            },
			cardgetbet(data){
				if (data.result === 0) {
					let maxarr_player=[];
					let maxarr_banker=[];
					let maxb = data.bets.banker;
					let maxp = data.bets.player;
					if(data.player_id in this.paramsmount.banker){
						this.paramsmount.banker[data.player_id] = this.paramsmount.banker[data.player_id]+maxb;
					}else{
						this.paramsmount.banker[data.player_id] = maxb;
					}
					if(data.player_id in this.paramsmount.player){
						this.paramsmount.player[data.player_id] = this.paramsmount.player[data.player_id]+maxp;
					}else{
						this.paramsmount.player[data.player_id]=maxp;
					}
					for(let key in this.paramsmount.banker){
						maxarr_banker.push(this.paramsmount.banker[key])
					}
					for(let key in this.paramsmount.player){
						maxarr_player.push(this.paramsmount.player[key])
					}
					for(let i=0;i<maxarr_banker.length;i++){
						if(maxarr_banker.length<2){
							this.maxamount.banker=maxarr_banker[0];
						}else{
							if(maxarr_banker[i]>maxarr_banker[i-1]){
								this.maxamount.banker=maxarr_banker[i];
							}else{
								this.maxamount.banker=maxarr_banker[i-1];
							}
						}
					}
					for(let i=0;i<maxarr_player.length;i++){
						if(maxarr_player.length<2){
							this.maxamount.player=maxarr_player[0];
						}else{
							if(maxarr_player[i]>maxarr_player[i-1]){
								this.maxamount.player=maxarr_player[i];
							}else{
								this.maxamount.player=maxarr_player[i-1];
							}
						}
					}
					
				} 
			},
            /// 获取游戏结果
            gameResult(data){
				this.openindex = {
					player:{
						0:0,
						1:1,
						2:2,
					},
					banker:{
						0:0,
						1:1,
						2:2,
					}
				};
				this.currentindex.palyer = 0;
				this.currentindex.banker = 0;
				this.betstatus = false;
				this.unbetstatus = false;
                let that = this;
                let winner = Number(data.winner).toString(2).split("").reverse();
                if(winner.length>6){
					winner=winner.slice(0,6);
				}
                let info = [
                    this.$t("PLAYER_PAIR"),
                    this.$t("BANKER_PAIR"),
                    this.$t("SUPERSIX"),
                    this.$t("BACCARAT_PLAYER_WIN") +' '+ this.$t("WINS"),
                    this.$t("BACCARAT_BANKER_WIN") +' '+ this.$t("WINS"),
                    this.$t("TIE_WIN")
                ];
                let resultInfo = [];
                winner.forEach((el, index) => {
                    if (index === 2)return;
                    if (el - 1 === 0) resultInfo.push(info[index]);

                });

                /// 处理输赢
                let winTotalAmount = 0; 
                data.results.forEach(el => {
                    if (el.player_id - this.$route.query.key === 0) {
                        this.userInfo.credit = (el.credit / 100).toFixed(9) - 0;
                        for (let key in el.prize) {
                            let winAmount = el.prize[key];
                            if (winAmount) {
                                winTotalAmount += winAmount;
                                that.winSwing[key] = true;
                            }
                        }
                    }
                });

                /// 播报及显示庄赢、闲赢、和 的信息

                var x=0;
                function countSecond()
                 {　
                    x+=1;
                    if(x==1){//标记声音
                        var playervoic=document.getElementById('playervoic');

                        this.$utils.playVoice1(playervoic);

                    }else if(x==2){
                        // this.$utils.playVoice(this.$t("RESULT_"+this.cards.playerResult));
                        var playerResult=document.getElementById('result'+this.cards.playerResult);
                        this.$utils.playVoice1(playerResult);
                    }else if(x==3){
                         var bankervoic=document.getElementById('bankervoic');
                        this.$utils.playVoice1(bankervoic);
                    }else if(x==4){
                        var bankerResult=document.getElementById('result'+this.cards.bankerResult);
                        this.$utils.playVoice1(bankerResult);
                        // this.$utils.playVoice(this.$t('result'+this.cards.bankerResult));
                    }else if(x==5){
                          if(winner[3]==1){
                            var PlayerWins=document.getElementById('PlayerWins');
                            this.$utils.playVoice1(PlayerWins);

                        }else if(winner[4]==1){
                             var bankerwins=document.getElementById('BankerWins');
                             this.$utils.playVoice1(bankerwins);

                        }else if(winner[5]==1){
                            this.$utils.playVoice(this.$t("TIE_VOICE"));
                            var Tiewins=document.getElementById('Tiewins');

                        }
                    return
                    }
                    // console.log(countSecond);
                 　 setTimeout(countSecond.bind(this), 700);
                 };
                 countSecond.apply(this);
                                                              // 播报完成
                this.alert(resultInfo.join("  "));

                /// 统计点数，并4秒后清空牌信息
                this.cards.playerResult = this.$utils.getCardsValue(this.cards.player);
                this.cards.bankerResult = this.$utils.getCardsValue(this.cards.banker);
                this.cards.turn_playerResult = this.$utils.getCardsValue(this.cards.player);
                this.cards.turn_bankerResult = this.$utils.getCardsValue(this.cards.banker);
                setTimeout(() => {
                    this.cards.player.length = 0;
                    this.cards.banker.length = 0;
                    this.cards.playerResult = "";
                    this.cards.bankerResult = ""; 
					this.cards.turn_playerResult = "";
                    this.cards.turn_bankerResult = "";
					this.showTurnstatus = false;
					this.owner='';
					this.openindex = {
						player:{
							0:-1,
							1:-1,
							2:-1,
						},
						banker:{
							0:-1,
							1:-1,
							2:-1,
						}
					};
					this.currentindex = {
						player:0,
						banker:0
					};
					this.threeStatus = false;
					this.opencardstatus = false;
					this.bankersqueezename = '';
					this.playersqueezename = '';
					this.max_banker =0;
					this.max_player =0;
					this.paramsmount.banker = {};
					this.paramsmount.player = {};
					this.max_bankerstatus=false;
					this.max_playerstatus=false;
					this.maxamount.player=0;
					this.maxamount.banker=0;
					this.paramsmount={banker:{},player:{}};
                    /// 清空出牌信息后 再显示派奖效果
                    if (winTotalAmount > 0) {
                        that.winTotalAmount = (winTotalAmount / 100).toFixed(9) - 0;
                        setTimeout(() => that.winTotalAmount = 0, 2000);
                    }
                }, 4000);
                
                /// 开牌后 清空筹码
                this.betters.forEach((el, index) => {
                    el.chips.length = 0;
                    el.hasBetted.length = 0;
                    el.history = 0;
                    el.amount = 0;
                    this.$set(this.betters, index, el);
                });
                
                /// 3s后关闭 中奖 闪烁效果
                setTimeout(() => {
                    for (let key in this.winSwing) {
                        that.winSwing[key] = false;
                    }
                }, 3000);
                
                /// 更新路单
                window.STORE.roomInfo.histories.push(data.winner);
                this.createRoad();
            },
            /// 获取牌的信息
            getCard(data){
                // this.$utils.playVoice(this.$t("FLIPCARD"));
                 var flipcard=document.getElementById('flipcard');
                this.$utils.playVoice1(flipcard);  
                let owner = ["player", "banker"][data.card.owner];//这里是选择是闲还是庄
                this.$set(this.cards[owner], data.card.index, data.card);
                this.cards[owner + "Result"] = this.$utils.getCardsValue(this.cards[owner]);//标记
				if(this.cards.player.length<3 && this.openindex.player['0']==='0' &&  this.openindex.player['1']==='1'){
					let pl = this.cards.player;
					//pl.pop();
					this.cards.turn_playerResult = this.$utils.getCardsValue(pl);
				}
				
				if(this.cards.banker.length<3 && this.openindex.banker['0']==='0' &&  this.openindex.banker['1']==='1'){
					let pl = this.cards.banker;
					//pl.pop();
					this.cards.turn_bankerResult = this.$utils.getCardsValue(pl);
				}
               
				
                //if(this.cards.player.length<3 && this.userInfo.name===this.playersqueezename){
				//	this.openCard('','player','0');
				//	this.openCard('','player','1');
				//}else if(this.cards.player.length>2 && this.userInfo.name===this.playersqueezename){
				//	this.openCard('','player','2');
				//}
				//if(this.cards.banker.length<3 && this.userInfo.name===this.bankersqueezename){
				//	this.openCard('','banker','0');
				//	this.openCard('','banker','1');
				//}else if(this.cards.banker.length>2 && this.userInfo.name===this.bankersqueezename){
				//	this.openCard('','banker','2');
				//}
                
            },
			/// 获取咪主信息
			getSqueezename(data){
				if(data.squeeze_player_name!="NONE"){
					this.playersqueezename=data.squeeze_player_name;
				}else{
					this.playersqueezename='';
				}
				
				if(data.squeeze_banker_name!="NONE"){
					this.bankersqueezename=data.squeeze_banker_name;
				}else{
					this.bankersqueezename='';
				}

			},
            addAmount($data){
				var chipsdown=document.getElementById('chipsdown');
				this.$utils.playVoice1(chipsdown);
                if (this.game_state === 0) {

                    $data.amount += this.selectedChip;
                    $data.chips.push(this.selectedChip);
                }
                let amount = 0;
				let limittip = [
                    {title: this.$t("PLAYER"), odds: this.odds.PLAYER, min: this.bet_limit.bet_min / 100, max: this.bet_limit.bet_max / 100},
					{title: this.$t("PLAYER_PAIR"), odds: this.odds.PLAYER_PAIR, min: this.bet_limit.bet_min / 100, max: this.bet_limit.bet_max / 100},
                    {title: this.$t("TIE"), odds: this.odds.TIE, min: this.bet_limit.bet_tie_min / 100, max: this.bet_limit.bet_tie_max / 100},
                    {title: this.$t("BANKER"), odds: this.odds.BANKER, min: this.bet_limit.bet_min / 100, max: this.bet_limit.bet_max / 100},
                    {title: this.$t("BANKER_PAIR"), odds: this.odds.BANKER_PAIR, min: this.bet_limit.bet_pair_min / 100, max: this.bet_limit.bet_pair_max / 100},
					{title: this.$t("BANKER"), odds: this.odds.BANKER, min: this.bet_limit.bet_min / 100, max: this.bet_limit.bet_max / 100},
					{title: this.$t("BANKER"), odds: this.odds.BANKER, min: this.bet_limit.bet_min / 100, max: this.bet_limit.bet_max / 100},
                ];
				let stat = [];
                this.betters.forEach((el, index) => {
                    amount += el.amount;
					if(this.betters[index].amount>limittip[index].max){
						this.alert(this.$t('RESULT_FAILED_CANNOT_BET_MORETHANMAXIMUM'));
						this.betters[index].amount = limittip[index].max;
					}
					if((this.max_player===0 && index<2) || (this.max_banker===0 && index>2)){
						if(this.betters[index].amount>=limittip[index].min && this.betters[index].amount>0){
							stat.push(true)
							this.unbetstatus=false;
							this.betstatus=true;
						}else if(this.betters[index].amount<limittip[index].min && this.betters[index].amount>0){
							stat.push(false)
						}
					}else if(this.betters[index].amount>0){
						stat.push(true)
						this.unbetstatus=false;
						this.betstatus=true;
					}
					
                });
				console.log(this.game_state);
				console.log(this.betters)
				stat.forEach((el, index) => {
                    if(el===false){
						this.unbetstatus = true;
						this.betstatus=false;
					}
                });
                this.totalAmount = amount;
				
            },
            /// 确认下注
            bet(){
                if (this.game_state !== 0)return;
                let params = {
                    //super_six: 0
                }, totalAmount = 0;
                
                //let errors = [], bet_limit = this.bet_limit;
                this.betters.forEach(el => {
					
					params[el.name] = el.amount * 100;
					if(el.name==='super_six2'){
						params['super_six']=params['super_six']+params['super_six2'];
					}
					delete params['super_six2'];
                    totalAmount += el.amount;
                });
                if (totalAmount <= 0)return;
                let sendData = {
                    bets: params,
                    header: {key: this.$route.query.key}
                };
				console.log(params);
				if(this.max_player>0 && (this.roomID=='201' || this.roomID=='204')){
					if(params.banker>0){
						this.alert('不能于庄闲同时投注');
						this.cancelBet();
						return;
					}
				}
				if(this.max_banker>0  && (this.roomID=='201' || this.roomID=='204')){
					if(params.player>0){
						this.alert('不能于庄闲同时投注');
						this.cancelBet();
						return;
					}
				}
				if(params.banker>0 && params.player>0 && (this.roomID=='201' || this.roomID=='204')){
					this.alert('不能于庄闲同时投注');
					this.cancelBet();
					return;
				}
				this.betstatus = false;
				this.unbetstatus = false;
                this.socket(203, sendData, {
                    "213": (data) => {
						console.log(data);
						
                        if (data.result === 0 && data.player_id - this.$route.query.key === 0) {
							let maxb = data.bets.banker;
							let maxp = data.bets.player;
							this.max_banker=this.max_banker+maxb;
							this.max_player=this.max_player+maxp;
							if(this.max_banker>this.maxamount.banker && this.max_banker!=0){
								this.max_bankerstatus=true;
							}
							if(this.max_player>this.maxamount.player && this.max_player!=0){
								this.max_playerstatus=true;
							}
                            this.betters.forEach((el, index) => {
                                //el.history = data.bets[el.name];
                                Array.prototype.push.apply(el.hasBetted, el.chips);
                                el.chips.length = 0;
                                el.history += el.amount;
                                el.amount = 0;
                                this.$set(this.betters, index, el);
                            });
                            this.alert(this.$t("YOUR_BET_IS_SUCCESSFUL") +" " + window.STORE[113].currency +" " + totalAmount);
                            this.userInfo.credit -= totalAmount;
                            this.totalAmount = 0;
                            this.betSuccess = true;
                        } else {
							if(data.result===0){
								 this.alert('玩家们都在投注看谁能咪牌');
							}
                        }
						
						if (data.result === 0) {
							let maxarr_player=[];
							let maxarr_banker=[];
							let maxb = data.bets.banker;
							let maxp = data.bets.player;
							if(data.player_id in this.paramsmount.banker){
								this.paramsmount.banker[data.player_id] = this.paramsmount.banker[data.player_id]+maxb;
							}else{
								this.paramsmount.banker[data.player_id] = maxb;
							}
							if(data.player_id in this.paramsmount.player){
								this.paramsmount.player[data.player_id] = this.paramsmount.player[data.player_id]+maxp;
							}else{
								this.paramsmount.player[data.player_id]=maxp;
							}
							for(let key in this.paramsmount.banker){
								maxarr_banker.push(this.paramsmount.banker[key])
							}
							for(let key in this.paramsmount.player){
								maxarr_player.push(this.paramsmount.player[key])
							}
							for(let i=0;i<maxarr_banker.length;i++){
								if(maxarr_banker.length<2){
									this.maxamount.banker=maxarr_banker[0];
								}else{
									if(maxarr_banker[i]>maxarr_banker[i-1]){
										this.maxamount.banker=maxarr_banker[i];
									}else{
										this.maxamount.banker=maxarr_banker[i-1];
									}
								}
							}
							for(let i=0;i<maxarr_player.length;i++){
								if(maxarr_player.length<2){
									this.maxamount.player=maxarr_player[0];
								}else{
									if(maxarr_player[i]>maxarr_player[i-1]){
										this.maxamount.player=maxarr_player[i];
									}else{
										this.maxamount.player=maxarr_player[i-1];
									}
								}
							}
							
						} 
						
						if(data.result === 0 && data.player_id - this.$route.query.key !== 0 ){
							if(this.maxamount.banker>this.max_banker){
								this.max_bankerstatus=false;
							}
							if(this.maxamount.player>this.max_player){
								this.max_playerstatus=false;
							}
						}
                    }
                });
            },
            /// 取消下注
            cancelBet(){
				this.betstatus = false;
				this.unbetstatus = false;
                this.betters.forEach((el, index) => {
                    el.amount = 0;
                    el.chips.length = 0;
                    this.$set(this.betters, index, el);
                });
                this.totalAmount = 0;
            },
            /// 离开房间
            leaveRoom(){
                this.socket(201, {header: {key: this.$route.query.key}}, {
                    "211": (data) => {
                        if (data.result === 0) {
                            console.log("离开房间成功");
                            this.$router.replace({name: "lobby"});
                        } else {
                            console.log("离开房间失败");
                        }
                    }
                });
            },
            /// 切换筹码列表
            slideChips($data){
                let index = this.chipsIndex + $data;
                if (index > this.chips.length - 5) {
                    this.chipsIndex = this.chips.length - 5;
                } else if (index < 0) {
                    this.chipsIndex = 0;
                } else {
                    this.chipsIndex = index;
                }
            },
            
            /// 台面盘数比例
            discsPercent(data){
                let o = {B: 0, P: 0, T: 0}, total = data.length;
                data.forEach(el => {
                    switch (el) {
                        case "庄":
                            o.B++;
                            break;
                        case "闲":
                            o.P++;
                            break;
                        case "和":
                            o.T++;
                            break;
                    }
                });
                
                this.percent.player = total > 0 ? ((o.P / total) * 100).toFixed(2) - 0 : 0;
                this.percent.banker = total > 0 ? ((o.B / total) * 100).toFixed(2) - 0 : 0;
                this.percent.tie = total > 0 ? ((o.T / total) * 100).toFixed(2) - 0 : 0;
				
				this.cardsTotal = total;
				this.numberDealer = o.P;
				this.numberPlayer = o.B;
				this.numberTie = o.T;
            },
            
            showMenu(val){
                this.showSideMenu = val;
            },
			showProtocol(val){
                this.showSideMenu = val;
            },
            reverse(arr){
                let _arr = [].concat(arr);
                return _arr.reverse();
            },
            alert(tip, t){
                clearTimeout(TEMP.interval);
                this.tip = tip;
                if (t !== 0 && t !== false) TEMP.interval = setTimeout(() => this.tip = "", t || 2000);
				
            },
            /// 编辑自定义筹码
            editCustomChip(){
                this.showCustomChip = true;
                setTimeout(() => {
                    document.getElementById("CustomChip").focus();
                }, 200);
            },
            /// 保存自定义筹码
            saveCustomChip(){
                if (this.customChip === "" || this.customChip - 0 < 0) return this.customChip = "";
                this.selectedChip = this.customChip;
                this.showCustomChip = false;
            },
            /// 生成路单
            createRoad(histories){
                 histories = histories || window.STORE.roomInfo.histories || [];
                 let allResults = histories.map(el => this.$utils.computedWinner(el));
				 let allResults_2 = histories.map(el => this.$utils.computedWinner2(el));
				
				 let datacard = []
                 this.discsPercent(allResults_2);
                 let results = allResults_2.filter(el => el !== "和");
                 let w = new Waybill(allResults,results);
                 this.road.big = w.BigRoad();
                 this.road.bead = w.PearlRoad();
                 this.road.eye = w.BigEyeRoad();
                 this.road.small = w.SmallRoad();
                 this.road.roach = w.RoachRoad();
				 this.road.knowblank = w.KnowRoad('庄');
				 this.road.knowplayer = w.KnowRoad('闲');
            },
			/// 问路路单
            createknowRoad(histories,val1,val2){
                 histories = window.STORE.roomInfo.histories || [];
                 let allResults = histories.map(el => this.$utils.computedWinner(el));
				 let allResults_2 = histories.map(el => this.$utils.computedWinner2(el));
				 
				 let datacard = []
				 	this.discsPercent(allResults_2);
				 allResults.push(val1)
				 	let results = allResults_2.filter(el => el !== "和");
				 results.push(val2)
                 let w = new Waybill(allResults,results,true);
                 this.road.big = w.BigRoad();
                 this.road.bead = w.PearlRoad();
                 this.road.eye = w.BigEyeRoad(true);
                 this.road.small = w.SmallRoad(true);
                 this.road.roach = w.RoachRoad(true);
            },
			fullScreen(){
				if(navigator.platform.indexOf("Win")!=0){
					this.$utils.fullScreen(document.getElementsByTagName('body')[0]);
					document.getElementsByTagName('body')[0].style.width="100%";
					document.getElementsByTagName('body')[0].style.height=document.documentElement.clientHeight+'px';
					$('.full-height').height(document.documentElement.clientHeight);
					$('.lobby-box').height(document.documentElement.clientHeight);
				}
			},
			openturn(type,item,index){
				this.openindex[type][index] = index;
				this.socket(206, {header: {key: this.$route.query.key},contents:{room_id:STORE.roomInfo.room_id,owner:type,openindex:index}}, { 
					"216": (data) => {
						
					}
				});
				let cardtype = $(".cont_"+type)
				cardtype.animate({
					aa:"180" 
				},{
					step:function(now,fx){
						cardtype.css({"transform":"rotateY("+now+"deg)"})
						if(fx.now=100){
							cardtype.css({"transform":"rotateY(0deg)"})
							this.opencardstatus = false;
						}
					},
					duration:2000
				});
			},
			cardGetindex(data,num){
				if(this.cards[data].length>1){
					if(num==1 && this.currentindex[data]<this.cards[data].length-this.currentindex[data]){
						this.currentindex[data] = this.currentindex[data] + 1;
					}else if(num==-1 && this.currentindex[data]>0){
						this.currentindex[data] = this.currentindex[data] - 1;
					}
				}else{
					this.currentindex[data] = 0;
				}
			},
			openCardindex(data){
				if(data.contents!=null){
					if(data.contents.openindex!=null){
						this.openindex[data.contents.owner][data.contents.openindex] = data.contents.openindex;
					}
				}
			},
			// 接收咪牌效果
			getCardaction(data){
				this.$utils.getCardaction(data);
			},
			/// 动态传递咪牌效果
			openturnStyle(cardindex,owner,areaNo,topinit,leftinit,top,left){
				let data = {contents:{room_id:STORE.roomInfo.room_id,owner:owner,index:areaNo,cardindex:cardindex,pre:[topinit,leftinit,top,left]}};
				//this.getCardaction(data);
				console.log(areaNo);
				this.socket(206, {header: {key: this.$route.query.key},contents:{room_id:STORE.roomInfo.room_id,owner:owner,index:areaNo,cardindex:cardindex,pre:[topinit,leftinit,top,left]}}, { 
					"216": (data) => {
						console.log(data);
					}
				});
			},
			//咪牌动作
			openCard(data,ower,index){
				this.$utils.openCard(data,ower,index,this.openindex,this.openturnStyle);
			},
			
        },
		Getmaxbet(data){
             console.log(data);
        },
        beforeRouteLeave(to, from, next){
            /// 离开页面时先退出房间
            this.loading = true;
            this.socket(201, {header: {key: this.$route.query.key}}, {
                "211": (data) => {
                    if (data.result === 0) {
                        next();
                    } else {
                        this.loading = false;
                        this.alertInfo = this.$t(this.ERRORCODE[data.result]) || this.ERRORCODE[data.result];
                        console.log("退出房间失败，错误代码：", data.result);
                        next(false);
                    }
                }
            });
        },
    }
</script>