<template>
    <div class="full-height">
        <Loading :show="loading"></Loading>
        <div class="baccaratroom-box">
            <header class="header clear-fix">
                <div class="function-box">
                    <router-link class="btn btn-back" to="/lobby"></router-link>
                    <div class="game-box">
                        <div class="game-name">{{gamename}}</div>
                    </div>
                </div>
                <Notice></Notice>
                <div class="inroompeople renshu" v-show="onlineCount!==''"><span>{{onlineCount}}</span></div><!--人数-->
				<div class="inroompeople renshu"><span>{{tip}}</span></div>
            </header>
            <div class="gameroom-box">
				<!--咪牌-->
				<div class="gameroom-info">
                    <div class="room-list" v-for="(item,index) in rooms" v-show="item.room_id!=204">
						<div class="room-list" v-for="(rule,index1) in item.rules" v-show="rule==7">
							<div style="color:#fff;margin-left:18%;padding:1rem 0 0.6rem;">{{'咪牌'+gamename}} {{item.room_id}}</div>
							<a class="btn btn-room">
								<!--<div class="room-name"><span>{{gamename}} {{item.room_id}}</span></div>-->
								<div class="room-info">
									<div class="player-pic woman">
										<img v-bind:src="'http://dealerpix.belcsc201602.com/east/'+$utils.toLowerCase(item.dealer_id)+'.jpg'" v-show="item.dealer_id"/>
									</div>
									<span class="player-name">{{item.dealer_id}}</span>
								</div>
								<div class="cardroad-info" @click="choosetypeStatussix=index">
									<div v-html="bigRoad(item.histories)"></div>
									<div class="wrapper" v-show="item.room_state===0">
										<div class="back"></div>
										<div class="time" v-countdown="item.remains"></div>
									</div>
									<!--<div class="wrapper settlement">
										<div class="back"></div>
										<i></i>
										<span>结算中</span>
									</div>-->
									<div class="wrapper changecard" v-show="item.room_state>1">
										<div class="back"></div>
										<i></i>
										<span>{{$t(["","","MAINTENANCE","ROOM_CHANGE_DEALER","ROOM_CHANGE_SHOE"][item.room_state])}}</span>
									</div>
								</div>
								<div class="otherinfo-box">
									<div class="totalinfo-item xianji"> {{bettinglimit}}</div>
									<div style="height:54px;overflow:auto;">
										
										<div class="totalinfo-item qian active" v-if="choosetypeStatussix===index" v-for="el in limits" @click="joinRoom(item,el,rule)">
											{{$utils.abbr(el.bet_min/100)}} - {{$utils.abbr(el.bet_max/100)}}
										</div>
										<div class="totalinfo-item qian" v-if="choosetypeStatussix!==index"  v-for="el in limits" @click="joinRoom(item,el,rule)">
											{{$utils.abbr(el.bet_min/100)}} - {{$utils.abbr(el.bet_max/100)}}
										</div>
										
									</div>
								</div>
							</a>
						</div>
					</div>
                </div>
            </div>
        </div>

        <Alert :show="!!alertInfo" :content="alertInfo"></Alert>
		<!--提示框-->
		
        
    </div>
</template>

<script>
    import Alert from "./Alert.vue"
    import Loading from "./Loading.vue"
    import Notice from "./Notice.vue"
    import Waybill from "./waybill"
	let TEMP = {};
	
    export default {
        data() {
            return {
                loading: true,
                gameID: 7,
                rooms: [],
                limits: [],
                alertInfo: "",
                onlineCount: "",
				gamename:this.$t("GAME_TYPE_1"),
				bettinglimit:this.$t("BETTING_LIMIT"),
				choosetypeStatus:'',
				gameStatus:true,
				supername:this.$t("SUPERSIX"),
				choosetypeStatussix:'',
				tip: "",
				choosetip:"请选择限红",
				roomtype: {
					0: "",
					1: this.$t("SUPERSIX"),
					2: "",
					3: this.$t("SUPERSIX"),
					4: "", //多台
					5: this.$t("SUPERSIX"), //多台超级六
					6: "咪牌", //咪牌
					7: "咪牌",//咪牌超级六
				},
            };
        },
        components: {
            Alert,
            Loading,
            Notice
        },
		mounted(){
            this.alert(this.$t("CHOOSE_TIP"),0);
			if(navigator.platform.indexOf("Win")!=0){
				this.$utils.fullScreen(document.getElementsByTagName('body')[0]);
				document.getElementsByTagName('body')[0].style.width="100%";
				document.getElementsByTagName('body')[0].style.height=document.documentElement.clientHeight+'px';
				$('.full-height').height(document.documentElement.clientHeight);
				$('.lobby-box').height(document.documentElement.clientHeight);
			}
        },
        methods: {
			alert(tip, t){
                clearTimeout(TEMP.interval);
                this.tip = tip;
                if (t !== 0 && t !== false) TEMP.interval = setTimeout(() => this.tip = "", t || 2000);
				
            },
			toLowerCase(value){
                return value.toLowerCase();
            },
            /// 获取大厅所有数据（所有房间、限额）
            runningGame(data){
                let BACCARAT = data.games.filter(el => el.game_id - 0 === this.gameID);
                this.limits = JSON.parse(data.bet_limit).bet_limit.filter(el => el.game_idx === this.gameID)[0].limit.filter(el => el.bet_idx >= 0 && el.bet_idx <= 9999);
                this.rooms = BACCARAT[0].rooms || [];
                this.loading = false;
            },
            /// 更新房间倒计时时间
            setBetTimer(data){
                this.rooms.forEach((el, index) => {
                    if (el.room_id === data.room_id && data.game_id === 7) {
                        el.bet_timer = data.bet_timer;
                        el.remains = [data.bet_timer, Date.now()].join("-");
						el.gameStatus=false;
                        this.$set(this.rooms, index, el);
                    }
                });
            },
            /// 更新历史记录（路单）
            updateHistory(data){
				
                
            },
            /// 更新房间信息（荷官名称和房间状态）
            updateRoom(data){
				
                this.rooms.forEach((el, index) => {
                    if (el.room_id === data.room_id) {
                        el.dealer_id = data.dealer_id;
                        el.room_state = data.state;
                        this.$set(this.rooms, index, el);
                    }
                });
            },
            /// 更新房间列表
            reloadGameList(data){
                let rooms = data.rooms || [];
                if (data.state === 0) {
                    this.rooms.push.apply(this.rooms, rooms);
                } else if (data.state === 1) {
                    let ids = rooms.map(el => el.room_id);
                    this.rooms = this.rooms.filter(el => {
                        return ids.indexOf(el.room_id) === -1;
                    });
                }
            },
            /// 进入房间
            joinRoom(data, item, ruleid){
                let that = this;
                console.log("进入房间中...");
                this.loading = true;
                this.socket(200, {
                    game_id: this.gameID,
                    room_id: data.room_id,
                    rule_id: ruleid,
                    bet_id: item.bet_idx
                }, {
                    "210": (_data) => {
                        this.loading = false;
                        if (_data.result === 0 || _data.result === 6) {
							STORE.rule_id = ruleid;
                            STORE.roomInfo = data;
                            this.$router.replace({name: "room", query: {key: _data.header.key}});
                        } else {
							this.$router.replace({name: "room", query: {key: _data.header.key}});
                            this.alertInfo = this.$t(that.ERRORCODE[_data.result]) || that.ERRORCODE[_data.result];
                            console.log("进入房间失败，错误代码：", _data.result);
                        }
                    }
                });
            },
            bigRoad(histories){
				let allresults = (histories||[]).map(el => this.$utils.computedWinner(el))
				let allResults_2 = (histories||[]).map(el => this.$utils.computedWinner(el));
                let results = allResults_2.filter(el => el.split('')[0] !== "和");
				
                return new Waybill(allresults,results).BigRoad();
            }
        },
        created(){
            console.log("pos:", "lobby created");
            this.loading = true;
            this.socket(104, null, {
                "114": this.runningGame.bind(this),
                "122": this.setBetTimer.bind(this),
                "123": this.updateHistory.bind(this),
                "124": this.updateRoom.bind(this),
                "1213": this.reloadGameList.bind(this),
                "1214": (data) => {
                    this.onlineCount = data.ccu; /// 在线人数
                }
            });
        },
        beforeRouteEnter(to, from, next){
            next();
        }
    }
</script>