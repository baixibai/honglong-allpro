<template>
    <div class="full-height" v-if="show">
        <div class="mask"></div>
        <div class="loading">
            <div class="circle01">
                <div class="circle02"></div>
            </div>
        </div>
    </div>
</template>

<script>
    export default{
        props: {
            show: {
                type: Boolean,
                default: false
            }
        }
    }
</script>
