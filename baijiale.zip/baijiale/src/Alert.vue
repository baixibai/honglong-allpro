<style>
    .m-alert {
        position: fixed;
        left: 0;
        top: 10%;
        z-index: 999;
        width: 100%;
        text-align: center;
    }

    .m-alert-in {
        display: inline-block;
        width: 80%;
        max-width: 30rem;
        word-break: break-all;
        background: rgba(0, 0, 0, 0.8);
        border: 1px rgba(225, 225, 225, 0.2) solid;
        box-shadow: 0 0 12px 5px rgba(225, 225, 225, 0.3);
    }

    .m-alert-body {
        padding: 0.8rem;
        color: #fff;
        line-height: 1.6rem;
    }

    .m-alert-footer {
        border-top: 1px solid rgba(225, 225, 225, 0.3);
        display: -webkit-flex;
        display: flex;
    }

    .m-alert-footer button {
        flex: 1;
        background: rgba(38, 146, 208, 0.5);
        border: none;
        border-right: 1px solid rgba(0, 0, 0, 0.2);
        padding: 5px;
        color: #fff;
    }

    .m-alert-footer button:last-child {
        border: none;
    }
</style>
<template>
    <div class="m-alert" v-show="show">
        <div class="m-alert-in">
            <div class="m-alert-header" v-if="title">{{title}}</div>
            <div class="m-alert-body" v-html="content">
                <slot>&nbsp;</slot>
            </div>
            <div class="m-alert-footer">
                <button @click="show=false" v-if="cancel">{{cancelText || $t("CANCEL")}}</button>
                <button @click="confirm">{{okText || $t("OK")}}</button>
            </div>
        </div>
    </div>
</template>
<script>
    export default{
        props: {
            show: {
                type: Boolean,
                default: true,
                twoWay: true
            },
            title: {
                type: String
            },
            content: {
                type: String
            },
            okText: {
                type: String,
                default: ""
            },
            ok: {
                type: Function
            },
            cancel: {
                type: Function
            },
            cancelText: {
                type: String,
                default: ""
            }
        },
        methods: {
            confirm(){
                if (this.ok === undefined || (this.ok && this.ok() !== false)) {
                    this.show = false;
                }
            }
        }
    }
</script>
