<template>
    <div v-show="showMenu">
        <div class="menu-box-mask" v-on:click="changeRoomclose_menu"></div>
        <div class="menu-box" v-bind:class="{show:showMenu}">
            <div class="function-box">
                <div class="player-box">
                    <div class="player-pic">
                        <img src="/res/images/BlueUser.png" alt=""/>
                    </div>
                    <div class="player-info">{{username}}</div>
                </div>
                <a class="btn btn-assets" @click="viewHistory" v-if="roomMenu">{{menu1}}</a>
                <a class="btn btn-gamerule" @click="childstatus=true">{{menu2}}</a>
                <a class="btn btn-gamerule" @click="showProtocol" v-if="protocolMenu">{{menu3}}</a>
				<a class="btn btn-gamerule" @click="changeRoom" v-if="roomMenu">{{menu6}}</a>
                 <!--<a class="btn btn-gamerule" @click="showRule" v-if="ruleMenu">{{menu1}}</a>-->
				 <a class="btn btn-gamerule" @click="showRule" v-if="ruleMenu">{{menu7}}</a>
                <router-link to="/lobby" class="btn btn-backtohall" v-if="backToLobby">{{menu4}}</router-link>
                <a class="btn btn-gamerule" @click="logout">{{menu5}}</a>
				<!-- v-if="protocolMenu"-->
            </div>
			
            <div class="close-box" v-if="continuePlay">
                <a class="btn btn-close">
                    {{gamegoon}}
                    <svg version="1.1" xmlns="http://www.w3.org/2000/svg" xmlns:xlink="http://www.w3.org/1999/xlink" x="0px" y="0px" viewBox="0 0 34 34" style="enable-background:new 0 0 34 34;" xml:space="preserve">
                <polygon points="16.8,1.2 15.3,2.5 28.9,16 1,16 1,18 28.8,18 15.3,31.6 16.7,33.1 32.7,17.1 " />
                </svg>
                </a>
            </div>

        </div>
		<div class="childmenu" v-show="childstatus==true">
			<a class="btn btn-gamerule" @click="loadsource">{{menu8}}</a>
			<a class="btn btn-gamerule" @click="clearcookie">{{menu9}}</a>
		</div>
		
	</div>
</template>
<style>
.divLoadWrap{width: 100%; height: auto;overflow: hidden;}
.divLoadWrap img{width: 100px;height: 100px; position: relative; z-index: 10 }
.loadImgWrap p{ text-align: center!important;margin-top: 20px;}
.divLoadWrap div.list{float: left;width: 100px;height: 100px;margin:5px; border:1px solid #ccc;padding: 1px;overflow: hidden; position: relative;background: #222}
.loadImgWrap{width: 100%;height: 100%; text-align: center;background: rgba(0,0,0,.95); position: fixed; left: 0px; top: 0; color: #fff;font-size: 16px;transition:all 1s .1s ease;-moz-transition:all 1s  .1s ease;-webkit-transition:all 1s  .1s ease;display: none; z-index: 999999}
.loadImgWrap .cons div{display: inline-block;width: 94%;height: 12px; background: #fff; border-radius: 5px;overflow: hidden;margin-bottom: 0px!important;}
.loadImgWrap  .cons div em{display: block;width: 0%; background: red;height: 100%;border-radius: 5px;
transition:all 0.2s ease;-moz-transition:all 0.2s ease;-webkit-transition:all 0.2s ease;
}
.loadImgWrap span{width: 200px;display: inline-block;}
.loadImgWrap .cons{position: absolute; width: 300px;height: 80px; top: 50%;margin-top: -40px;left:50%;margin-left:-150px;}
.startLoadimg{display: block;width: 160px;height: 45px;font-size: 16px; border:none; background: #000;color: #fff;cursor: pointer;margin-bottom: 20px;}
.divLoadWrap div.list:after{
content: '';display: block;
width: 36px;height: 36px; border:2px solid rgba(0,255,255,.2); border-radius: 50%; border-top-color:rgba(0,255,255,1);
-webkit-animation: turn 1s linear infinite; position: absolute; left: 50%;top:50%;margin-left: -18px;margin-top: -18px;
-moz-animation: turn 1s linear infinite;
}
@-webkit-keyframes turn
{
0%   {-webkit-transform:rotate(0deg)}
100% {-webkit-transform:rotate(360deg)}
}
@-moz-keyframes turn
{
0%   {-moz-transform:rotate(0deg)}
100% {-moz-transform:rotate(360deg)}
}
	</style>
<script>
  // import $ from 'jquery'
    export default{
        props: {
            show: {
                type: Boolean,
                default: false
            },
            continuePlay: {
                type: Boolean,
                default: false
            },
            backToLobby: {
                type: Boolean,
                default: false
            },
            protocolMenu: {
                type: Boolean,
                default: false
            },
            ruleMenu: {
                type: Boolean,
                default: false
            },
			roomMenu: {
                type: Boolean,
                default: false
            },
        },
        data(){
            return {
                showMenu: this.show,
                username: window.STORE["113"].user.login_id,
				menu1:this.$t("MENU_NAME_1"),
				menu2:this.$t("MENU_NAME_2"),
				menu3:this.$t("MENU_NAME_3"),
				menu4:this.$t("MENU_NAME_4"),
				menu5:this.$t("MENU_NAME_5"),
				menu6:this.$t("MENU_NAME_6"),
				menu7:this.$t("MENU_NAME_7"),
				menu8:this.$t("MENU_NAME_8"),
				menu9:this.$t("MENU_NAME_9"),
				gamegoon:this.$t("MENU_GOON"),
                P:this.$t("P"),
                T:this.$t("T"),
                B:this.$t("B"),
                PGCNT:25,
                startsnon:'',
				flag:false,
				childstatus:false,
				setSms:'',
				re_code:'',
				codesta:false,
				dialogcontent:'',
				dialog:false
            };
        },
        watch: {
            show(val){
                this.showMenu = val;
            },
            showMenu(val){
                this.$emit("showMenu", val);
            }
        },
		created(){
			this.$utils.LoadImg()
            this.$parent.$on("changeroom-state", (status) => {
                this.showMenu = status;
            });
            this.$parent.$on("load-new-history", (kkk) => {
			
              if(kkk==this.startsnon || this.startsnon==''){

               return
              }
              this.viewHistory(kkk);
            });
        },
        methods: {
			loadsource(){
				var loadImgWrap = document.querySelector('.loadImgWrap');
				var span = loadImgWrap.querySelector('span');
				var em = loadImgWrap.querySelector('em');
				loadImgWrap.style.display = 'block';
				var resources = [
					this.$t("BGIMG_WIN")+'?t='+Math.random(),
					this.$t("BGIMG_WIN_SIX_L")+'?t='+Math.random(),
					this.$t("BGIMG_WIN_SIX_R")+'?t='+Math.random(),
					this.$t("BGIMG_WIN_SIX")+'?t='+Math.random(),
					this.$t("BGIMG_WIN_DT")+'?t='+Math.random(),
					this.$t("PLACE_YOUR_BETS_VOICE")+'?t='+Math.random(),
					this.$t("NO_YOUR_BETS_VOICE")+'?t='+Math.random(),
					this.$t("BANKER_HAS_VOICE")+'?t='+Math.random(),
					this.$t("BANKER_WIN_VOICE")+'?t='+Math.random(),
					this.$t("PLAYER_HAS_VOICE")+'?t='+Math.random(),
					this.$t("PLAYER_WIN_VOICE")+'?t='+Math.random(),
					this.$t("TIE_VOICE")+'?t='+Math.random(),
					this.$t("BACCARAT_VOICE")+'?t='+Math.random(),
					this.$t("CHIP_VOICE")+'?t='+Math.random(),
					this.$t("CLICK_CHIP_VOICE")+'?t='+Math.random(),
					this.$t("TIMER_TICK_0_VOICE")+'?t='+Math.random(),
					this.$t("TIMER_TICK_1_VOICE")+'?t='+Math.random(),
					this.$t("WINNER_BGM_VOICE")+'?t='+Math.random(),
					this.$t("LOSE_VOICE")+'?t='+Math.random(),
					this.$t("BG1_VOICE")+'?t='+Math.random(),
					this.$t("FLIPCARD")+'?t='+Math.random(),
					this.$t("TUK")+'?t='+Math.random(),
					this.$t("COUNTDOWN")+'?t='+Math.random(),
					this.$t("TIGERHAS")+'?t='+Math.random(),
					this.$t("DRAGONHAS")+'?t='+Math.random(),
					this.$t("DRAGON_WIN_VOICE")+'?t='+Math.random(),
					this.$t("TIGER_WIN_VOICE")+'?t='+Math.random(),
					this.$t("RESULT_0")+'?t='+Math.random(),
					this.$t("RESULT_1")+'?t='+Math.random(),
					this.$t("RESULT_2")+'?t='+Math.random(),
					this.$t("RESULT_3")+'?t='+Math.random(),
					this.$t("RESULT_4")+'?t='+Math.random(),
					this.$t("RESULT_5")+'?t='+Math.random(),
					this.$t("RESULT_6")+'?t='+Math.random(),
					this.$t("RESULT_7")+'?t='+Math.random(),
					this.$t("RESULT_8")+'?t='+Math.random(),
					this.$t("RESULT_9")+'?t='+Math.random(),
					this.$t("RESULT_10")+'?t='+Math.random(),
					this.$t("RESULT_11")+'?t='+Math.random(),
					this.$t("RESULT_12")+'?t='+Math.random(),
					this.$t("RESULT_13")+'?t='+Math.random(),
					"../lang/"+this.$t("LANGUAGE_TYPE")+'.json?t='+Math.random()
					];
				loadImg.init(resources,{
				datasrc : 'data-src',
					progress: function(b,a){
						span.innerHTML = 'load：' + (b*100).toFixed(0) + '%';
						em.style.width = (b*100).toFixed(0) +'%';
					},
					complete: function(a,b){
					   loadImgWrap.style.opacity = 0;
					   loadImgWrap.style.transform = 'scale(2)';
					   setTimeout(function(){
							loadImgWrap.style.display = 'none';
					   },800);
					}
				});
				this.showMenu = false;
				this.flag = true;
                
            },
            logout(){
                sessionStorage.removeItem("token");
                window.STORE.token = null;
                //this.$router.replace("/");
                location.href = "/";
            },
			clearcookie(){
                let date=new Date();
				date.setTime(date.getTime()+10*24*3600*1000);
				document.cookie='id='+encodeURIComponent('').replace(/!/g, '%21').replace(/'/g, '%27').replace(/\(/g, '%28').  
				replace(/\)/g, '%29').replace(/\*/g, '%2A').replace(/%20/g, '+')+'; path=/;expires='+date.toGMTString();
				document.cookie='password='+encodeURIComponent('').replace(/!/g, '%21').replace(/'/g, '%27').replace(/\(/g, '%28').  
				replace(/\)/g, '%29').replace(/\*/g, '%2A').replace(/%20/g, '+')+'; path=/;expires='+date.toGMTString();
				this.showMenu = false;
            },
            showProtocol(){
                this.showMenu = false;
                this.$parent.$emit("show-protocol", true);
            },
            showRule(){
                this.showMenu = false;
				this.$parent.$emit("show-room", false);
                this.$parent.$emit("show-rule", true);
            },
			changeRoom(){
                this.$parent.$emit("show-room", true);
            },
			changeRoomclose_menu(){
				this.childstatus=false;
				this.showMenu=false;
                this.$parent.$emit("show-room", false);
            },
            viewHistory(kkk){
   
             if(!isNaN(kkk)){this.startsnon=kkk;}
               this.$parent.$emit("loading", true);
                 this.showMenu = false;
                 this.$parent.$emit("show-room", false);
                 this.$parent.$emit("show-history", true);
                 this.$http.get(this.$t("GameHistoryurl"),{
                    params: {
                        type:"L",
                        b_type:"N",
                        name:window.STORE.gameName,
                        idx:window.STORE.token,
                        pgcnt:this.PGCNT,
                        sno:this.startsnon
                    }
                }).then(res => { 
                

				var xmlDom= new DOMParser().parseFromString(res.body, "text/xml"); //将xml字符串转成document对象,从而可以使用骰选器获取值
               var gameName=xmlDom.querySelectorAll("gameName");
               if(gameName[0].innerHTML=='BACCARAT'){
				  var gameResult=xmlDom.querySelectorAll('gameResult');
				  var resultArr=[];
					  for(var i=0;i<gameResult.length;i++){
					   var time=gameResult[i].querySelector('time').innerHTML;
					   var betCash= gameResult[i].querySelector('betCash').innerHTML;
					   var winCash= gameResult[i].querySelector('winCash').innerHTML;               
					   var winBalance= gameResult[i].querySelector('winBalance').innerHTML;
					   var winner=gameResult[i].querySelector('result').innerHTML;
					   var tableInfo=gameResult[i].querySelector('tableInfo').innerHTML;
					   var round=gameResult[i].querySelector('round').innerHTML;
					  var chipdatab={};
					  var chipdatap={};
					  chipdatab.val={};
						var arrcardnumb= gameResult[i].querySelector('card_banker').innerHTML.split(",");
						var arrcardnump= gameResult[i].querySelector('card_player').innerHTML.split(",");

					   var resultObj={};
					   var chipnump;
					   var chipnumb;
					   var cardsarr=[];   
					   var arrcardb=[];
					   for(var j=0;j<arrcardnumb.length;j++){
							var chipdatabc={};
							chipnumb=arrcardnumb[j];
							var chiptype= chipnumb%4;
							var chipnum=Math.floor(chipnumb/4);
							chipdatabc.type=chiptype;
							chipdatabc.val=chipnumb;
							chipdatabc.num=chipnum;
							cardsarr.push(chipnum)
							arrcardb.push(chipdatabc)

						  } 
						  var bankercval=this.$utils.getCardsValueHistory(cardsarr);
						  var cardsarr=[];
						  var arrcardp=[];
						for(var j=arrcardnump.length-1;j>=0;j--){
							var chipdatapc={};
							chipnumb=arrcardnump[j];
							var chiptype= chipnumb%4;
							var chipnum=Math.floor(chipnumb/4);
							chipdatapc.type=chiptype;
							chipdatapc.val=chipnumb;
							chipdatapc.num=chipnum;
							cardsarr.push(chipnum)
							arrcardp.push(chipdatapc);
						  } 
					  var playercval=this.$utils.getCardsValueHistory(cardsarr);


					   resultObj.time=time;
					   resultObj.winBalance=Math.floor(winBalance);
					   resultObj.betCash=Math.floor(betCash);
					   resultObj.winCash=Math.floor(winCash);
					   resultObj.cardplayer=arrcardp;
					   resultObj.cardbanker=arrcardb;
					   resultObj.bankercval=bankercval;
					   resultObj.playercval=playercval;
					   resultObj.winner=winner;
					   resultObj.tableInfo=tableInfo;
					   resultObj.round=round;
					   resultObj.sno=gameResult[i].getAttribute('no');
					   resultArr.push(resultObj);
				 
				  }
              }else  if(gameName[0].innerHTML=='DNT'){
				  var gameResult=xmlDom.querySelectorAll('gameResult');
				  var resultArr=[];
						for(var i=0;i<gameResult.length;i++){
						   var time=gameResult[i].querySelector('time').innerHTML;
						   var betCash= gameResult[i].querySelector('betCash').innerHTML;
						   var winCash= gameResult[i].querySelector('winCash').innerHTML;               
						   var winBalance= gameResult[i].querySelector('winBalance').innerHTML;
						   var winner=gameResult[i].querySelector('result').innerHTML;
						   var tableInfo=gameResult[i].querySelector('tableInfo').innerHTML;
						   var round=gameResult[i].querySelector('round').innerHTML;
						  var chipdatab={};
						  var chipdatap={};
						  chipdatab.val={};
							var arrcardnumb= gameResult[i].querySelector('card_tiger').innerHTML.split(",");
							var arrcardnump= gameResult[i].querySelector('card_dragon').innerHTML.split(",");

						   var resultObj={};
						   var chipnump;
						   var chipnumb;
						   // var cardsarr=[];
							var cardsarr=[];   
						   var arrcardb=[];
						   for(var j=0;j<arrcardnumb.length;j++){
								var chipdatabc={};
								chipnumb=arrcardnumb[j];
								var chiptype= chipnumb%4;
								var chipnum=Math.floor(chipnumb/4);
								chipdatabc.type=chiptype;
								chipdatabc.val=chipnumb;
								chipdatabc.num=chipnum;
								cardsarr.push(chipnum)
								arrcardb.push(chipdatabc)

							} 
					  var bankercval=this.$utils.getDTCardsValueHistory(cardsarr);
					  var cardsarr=[];
					  var arrcardp=[];
						for(var j=arrcardnump.length-1;j>=0;j--){
							var chipdatapc={};
							chipnumb=arrcardnump[j];
							var chiptype= chipnumb%4;
							var chipnum=Math.floor(chipnumb/4);
							chipdatapc.type=chiptype;
							chipdatapc.val=chipnumb;
							chipdatapc.num=chipnum;
							cardsarr.push(chipnum)
							arrcardp.push(chipdatapc);
					  } 
				  var playercval=this.$utils.getDTCardsValueHistory(cardsarr);


				   resultObj.time=time;
				   resultObj.winBalance=Math.floor(winBalance);
				   resultObj.betCash=Math.floor(betCash);
				   resultObj.winCash=Math.floor(winCash);
				   resultObj.cardplayer=arrcardp;
				   resultObj.cardbanker=arrcardb;
				   resultObj.bankercval=bankercval;
				   resultObj.playercval=playercval;
				   resultObj.winner=winner;
				   resultObj.tableInfo=tableInfo;
				   resultObj.round=round;
				   resultObj.sno=gameResult[i].getAttribute('no');
				   resultArr.push(resultObj);
				 
				  }


                

              }else  if(gameName[0].innerHTML=='ROULETTE'){
					var gameResult=xmlDom.querySelectorAll('gameResult');
					var resultArr=[];
					for(var i=0;i<gameResult.length;i++){
						var time=gameResult[i].querySelector('time').innerHTML;
						var betCash= gameResult[i].querySelector('betCash').innerHTML;
						var winCash= gameResult[i].querySelector('winCash').innerHTML;               
						var winBalance= gameResult[i].querySelector('winBalance').innerHTML;
						var winner=gameResult[i].querySelector('result').innerHTML;
						var tableInfo=gameResult[i].querySelector('tableInfo').innerHTML;
						var round=gameResult[i].querySelector('round').innerHTML;
						var chipdatab={};
						var chipdatap={};

						var resultObj={};
						
						resultObj.time=time;
						resultObj.winBalance=Math.floor(winBalance);
						resultObj.betCash=Math.floor(betCash);
						resultObj.winCash=Math.floor(winCash);
						resultObj.winner=winner;
						resultObj.tableInfo=tableInfo;
						resultObj.round=round;
						resultObj.sno=gameResult[i].getAttribute('no');
						resultArr.push(resultObj);

					}

              }else  if(gameName[0].innerHTML=='SICBO'){
					var gameResult=xmlDom.querySelectorAll('gameResult');
					var resultArr=[];
					for(var i=0;i<gameResult.length;i++){
						var time=gameResult[i].querySelector('time').innerHTML;
						var betCash= gameResult[i].querySelector('betCash').innerHTML;
						var winCash= gameResult[i].querySelector('winCash').innerHTML;               
						var winBalance= gameResult[i].querySelector('winBalance').innerHTML;
						var winner=gameResult[i].querySelector('result').innerHTML;
						var tableInfo=gameResult[i].querySelector('tableInfo').innerHTML;
						var round=gameResult[i].querySelector('round').innerHTML;
						var chipdatab={};
						var chipdatap={};

						var resultObj={};
						
						resultObj.time=time;
						resultObj.winBalance=Math.floor(winBalance);
						resultObj.betCash=Math.floor(betCash);
						resultObj.winCash=Math.floor(winCash);
						resultObj.winner=winner;
						resultObj.tableInfo=tableInfo;
						resultObj.round=round;
						resultObj.sno=gameResult[i].getAttribute('no');
						resultArr.push(resultObj);

					}

              }
             this.startsnon='';
             this.$parent.$emit("load-history", resultArr);//发射获取的结

             })
            }
        }
    }
</script>
