/**
 * Created by satrong on 17-2-6.
 */

export default class {
    constructor(data,data2,laststatus,gametype) {
		this.originData = data || [];
		this.originData2 = data2 || []
        this.colsArr = this.TotalCol();
		this.laststatus = laststatus || false;
		this.gametype = gametype || '';
    }
    getCookie(cookie_name)
	{
		var acookie=document.cookie.split("; ")
		// alert(acookie)
		for(var i=0;i<acookie.length;i++){ 
			var arr=acookie[i].split("="); 
			if(cookie_name==arr[0]){ 
			if(arr.length>1) {
			
			return unescape(arr[1]); 
		}
			else {
			return ""; }
		}} 
		return ""; 
	} 
    /// 生成表格
    RenderTable(data, option,type) {
		
        /// 取出x轴最大值
        let xRange = Object.keys(data).map(el => el.replace(/_\d+$/, '') - 0);
        let xMax = Math.max.apply(null, xRange);
        
        let t,
            x = xMax > 24 ? xMax : 24,
            y = option.y || 6,
            str = '',num=0;
		let arrsic=[111,112,113,122,114,123,222,115,124,133,223,116,125,134,224,233,126,135,144,234,225,333,136,145,226,235,244,334,146,155,236,245,335,344,156,246,255,336,345,444,166,256,346,355,445,266,356,446,455,366,456,555,466,556,566,666];
		if(type=="turn"){
				for (let i = 1; i <= y; i++) {
					let a=0;
					str += '<tr>';
					for (let j = x - 23; j <= x; j++) {
						let d = data[j + '_' + i],
							k = t = '';
						let s;
						if(d!=undefined){
							if (d ==0) {
								k = 'class="type_blue"';
							}else if (d%2 ==0) {
								k = 'class="type_red"';
							}else{
								k = 'class="type_black"';
							}
							s = '<i ' + k + '>' + d + '</i>';
						}else{
							s='';
						}
						str += '<td xy="' + j + ',' + i + '">' + s + '</td>';
					
					}
					
					str += '</tr>';
				}
		}else if(type=="sicbo"){
			for (let i = 1; i <= y; i++) {
				let a=0;
				str += '<tr>';
				x = Math.ceil(this.originData.length/6);
				for (let j = x - (x-1); j <= x; j++) {
					let d = data[j + '_' + i],
						k = t = '';
					let s;
					if(d!=undefined){
						if (d ==0) {
							k = 'class="type_blue"';
						}else if (d%2 ==0) {
							k = 'class="type_red"';
						}else{
							k = 'class="type_black"';
						}
						let big=this.getCookie('language')=='zh-CHS'?'大':'BIG';
						let small=this.getCookie('language')=='zh-CHS'?'小':'SMALL';
						let even=this.getCookie('language')=='zh-CHS'?'双':'EVEN';
						let odd=this.getCookie('language')=='zh-CHS'?'单':'ODD';
						// s = '<i ' + k + '>' + d + '</i>';
						num=parseInt(arrsic[d].toString().split('')[0])+parseInt(arrsic[d].toString().split('')[1])+parseInt(arrsic[d].toString().split('')[2]);
						let d1=num>10?'<span style="color: red;">'+big+'</span>':'<span style="color:rgb(42, 109, 173);">'+small+'</span>';
						let d2=num%2==0?'<span style="color: #e5d577;">'+even+'</span>':'<span style="color: #fff;">'+odd+'</span>';
						let numinfo = num>10?'<span style="color: red;">'+num+'</span>':'<span style="color:rgb(42, 109, 173);">'+num+'</span>';
						s = '<img src="res/images/sicbo/b'+arrsic[d].toString().split('')[0]+'.png" /><img src="res/images/sicbo/b'+arrsic[d].toString().split('')[1]+'.png" /><img src="res/images/sicbo/b'+arrsic[d].toString().split('')[2]+'.png" />'+numinfo+d1+d2;
					
					}else{
						s='';
					}
					
					str += '<td xy="' + j + ',' + i + '">' + s + '</td>';
				}
				
				str += '</tr>';
			}
		}else if(type=="sicbohot"){
				for (let i = 1; i <= y; i++) {
					let a=0;
					str += '<tr>';
					x = Math.ceil(this.originData.length/6);
					for (let j = x - (x-1); j <= x; j++) {
						let d = data[j + '_' + i],
							k = t = '';
						let s;
						if(d!=undefined){
							// if (d ==0) {
								// k = 'class="type_blue"';
							// }else if (d%2 ==0) {
								// k = 'class="type_red"';
							// }else{
								// k = 'class="type_black"';
							// }
							num=parseInt(arrsic[d].toString().split('')[0])+parseInt(arrsic[d].toString().split('')[1])+parseInt(arrsic[d].toString().split('')[2]);
							s = '<i ' + k + '>' + num + '</i>';
						}else{
							s='';
						}
						str += '<td xy="' + j + ',' + i + '">' + s + '</td>';
					
					}
					
					str += '</tr>';
				}
		}else{
			for (let i = 1; i <= y; i++) {
				str += '<tr>';
				for (let j = x - 23; j <= x; j++) {
					let d = data[j + '_' + i],
						k = t = '';
						
					if (/^\d+$/.test(d)) {
						t = d;
					} else {
						k = 'class="' + d + '"';
					}
					let s = d ? '<i ' + k + '>' + (option[d.split(' ')[0]] || t) + '</i>' : '';
					str += '<td xy="' + j + ',' + i + '">' + s + '</td>';
				}
				str += '</tr>';
			}
		}
      
        return '<table class="waybill-table ' + option.klass + '-table">' + str + '</table>';

    }
	
	/// 大路生成表格
    RenderBigTable(data, option) {
        /// 取出x轴最大值
        let xRange = Object.keys(data).map(el => el.replace(/_\d+$/, '') - 0);
        let xMax = Math.max.apply(null, xRange);
        
        let t,
            x = xMax > 24 ? xMax : 24,
            y = option.y || 6,
            str = '',bigstr='',num='';
        for (let i = 1; i <= y; i++) {
            str += '<tr>';
            for (let j = x - 23; j <= x; j++) {
                let d = data[j + '_' + i],
                    k = t = '';
                if (/^\d+$/.test(d)) {
                    t = d;
                } else {
                   
					k = 'class="' + d + '"';
					if(d!=undefined){
						num = Number(d.split(' ').slice(-1))==0?'':d.split(' ').slice(-1)
					}else{
						 num = ''
					}
                }
                
                let s = d ? '<i ' + k + '>'  +num+ '</i>' : '';
                str += '<td xy="' + j + ',' + i + '">' + s + '</td>';
            }
            str += '</tr>';
        }
        return '<table class="waybill-table ' + option.klass + '-table">' + str + '</table>';

    }
    
    /// 生成 路龙 的走势 数据对象 (适用于 大路、大眼仔、小路、蟑螂路)
    Trend(arr, option, originOps) {
        let that = this,
            dataObj = {},
            dataObj2 = {}, // 存储原始坐标
            red = option.red || '',
            blue = option.blue || '',
            data, reg = '',
            arr1 = arr.concat();
        originOps = originOps || false;// 是否返回原始坐标对象
        
        this.unique(arr1).forEach(function (b) {
            reg += '(' + b + ',)+|';
        });
        reg = new RegExp(reg.slice(0, -1), 'g');
        data = (arr.join(',') + ',').match(reg);
        
        // a对应着x轴，m对应y轴（假设有无限行）
        // 将路龙信息存储到dataObj对象中，对象的属性名为相应的坐标
        // 1对应red, 2对应blue
        arr.length > 0 && data.forEach(function (b, a) {
            let p = b.slice(0, -1).split(','),
                long = false,
                x0 = null,
                y0 = null;
            p.forEach(function (n, m) {
                let x = a + 1,
                    y = m + 1,
                    r;
                if (/龙|庄/.test(n)) {
                    n = red == '' ? 'icon-red-1' : red;
                } else if (/虎|闲/.test(n)) {
                    n = blue == '' ? 'icon-blue-1' : blue;
                }
                
                dataObj2[x + '_' + y] = n;
                if (((dataObj[x + '_' + y] && y < 7) || y == 7) && !long) { // 开始转弯
                    long = true;
                    //  转弯后的坐标
                    x0 = x + 1;
                    y0 = y - 1;
                    dataObj[x0 + '_' + y0] = n;
                } else if (long) {
                    dataObj[(x + y - y0) + '_' + y0] = n;
                } else {
                    if (y > 6) {
                        x = x + y - 6;
                        y = 6;
                    }
                    // 检查该粒的(垂直方向)下一粒 与 该粒的(水平方向)左边粒子 是否同色
                    if (dataObj[x + '_' + (y + 1)] == n || dataObj[(x - 1) + '_' + y] == n) {
                        dataObj[(x + 1) + '_' + (y - 1)] = n;
                    } else {
                        dataObj[x + '_' + y] = n;
                    }
                }
            });
        });
        return originOps ? {
                newPos: dataObj,
                oldPos: dataObj2
            } : dataObj;
    }
    
	// 大路专用
	/// 生成 路龙 的走势 数据对象 (适用于 大路、大眼仔、小路、蟑螂路)
    TrendBig(arr, option, originOps,arr2) {
        let that = this,
            dataObj = {},
            dataObj2 = {}, // 存储原始坐标
			dataObj3 = {},
            red = option.red || '',
            blue = option.blue || '',
			green = option.green || '',
			x_pairs = option.x_pairs || '',
			z_pairs = option.z_pairs || '',
			c_pairs = option.c_pairs || '',
            data, reg = '',
			arr1=["闲","庄","和"],
			arr3=[],data2='';
		if(arr2!=undefined){
			arr3=arr2.concat()
		}	
        originOps = originOps || false;// 是否返回原始坐标对象
		
        let dataarr = []
		
        this.unique(arr1).forEach(function (b) {
            reg += '(' + b + '[a-zA-z0-9-]{0,5},)+|';
        });
        reg = new RegExp(reg.slice(0, -1), 'g');
        data = (arr.join(',') + ',').match(reg);
		
        arr.length > 0 && data.forEach(function (b, a) {
            let p = b.slice(0, -1).split(','),
                long = false,
                x0 = null,
                y0 = null;
            p.forEach(function (n, m) {
                let x = a + 1,
                    y = m + 1,
                    r;
					let newcss=''
					if(n.split('')[0]=="庄"){
						newcss+=red
					}
					if(n.split('')[0]=="闲"){
						newcss+=blue
					}
					if(n.split('')[0]=="和"){
						newcss+=green
					}
					if(n.split('')[1]==1){
						newcss+="_1"
					}
					if(n.split('')[2]==1){
						newcss+="_2"
					}
					if(n.split('')[3]==1){
						newcss+="_3"
					}
					if(Number(n.split('')[5])>0){
						newcss+="_4"
					}
					n=newcss+' '+n.split('')[5] //和局数量，最后形成red x_pairs c_pairs 1的形式
					
				
                
                // dataObj2[x + '_' + y] = n;
                if (((dataObj[x + '_' + y] && y < 7) || y == 7) && !long) { // 开始转弯
                    long = true;
                    //  转弯后的坐标
                    x0 = x + 1;
                    y0 = y - 1;
                    dataObj[x0 + '_' + y0] = n;
					dataObj3[x0 + '_' + y0] = ''
                } else if (long) {
                    dataObj[(x + y - y0) + '_' + y0] = n;
					dataObj3[(x + y - y0) + '_' + y0] = '';
                } else {
                    if (y > 6) {
                        x = x + y - 6;
                        y = 6;
                    }
                    // 检查该粒的(垂直方向)下一粒 与 该粒的(水平方向)左边粒子 是否同色
                    if (dataObj[x + '_' + (y + 1)] == n || dataObj[(x - 1) + '_' + y] == n) {
                        dataObj[(x + 1) + '_' + (y - 1)] = n;
						dataObj3[(x + 1) + '_' + (y - 1)] = '';
                    } else {
                        dataObj[x + '_' + y] = n;
						dataObj3[x + '_' + y] = '';
                    }
                }
            });
        });
		if(arr2!=undefined){
			data2 = (arr2.join(',') + ',').match(reg);
			if(data2==null){
				data2=[];
			}
			arr2.length > 0 && data2.forEach(function (b, a) {
				let p = b.slice(0, -1).split(','),
					long = false,
					x0 = null,
					y0 = null;
				p.forEach(function (n, m) {
					let x = a + 1,
						y = m + 1,
						r;
					if (/龙|庄/.test(n)) {
						n = red == '' ? 'icon-red-1' : red;
					} else if (/虎|闲/.test(n)) {
						n = blue == '' ? 'icon-blue-1' : blue;
					}
					
					dataObj2[x + '_' + y] = n;
				});
			});
		}	
        return originOps ? {
                newPos: dataObj,
                oldPos: dataObj2,
				num : dataObj3,
            } : dataObj;
    }
	
	 DTTrendBig(arr, option, originOps) {
        let that = this,
            dataObj = {},
            dataObj2 = {}, // 存储原始坐标
			dataObj3 = {},
            red = option.red || '',
            blue = option.blue || '',
			green = option.green || '',
            data, reg = '',
			arr1=["虎","龙","和"],
			data2='';
        originOps = originOps || false;// 是否返回原始坐标对象
		
        let dataarr = []
		this.unique(arr1).forEach(function (b) {
			reg += '(' + b + '[a-zA-z0-9-]{0,3},)+|';
        });
        reg = new RegExp(reg.slice(0, -1), 'g');
        data = (arr.join(',') + ',').match(reg);
        arr.length > 0 && data.forEach(function (b, a) {
            let p = b.slice(0, -1).split(','),
                long = false,
                x0 = null,
                y0 = null;
            p.forEach(function (n, m) {
                let x = a + 1,
                    y = m + 1,
                    r;
					let newcss=''
					if(n.split('')[0]=="龙"){
						newcss+=red
					}
					if(n.split('')[0]=="虎"){
						newcss+=blue
					}
					if(n.split('')[0]=="和"){
						newcss+=green
					}
					if(Number(n.split('')[2])>0){
						newcss+="_h"
					}
					n=newcss+' '+n.split('')[2] //和局数量，最后形成red x_pairs c_pairs 1的形式

                // dataObj2[x + '_' + y] = n;
                if (((dataObj[x + '_' + y] && y < 7) || y == 7) && !long) { // 开始转弯
                    long = true;
                    //  转弯后的坐标
                    x0 = x + 1;
                    y0 = y - 1;
                    dataObj[x0 + '_' + y0] = n;
                } else if (long) {
                    dataObj[(x + y - y0) + '_' + y0] = n;
                } else {
                    if (y > 6) {
                        x = x + y - 6;
                        y = 6;
                    }
                    // 检查该粒的(垂直方向)下一粒 与 该粒的(水平方向)左边粒子 是否同色
                    if (dataObj[x + '_' + (y + 1)] == n || dataObj[(x - 1) + '_' + y] == n) {
                        dataObj[(x + 1) + '_' + (y - 1)] = n;
                    } else {
                        dataObj[x + '_' + y] = n;
                    }
                }
            });
        });	
        return originOps ? {
                newPos: dataObj,
            } : dataObj;
    }
	
    /// 大路
    BigRoad() {
		let bigarr = []
		let newindex = 0 
		let numarr = []
		this.originData.forEach((el, index) => {
			let new_result=this.originData[index].split('').slice(0,4).join('')
			if(/和/.test(new_result)){
				if(index==0){
					bigarr.push(new_result+'-1')
				}else{
					let result_arr=bigarr[newindex].split('')
					bigarr[newindex]=result_arr[0]+(Number(result_arr[1])+Number(new_result.split('')[1])?1:0)+(Number(result_arr[2])+Number(new_result.split('')[2])?1:0)+(Number(result_arr[3])+Number(new_result.split('')[3])?1:0)+result_arr[4]+result_arr[5]
					bigarr[newindex]=bigarr[newindex].split('-')[0]+"-"+(Number(bigarr[newindex].split('-')[1])+1)
				}
			}else{
				if(bigarr[newindex]!=undefined){
					newindex++;
				}
				if(/和/.test(bigarr[0])){
					bigarr.push(new_result+'-'+bigarr[bigarr.length-1].split("").splice(-1))
					delete bigarr[0]
				}else{
					bigarr.push(new_result+'-0')
				}
				
				
			}
		})
			
        let dataObj = this.TrendBig(bigarr, {
            red: 'zstyle',
            blue: 'xstyle',
			green: 'hstyle',
			x_pairs:'css16', //闲对
			z_pairs:'css8', //庄对
			c_pairs:'bigtype4', //超级六
        }, 1,this.originData2);
		let dataObjother = this.Trend(this.originData2, {
            red: 'type6',
            blue: 'type7'
        }, 1);
        this.bigRoadData = dataObjother;
		let props = "";
		let carr={};
		let lastkey="";
		for (let keyname in dataObj.newPos){
			lastkey=keyname;
		}
		dataObj.newPos[lastkey]=this.laststatus?'lastanimation '+dataObj.newPos[lastkey]:dataObj.newPos[lastkey]
        return '<div class="big-road">' + this.RenderBigTable(dataObj.newPos, {
                klass: 'big-road',
                type4: "庄",
                type5: "闲",
            }) + '</div>';
    }
    
	/// 龙虎大路
    DTBigRoad() {

		let bigarr = []
		let newindex = 0 
		let numarr = []
		this.originData.forEach((el, index) => {
			let new_result=this.originData[index].split('').slice(0,4).join('')
			if(/和/.test(new_result)){
				if(index==0){
					bigarr.push(new_result+'-1')
				}else{
					let result_arr=bigarr[newindex].split('')
					bigarr[newindex]=result_arr[0]+result_arr[1]+result_arr[2]
					bigarr[newindex]=bigarr[newindex].split('-')[0]+"-"+(Number(bigarr[newindex].split('-')[1])+1)
				}
			}else{
				if(bigarr[newindex]!=undefined){
					newindex++;
				}
				if(/和/.test(bigarr[0])){
					bigarr.push(new_result+'-'+bigarr[bigarr.length-1].split("").splice(-1))
					delete bigarr[0]
				}else{
					bigarr.push(new_result+'-0')
				}	
			}
		})
        let dataObj = this.DTTrendBig(bigarr, {
            red: 'zstyle',
            blue: 'xstyle',
			green: 'hstyle',
        }, 1);
		let dataObjother = this.Trend(this.originData2, {
            red: 'type6',
            blue: 'type7'
        }, 1);
        this.bigRoadData = dataObjother;
		let props = "";
		let carr={};
		let lastkey="";
		for (let keyname in dataObj.newPos){
			lastkey=keyname;
		}
		dataObj.newPos[lastkey]=this.laststatus?'lastanimation '+dataObj.newPos[lastkey]:dataObj.newPos[lastkey]
        return '<div class="big-road">' + this.RenderBigTable(dataObj.newPos, {
                klass: 'big-road',
                type4: "龙",
                type5: "虎",
            }) + '</div>';
    }
	
    /// 珠盘路
    PearlRoad() {
        let arr = this.originData,
            dataObj = {};
		let dataarr = []
		arr.forEach((el, index) => {
			dataarr.push(el.split('')[0])
		});
        dataarr.forEach(function (n, a) {
            let x = parseInt(a / 6) + 1,
                y = a % 6 + 1;
            if (/龙/.test(n)) {
                n = 'type5_d';
            } else if (/虎/.test(n)) {
                n = 'type4_t';
            } else if (/庄/.test(n)) {
                n = 'type4';
            } else if (/闲/.test(n)) {
                n = 'type5';
            } else if (/和/.test(n)) {
                n = 'type5_4';
            }
            dataObj[x + '_' + y] = n;
        });
		let lastkey="";
		for (let keyname in dataObj){
			lastkey=keyname;
		}
		dataObj[lastkey]=this.laststatus?dataObj[lastkey]+' lastanimation':dataObj[lastkey]                    
        return '<div class="pearl-road pearl-road-5">' + this.RenderTable(dataObj, {
                klass: 'pearl-road',
                type4: "庄",
                type5: "闲",
				type5_4: "和",
				type4_t: "虎",
                type5_d: "龙",
            }) + '</div>';
    }
    
    /// 统计每列的个数，供齐整使用
    TotalCol() {
        let that = this,
            colsArr = [],
            reg = '',
            data,
            arr = that.originData2.concat(),
            arr1 = that.originData2.concat();
        this.unique(arr1).forEach(function (b, a) {
            reg += '(' + b + ',)+|';
        });
        reg = new RegExp(reg.slice(0, -1), 'g');
        data = (arr.join(',') + ',').match(reg);
        
        data.forEach(function (b, a) {
            colsArr.push(b.slice(0, -1).split(',').length);
        });
        return colsArr;
    }
    
    /// 从大路中 整理出 下三路 的数据
    DownRoad(startX) {
        let that = this,
            dataObj = {},
            bigRoadData = this.bigRoadData.oldPos,
            colsArr = this.colsArr,
            newArr = [];
        startX = startX || 2;
		// for(let i in bigRoadData){
			// if(bigRoadData[i]=='和'){delete bigRoadData[i];}
		// };
        /// 判断 下路中的三条路分别是否有数据,无数据则返回空数组
        if ((startX - 2 === 0 && !(bigRoadData['2_2'] || bigRoadData['3_1'])) ||
            (startX - 3 === 0 && !(bigRoadData['3_2'] || bigRoadData['4_1'])) ||
            (startX - 4 === 0 && !(bigRoadData['4_2'] || bigRoadData['5_1']))
        ) {
            return newArr;
        }
        
        for(let a in bigRoadData){
            let d = a.split('_'),
                xy = {
                    x: d[0],
                    y: d[1]
                };
            if (xy.x > startX || (xy.x - startX === 0 && xy.y > 1)) {
                /// 看齐整
                if (xy.y == 1) {
                    if (colsArr[xy.x - 2] == colsArr[xy.x - 1 - startX]) {
                        newArr.push('庄');
                    } else {
                        newArr.push('闲');
                    }
                }
                /// 看有无
                else {
                    let x = xy.x - startX + 1;
                    if (bigRoadData[x + '_' + xy.y]) {
                        newArr.push('庄');
                    }
                    /// 看直落
                    else {
                        // if (xy.y == 2) {
                            // newArr.push('闲');
                        // }
                        /// 为直落
                        if (!bigRoadData[(xy.x - startX + 1) + '_' + (xy.y - 1)]) {
                            newArr.push('庄');
                        } else {
                            newArr.push('闲');
                        }
                    }
                }
            }
        }
        return newArr;
    }
    
    /// 大眼仔
    BigEyeRoad() {
		
        let dataObj = this.Trend(this.DownRoad(2), {
            red: 'type6',
            blue: 'type7'
        });
		let lastkey="";
		for (let keyname in dataObj){
			lastkey=keyname;
		}
		dataObj[lastkey]=this.laststatus?dataObj[lastkey]+' lastanimation':dataObj[lastkey]   
        return '<div class="big-road">' + this.RenderTable(dataObj, {
                klass: 'big-eye-road'
            }) + '</div>';
    }
    
    /// 小路
    SmallRoad() {
        let dataObj = this.Trend(this.DownRoad(3), {
            red: 'type8',
            blue: 'type9'
        });
		let lastkey="";
		for (let keyname in dataObj){
			lastkey=keyname;
		}
		dataObj[lastkey]=this.laststatus?dataObj[lastkey]+' lastanimation':dataObj[lastkey]
        return '<div class="small-road">' + this.RenderTable(dataObj, {
                klass: 'small-road'
            }) + '</div>';
    }
    
    /// 蟑螂路
    RoachRoad() {
        let dataObj = this.Trend(this.DownRoad(4), {
            red: 'type10',
            blue: 'type11'
        });
		let lastkey="";
		for (let keyname in dataObj){
			lastkey=keyname;
		}
		dataObj[lastkey]=this.laststatus?dataObj[lastkey]+' lastanimation':dataObj[lastkey]
        return '<div class="roach-road">' + this.RenderTable(dataObj, {
                klass: 'roach-road'
            }) + '</div>';
    }
	
	/// 处理问路
    DownknowRoad(startX,data,type) {
        let that = this,
            dataObj = {},
            bigRoadData = this.knowRoadData.oldPos,
            colsArr = this.TotalColknow(data),
            newArr = [];
        startX = startX || 2;
        /// 判断 下路中的三条路分别是否有数据,无数据则返回空数组
        if ((startX - 2 === 0 && !(bigRoadData['2_2'] || bigRoadData['3_1'])) ||
            (startX - 3 === 0 && !(bigRoadData['3_2'] || bigRoadData['4_1'])) ||
            (startX - 4 === 0 && !(bigRoadData['4_2'] || bigRoadData['5_1']))
        ) {
            return newArr;
        }
        
        for(let a in bigRoadData){
            let d = a.split('_'),
                xy = {
                    x: d[0],
                    y: d[1]
                };
            if (xy.x > startX || (xy.x - startX === 0 && xy.y > 1)) {
                /// 看齐整
                if (xy.y == 1) {
                    if (colsArr[xy.x - 2] == colsArr[xy.x - 1 - startX]) {
						if(type=='dt'){
							newArr.push('龙');
						}else{
							newArr.push('庄');
						}
                        
                    } else {
						if(type=='dt'){
							newArr.push('虎');
						}else{
							newArr.push('闲');
						}
                    }
                }
                /// 看有无
                else {
                    let x = xy.x - startX + 1;
                    if (bigRoadData[x + '_' + xy.y]) {
						if(type=='dt'){
							newArr.push('龙');
						}else{
							newArr.push('庄');
						}
                    }
                    /// 看直落
                    else {
                        // if (xy.y == 2) {
                            // newArr.push('闲');
                        // }
                        /// 为直落
                        if (!bigRoadData[(xy.x - startX + 1) + '_' + (xy.y - 1)]) {
                            if(type=='dt'){
								newArr.push('龙');
							}else{
								newArr.push('庄');
							}
                        } else {
                            if(type=='dt'){
								newArr.push('虎');
							}else{
								newArr.push('闲');
							}
                        }
                    }
                }
            }
        }
        return newArr;
		
    }
	/// 问路统计每列的个数，供齐整使用
    TotalColknow(value) {
        let that = this,
            colsArr = [],
            reg = '',
            data,
            arr = that.originData2.concat(),
            arr1 = that.originData2.concat();
			arr.push(value)
			arr1.push(value)
        this.unique(arr1).forEach(function (b, a) {
            reg += '(' + b + ',)+|';
        });
        reg = new RegExp(reg.slice(0, -1), 'g');
        data = (arr.join(',') + ',').match(reg);
        
        data.forEach(function (b, a) {
            colsArr.push(b.slice(0, -1).split(',').length);
        });
        return colsArr;
    }
	 /// 问路
    KnowRoad(data,type) {
		let konwdata = this.originData2
		konwdata.push(data)
		let dataObjother = this.Trend(konwdata, {
            red: 'type6',
            blue: 'type7'
        }, 1);
        this.knowRoadData = dataObjother;
		
		let arrroad = [];
		if(this.DownknowRoad(2,data,this.gametype).pop()!=undefined){
			arrroad.push(this.DownknowRoad(2,data,this.gametype).pop());
		}
		if(this.DownknowRoad(3,data,this.gametype).pop()!=undefined){
			arrroad.push(this.DownknowRoad(3,data,this.gametype).pop());
		}
		if(this.DownknowRoad(4,data,this.gametype).pop()!=undefined){
			arrroad.push(this.DownknowRoad(4,data,this.gametype).pop());
		}
        return  arrroad;
    }
	// 轮盘
	TurnRoad() {
		
        let arr = this.originData,
            dataObj = {};
        arr.forEach(function (n, a) {
            let x = parseInt(a / 6) + 1,
                y = a % 6 + 1;
            dataObj[x + '_' + y] = n;
        });
		let lastkey="";
		for (let keyname in dataObj){
			lastkey=keyname;
		}
		dataObj[lastkey]=this.laststatus?dataObj[lastkey]+' lastanimation':dataObj[lastkey]    
        return '<div class="pearl-road pearl-road-5">' + this.RenderTable(dataObj, {
                klass: 'pearl-road'
            },'turn') + '</div>';
    }
	//骰宝
	SicboRoad(){
		
        let arr = this.originData,
            dataObj = {};
        arr.forEach(function (n, a) {
            let x = parseInt(a / 6) + 1,
                y = a % 6 + 1;
            dataObj[x + '_' + y] = n;
        });
		let lastkey="";
		for (let keyname in dataObj){
			lastkey=keyname;
		}
		dataObj[lastkey]=this.laststatus?dataObj[lastkey]+' lastanimation':dataObj[lastkey]    
        return '<div class="pearl-road pearl-road-5"><div style="width:360px;">' + this.RenderTable(dataObj, {
                klass: 'sicbo-road'
            },'sicbo') + '</div></div>';
    }
	hotRoad(){
		
        let arr = this.originData,
            dataObj = {};
        arr.forEach(function (n, a) {
            let x = parseInt(a / 6) + 1,
                y = a % 6 + 1;
            dataObj[x + '_' + y] = n;
        });
		let lastkey="";
		for (let keyname in dataObj){
			lastkey=keyname;
		}
		dataObj[lastkey]=this.laststatus?dataObj[lastkey]+' lastanimation':dataObj[lastkey]    
        return '<div class="pearl-road pearl-road-5"><div style="width:230px;overflow:auto;">' + this.RenderTable(dataObj, {
                klass: 'hot-road',
				y:4
            },'sicbohot') + '</div></div>';
    }
	
    unique(arr) {
        let mapping = {};
        arr.forEach(function (el) {
            mapping[el] = 1;
        });
        return Object.keys(mapping);
    }
}